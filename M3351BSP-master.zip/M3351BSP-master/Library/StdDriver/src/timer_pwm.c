/**************************************************************************//**
 * @file     timer_pwm.c
 * @version  V3.00
 * @brief    Timer PWM Controller(Timer PWM) driver source file
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 *****************************************************************************/
#include "NuMicro.h"

/** @addtogroup Standard_Driver Standard Driver
  @{
*/

/** @addtogroup TIMER_PWM_Driver TIMER_PWM Driver
  @{
*/

/** @addtogroup TIMER_PWM_EXPORTED_FUNCTIONS TIMER_PWM Exported Functions
  @{
*/

/**
  * @brief      Configure TPWM Output Frequency and Duty Cycle
  *
  * @param[in]  timer           The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @param[in]  u32Frequency    Target generator frequency.
  * @param[in]  u32DutyCycle    Target generator duty cycle percentage. Valid range are between 0~100. 10 means 10%, 20 means 20%...
  *
  * @return     Nearest frequency clock in nano second
  *
  * @details    This API is used to configure TPWM output frequency and duty cycle in up count type and auto-reload operation mode.
  * @note       This API is only available if Timer PWM counter clock source is from TMRx_CLK.
  */
uint32_t TPWM_ConfigOutputFreqAndDuty(TIMER_T *timer, uint32_t u32Frequency, uint32_t u32DutyCycle)
{
    uint32_t u32Src = 2UL;
    uint32_t u32PWMClockFreq;
    uint32_t u32TargetFreq;
    uint32_t u32Prescaler = 0x100UL;
    uint32_t u32Period = 1UL;
    const uint32_t au32Clk[] = {__HXT, __LXT, 0UL, 0UL, 0UL, __LIRC, 0UL, __HIRC};

    if (u32Frequency == 0UL)
    {
        return u32Frequency;
    }

    if (timer == TIMER0)
    {
        u32Src = (CLK->CLKSEL1 & CLK_CLKSEL1_TMR0SEL_Msk) >> CLK_CLKSEL1_TMR0SEL_Pos;
    }
    else if (timer == TIMER1)
    {
        u32Src = (CLK->CLKSEL1 & CLK_CLKSEL1_TMR1SEL_Msk) >> CLK_CLKSEL1_TMR1SEL_Pos;
    }
    else if (timer == TIMER2)
    {
        u32Src = (CLK->CLKSEL1 & CLK_CLKSEL1_TMR2SEL_Msk) >> CLK_CLKSEL1_TMR2SEL_Pos;
    }
    else      /* Timer 3 */
    {
        u32Src = (CLK->CLKSEL1 & CLK_CLKSEL1_TMR3SEL_Msk) >> CLK_CLKSEL1_TMR3SEL_Pos;
    }

    if (u32Src == 2UL)
    {
        if ((timer == TIMER0) || (timer == TIMER1))
        {
            u32PWMClockFreq = CLK_GetPCLK0Freq();
        }
        else
        {
            u32PWMClockFreq = CLK_GetPCLK1Freq();
        }
    }
    else
    {
        u32PWMClockFreq = au32Clk[u32Src];
    }

    if (u32Frequency > u32PWMClockFreq)
    {
        return 0UL;
    }

    /* Calculate u32Period and u32Prescaler */
    for (u32Prescaler = 1UL; u32Prescaler <= 0x100UL; u32Prescaler++)
    {
        u32Period = (u32PWMClockFreq / u32Prescaler) / u32Frequency;

        /* If target u32Period is larger than 0x10000, need to use a larger prescaler */
        if (u32Period > 0x10000UL)
        {
            continue;
        }

        break;
    }

    if (u32Prescaler == 0x101UL)
    {
        u32Prescaler = 0x100UL;
        u32Period = 0x10000UL;
    }

    /* Store return value here 'cos we're gonna change u32Prescaler & u32Period to the real value to fill into register */
    u32TargetFreq = (u32PWMClockFreq / u32Prescaler) / u32Period;

    /* Set PWM to auto-reload mode */
    timer->PWMCTL = (timer->PWMCTL & ~TIMER_PWMCTL_CNTMODE_Msk) | (TPWM_AUTO_RELOAD_MODE << TIMER_PWMCTL_CNTMODE_Pos);

    /* Convert to real register value */
    TPWM_SET_PRESCALER(timer, (u32Prescaler - 1UL));

    TPWM_SET_PERIOD(timer, (u32Period - 1UL));
    TPWM_SET_CMPDAT(timer, (u32DutyCycle * u32Period) / 100UL);

    return (u32TargetFreq);
}

/**
  * @brief      Enable TPWM Counter
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to enable TPWM generator and start counter counting.
  */
void TPWM_EnableCounter(TIMER_T *timer)
{
    timer->PWMCTL |= TIMER_PWMCTL_CNTEN_Msk;
}

/**
  * @brief      Disable TPWM Generator
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details This function is used to disable TPWM counter immediately by clear CNTEN (TIMERx_PWMCTL[0]) bit.
  */
void TPWM_DisableCounter(TIMER_T *timer)
{
    timer->PWMCTL &= ~TIMER_PWMCTL_CNTEN_Msk;
}

/**
  * @brief      Enable TPWM Trigger ADC/DAC/PDMA
  *
  * @param[in]  timer           The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @param[in]  u32TargetMask   The mask of modules (DAC/EADC/PDMA) trigger by TPWM, the combination of:
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGDAC_Msk
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGEADC_Msk
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGPDMA_Msk
  * @param[in]  u32Condition    The condition to trigger ADC/DAC/PDMA. It could be one of following conditions:
  *                                 - \ref TPWM_TRIGGER_AT_PERIOD_POINT
  *                                 - \ref TPWM_TRIGGER_AT_COMPARE_POINT
  *                                 - \ref TPWM_TRIGGER_AT_PERIOD_OR_COMPARE_POINT
  * @return     None
  *
  * @details    This function is used to enable specified counter event to trigger ADC/DAC/PDMA.
  */
void TPWM_EnableTrigger(TIMER_T *timer, uint32_t u32TargetMask, uint32_t u32Condition)
{
    if ((u32TargetMask == 0UL) || ((u32TargetMask & ~(TIMER_PWMTRGCTL_PWMTRGDAC_Msk | TIMER_PWMTRGCTL_PWMTRGEADC_Msk | TIMER_PWMTRGCTL_PWMTRGPDMA_Msk)) != 0UL))
    {
        return;
    }

    timer->PWMTRGCTL &= ~(TIMER_PWMTRGCTL_PWMTRGDAC_Msk | TIMER_PWMTRGCTL_PWMTRGEADC_Msk | TIMER_PWMTRGCTL_PWMTRGPDMA_Msk | TIMER_PWMTRGCTL_TRGSEL_Msk);
    timer->PWMTRGCTL |= (u32TargetMask) | ((u32Condition) & TIMER_PWMTRGCTL_TRGSEL_Msk);
}

/**
  * @brief      Disable Trigger ADC/DAC/PDMA
  *
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @param[in]  u32TargetMask   The mask of modules (DAC/EADC/PDMA) trigger by TPWM, the combination of:
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGDAC_Msk
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGEADC_Msk
  *                                 - \ref TIMER_PWMTRGCTL_PWMTRGPDMA_Msk
  *
  * @return     None
  *
  * @details    This function is used to disable counter event to trigger ADC/DAC/PDMA.
  */
void TPWM_DisableTrigger(TIMER_T *timer, uint32_t u32TargetMask)
{
    if ((u32TargetMask & ~(TIMER_PWMTRGCTL_PWMTRGDAC_Msk | TIMER_PWMTRGCTL_PWMTRGEADC_Msk | TIMER_PWMTRGCTL_PWMTRGPDMA_Msk)) != 0UL)
    {
        return;
    }

    timer->PWMTRGCTL &= ~(u32TargetMask);
}

/**
  * @brief      Enable Interrupt Flag Accumulator
  * @param[in]  timer           The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @param[in]  u32IntFlagCnt   Interrupt flag counter. Valid values are between 0~65535.
  * @param[in]  u32IntAccSrc    Interrupt flag accumulator source selection.
  *                                 - \ref TPWM_IFA_PERIOD_POINT
  *                                 - \ref TPWM_IFA_COMPARE_UP_COUNT_POINT
  * @return     None
  * @details    This function is used to enable interrupt flag accumulator.
  */
void TPWM_EnableAcc(TIMER_T *timer, uint32_t u32IntFlagCnt, uint32_t u32IntAccSrc)
{
    timer->PWMIFA = (((timer)->PWMIFA & ~(TIMER_PWMIFA_IFACNT_Msk | TIMER_PWMIFA_IFASEL_Msk | TIMER_PWMIFA_STPMOD_Msk))
                     | (TIMER_PWMIFA_IFAEN_Msk | (u32IntFlagCnt & TIMER_PWMIFA_IFACNT_Msk) | ((u32IntAccSrc & 0x3UL) << TIMER_PWMIFA_IFASEL_Pos)));
}

/**
  * @brief      Disable Interrupt Flag Accumulator
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to disable interrupt flag accumulator.
  */
void TPWM_DisableAcc(TIMER_T *timer)
{
    timer->PWMIFA &= ~TIMER_PWMIFA_IFAEN_Msk;
}

/**
  * @brief      Enable Interrupt Flag Accumulator Interrupt Function
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to enable interrupt flag accumulator interrupt.
  */
void TPWM_EnableAccInt(TIMER_T *timer)
{
    timer->PWMAINTEN |= TIMER_PWMAINTEN_IFAIEN_Msk;
}

/**
  * @brief      Disable Interrupt Flag Accumulator Interrupt Function
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to disable interrupt flag accumulator interrupt.
  */
void TPWM_DisableAccInt(TIMER_T *timer)
{
    timer->PWMAINTEN &= ~TIMER_PWMAINTEN_IFAIEN_Msk;
}

/**
  * @brief      Clear Interrupt Flag Accumulator Interrupt Flag
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to clear interrupt flag accumulator interrupt.
  */
void TPWM_ClearAccInt(TIMER_T *timer)
{
    timer->PWMAINTSTS = TIMER_PWMAINTSTS_IFAIF_Msk;
}

/**
  * @brief      Get Interrupt Flag Accumulator Interrupt Flag
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @retval     0   Accumulator interrupt did not occur
  * @retval     1   Accumulator interrupt occurred
  * @details    This function is used to get interrupt flag accumulator interrupt.
  */
uint32_t TPWM_GetAccInt(const TIMER_T *timer)
{
    return (((timer)->PWMAINTSTS & TIMER_PWMAINTSTS_IFAIF_Msk) ? 1UL : 0UL);
}

/**
  * @brief      Enable Accumulator Interrupt Trigger PDMA
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to enable accumulator interrupt trigger PDMA transfer.
  */
void TPWM_EnableAccPDMA(TIMER_T *timer)
{
    timer->PWMAPDMACTL |= TIMER_PWMAPDMACTL_APDMAEN_Msk;
}

/**
  * @brief      Disable Accumulator Interrupt Trigger PDMA
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to disable accumulator interrupt trigger PDMA transfer.
  */
void TPWM_DisableAccPDMA(TIMER_T *timer)
{
    timer->PWMAPDMACTL &= ~TIMER_PWMAPDMACTL_APDMAEN_Msk;
}

/**
  * @brief      Enable Interrupt Flag Accumulator Stop Mode
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to enable interrupt flag accumulator event to stop PWM counting.
  */
void TPWM_EnableAccStopMode(TIMER_T *timer)
{
    timer->PWMIFA |= TIMER_PWMIFA_STPMOD_Msk;
}

/**
  * @brief      Disable Interrupt Flag Accumulator Stop Mode
  * @param[in]  timer       The pointer of the specified Timer module. It could be TIMER0, TIMER1, TIMER2, TIMER3.
  * @return     None
  * @details    This function is used to disable interrupt flag accumulator event to stop PWM counting.
  */
void TPWM_DisableAccStopMode(TIMER_T *timer)
{
    timer->PWMIFA &= ~TIMER_PWMIFA_STPMOD_Msk;
}

/** @} end of group TIMER_PWM_EXPORTED_FUNCTIONS */
/** @} end of group TIMER_PWM_Driver */
/** @} end of group Standard_Driver */
