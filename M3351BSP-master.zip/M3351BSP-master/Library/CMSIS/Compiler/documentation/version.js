function writeVersionDropdown() {
};
