/******************************************************************************
 * @file     Flash.h
 * @brief    Flash header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __Flash_H__
#define __Flash_H__

#include <stdint.h>
#include "fmc.h"

/*------Define setting storage (M3351 has no separate Data Flash)---------*/
/* Reserve the last APROM page as the LED setting storage area.           */
#define NUM_DATAFLASH_PAGE      1
#define DATAFLASH_BASE_ADDR     (FMC_APROM_END - (FMC_FLASH_PAGE_SIZE * NUM_DATAFLASH_PAGE))
#define DATAFLASH_BLANK_WORD    0xFFFFFFFF
#define SETTING_MAGIC           0xA5A5A5A5   /* validity signature stored at each record's 4th word */
#define OFFSET_CHECKSUM         (-4)      // Reserved (not used on M3351)
#define OFFSET_LED_SETTING      0x000
#define LEN_LED_SETTING         0x010

typedef struct
{
    uint8_t  AP_Sync;
    uint8_t  LightingMode;
    uint16_t LED_Nums;
} FLASH1_T;
#define FLASH1_AP_SYNC_POS       0
#define FLASH1_AP_SYNC_MSK       (0xFF   << FLASH1_AP_SYNC_POS)
#define FLASH1_LIGHTING_MODE_POS 8
#define FLASH1_LIGHTING_MODE_MSK (0xFF   << FLASH1_LIGHTING_MODE_POS)
#define FLASH1_LED_NUMS_POS      16
#define FLASH1_LED_NUMS_MSK      (0xFFFF << FLASH1_LED_NUMS_POS)

typedef struct
{
    uint8_t Color_R;
    uint8_t Color_G;
    uint8_t Color_B;
    uint8_t Brightness;
} FLASH2_T;
#define FLASH2_COLOR_R_POS       0
#define FLASH2_COLOR_R_MSK       (0xFF << FLASH2_COLOR_R_POS)
#define FLASH2_COLOR_G_POS       8
#define FLASH2_COLOR_G_MSK       (0xFF << FLASH2_COLOR_G_POS)
#define FLASH2_COLOR_B_POS       16
#define FLASH2_COLOR_B_MSK       (0xFF << FLASH2_COLOR_B_POS)
#define FLASH2_BRIGHTNESS_POS    24
#define FLASH2_BRIGHTNESS_MSK    (0xFF << FLASH2_BRIGHTNESS_POS)

typedef struct
{
    uint8_t Speed;
    uint8_t Direction;
    uint8_t Reserve;
    uint8_t LED_Type;
} FLASH3_T;
#define FLASH3_SPEED_POS         0
#define FLASH3_SPEED_MSK         (0xFF << FLASH3_SPEED_POS)
#define FLASH3_DIRECTION_POS     8
#define FLASH3_DIRECTION_MSK     (0xFF << FLASH3_DIRECTION_POS)
#define FLASH3_LED_TYPE_POS      24
#define FLASH3_LED_TYPE_MSK      (0xFF << FLASH3_LED_TYPE_POS)

typedef struct
{
    uint8_t Reserve1;
    uint8_t Reserve2;
    uint8_t Reserve3;
    uint8_t Reserve4;
} FLASH4_T;

extern volatile uint8_t WriteSetting_Flag;

void ReadStoredSetting(void);
void WriteNewSetting(void);
void WriteDefaultSetting(void);

#endif  /* __Flash_H__ */

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
