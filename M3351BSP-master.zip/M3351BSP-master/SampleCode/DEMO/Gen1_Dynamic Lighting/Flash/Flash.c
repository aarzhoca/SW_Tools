/******************************************************************************//**
 * @file     Flash.c
 * @version  V1.00
 * @brief    Flash sample file
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

/*!<Includes */
#include <stdlib.h>
#include "device.h"
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "Flash.h"
#include "LED_Control.h"

volatile uint8_t WriteSetting_Flag = 0;

void ReadStoredSetting(void)
{
    uint8_t i;
    uint32_t Data_Address;
    FLASH1_T Temp1;
    FLASH2_T Temp2;
    FLASH3_T Temp3;
    FLASH4_T Temp4;

    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Enable FMC ISP function */
    FMC_Open();

    /* Get setting storage address (APROM last page) */
    Data_Address = DATAFLASH_BASE_ADDR;

    /* Read LED setting from Data Flash */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        /* A record is valid only if its signature word matches; otherwise (blank or garbage
           APROM) use defaults so bogus 0xFF/stale fields cannot disable the lighting effect */
        if(FMC_Read(Data_Address + LEN_LED_SETTING*i + 12) != SETTING_MAGIC)
        {
            LED_Mapping[i]->AP_Sync      = DEFAULT_AP_SYNC;
            LED_Mapping[i]->LEDNum       = DEFAULT_LED_NUMS;
            LED_Mapping[i]->LightingMode = DEFAULT_LIGHTING_MODE;
            LED_Mapping[i]->Color_R      = DEFAULT_COLOR_R;
            LED_Mapping[i]->Color_G      = DEFAULT_COLOR_G;
            LED_Mapping[i]->Color_B      = DEFAULT_COLOR_B;
            LED_Mapping[i]->Brightness   = DEFAULT_BRIGHTNESS;
            LED_Mapping[i]->Speed        = DEFAULT_SPEED;
            LED_Mapping[i]->Direction    = DEFAULT_DIRECTION;
            LED_Mapping[i]->LED_Type     = DEFAULT_LED_TYPE;
        }
        else
        {
            *(uint32_t *)&Temp1 = FMC_Read(Data_Address + LEN_LED_SETTING*i     );
            LED_Mapping[i]->AP_Sync      = Temp1.AP_Sync;
            LED_Mapping[i]->LEDNum       = Temp1.LED_Nums;
            LED_Mapping[i]->LightingMode = Temp1.LightingMode;
            *(uint32_t *)&Temp2 = FMC_Read(Data_Address + LEN_LED_SETTING*i +  4);
            LED_Mapping[i]->Color_R      = Temp2.Color_R;
            LED_Mapping[i]->Color_G      = Temp2.Color_G;
            LED_Mapping[i]->Color_B      = Temp2.Color_B;
            LED_Mapping[i]->Brightness   = Temp2.Brightness;
            *(uint32_t *)&Temp3 = FMC_Read(Data_Address + LEN_LED_SETTING*i +  8);
            LED_Mapping[i]->Speed        = Temp3.Speed;
            LED_Mapping[i]->Direction    = Temp3.Direction;
            LED_Mapping[i]->LED_Type     = Temp3.LED_Type;
            /* Safety clamps for stored values */
            if(LED_Mapping[i]->LightingMode >= LED_MODE_COUNT)
                LED_Mapping[i]->LightingMode = DEFAULT_LIGHTING_MODE;
            if((LED_Mapping[i]->LEDNum == 0) || (LED_Mapping[i]->LEDNum > LED_Number_Limit[i]))
                LED_Mapping[i]->LEDNum = LED_Number_Limit[i];
            if(LED_Mapping[i]->Direction != eDir_Backward)
                LED_Mapping[i]->Direction = eDir_Forward;
        }
        LED_Mapping[i]->Mode_FUNC = (LED_FUNC)Mode_Function[LED_Mapping[i]->LightingMode];
    }

    /* Lock protected registers */
    SYS_LockReg();
}

void WriteNewSetting(void)
{
    uint8_t i;
    uint32_t Data_Address;
    FLASH1_T Temp1;
    FLASH2_T Temp2;
    FLASH3_T Temp3;
    FLASH4_T Temp4;
    uint8_t target_port;

    /* Wait all LLSI and PDMA transmission done */
    while(1)
    {
        for(target_port = 0; target_port < TOTAL_LED_AREA; target_port++)
        {
            /* Check if data transmission is not done yet */
            if(LED_Mapping[target_port]->fPDMA_Done == 0)
                break;
        }

        /* Check if all LLSI and PDMA transmission is done */
        if(target_port == TOTAL_LED_AREA)
            break;
    }

    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Enable FMC ISP function and APROM update */
    FMC_Open();
    FMC_ENABLE_AP_UPDATE();

    /* Get setting storage address (APROM last page) */
    Data_Address = DATAFLASH_BASE_ADDR;

    /* Erase Current Setting */
    for(i = 0; i < NUM_DATAFLASH_PAGE; i++)
        FMC_Erase(Data_Address + FMC_FLASH_PAGE_SIZE*i);

    /* Write new setting to Data Flash. M3351 flash has ECC: each 8-byte unit
       must be programmed once with a single 64-bit write, so pack the 16-byte
       record into two FMC_Write8Bytes calls (offsets 0/4 and 8/12). */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        Temp1.AP_Sync      = LED_Mapping[i]->AP_Sync;
        Temp1.LED_Nums     = LED_Mapping[i]->LEDNum;
        Temp1.LightingMode = LED_Mapping[i]->LightingMode;
        Temp2.Color_R      = LED_Mapping[i]->Color_R;
        Temp2.Color_G      = LED_Mapping[i]->Color_G;
        Temp2.Color_B      = LED_Mapping[i]->Color_B;
        Temp2.Brightness   = LED_Mapping[i]->Brightness;
        FMC_Write8Bytes(Data_Address + LEN_LED_SETTING*i    , *(uint32_t *)&Temp1, *(uint32_t *)&Temp2);
        Temp3.Speed        = LED_Mapping[i]->Speed;
        Temp3.Direction    = LED_Mapping[i]->Direction;
        Temp3.Reserve      = 0x00;
        Temp3.LED_Type     = LED_Mapping[i]->LED_Type;
        /* Second 8-byte unit: record word 3 + validity signature */
        FMC_Write8Bytes(Data_Address + LEN_LED_SETTING*i + 8, *(uint32_t *)&Temp3, SETTING_MAGIC);
    }

    /* Disable APROM update */
    FMC_DISABLE_AP_UPDATE();

    /* Lock protected registers */
    SYS_LockReg();
}

void WriteDefaultSetting(void)
{
    uint8_t i;
    uint32_t Data_Address;
    FLASH1_T Temp1;
    FLASH2_T Temp2;
    FLASH3_T Temp3;
    FLASH4_T Temp4;

    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Enable FMC ISP function and APROM update */
    FMC_Open();
    FMC_ENABLE_AP_UPDATE();

    /* Get setting storage address (APROM last page) */
    Data_Address = DATAFLASH_BASE_ADDR;

    /* Erase the storage page before writing (ensure a clean APROM page) */
    for(i = 0; i < NUM_DATAFLASH_PAGE; i++)
        FMC_Erase(Data_Address + FMC_FLASH_PAGE_SIZE*i);

    /* Write default setting to Data Flash (64-bit writes for M3351 ECC flash). */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        Temp1.AP_Sync      = DEFAULT_AP_SYNC;
        Temp1.LED_Nums     = DEFAULT_LED_NUMS;
        Temp1.LightingMode = DEFAULT_LIGHTING_MODE;
        Temp2.Color_R      = DEFAULT_COLOR_R;
        Temp2.Color_G      = DEFAULT_COLOR_G;
        Temp2.Color_B      = DEFAULT_COLOR_B;
        Temp2.Brightness   = DEFAULT_BRIGHTNESS;
        FMC_Write8Bytes(Data_Address + LEN_LED_SETTING*i    , *(uint32_t *)&Temp1, *(uint32_t *)&Temp2);
        Temp3.Speed        = DEFAULT_SPEED;
        Temp3.Direction    = DEFAULT_DIRECTION;
        Temp3.Reserve      = 0x00;
        Temp3.LED_Type     = DEFAULT_LED_TYPE;
        /* Second 8-byte unit: record word 3 + validity signature */
        FMC_Write8Bytes(Data_Address + LEN_LED_SETTING*i + 8, *(uint32_t *)&Temp3, SETTING_MAGIC);
    }

    /* Disable APROM update */
    FMC_DISABLE_AP_UPDATE();

    /* Lock protected registers */
    SYS_LockReg();
}