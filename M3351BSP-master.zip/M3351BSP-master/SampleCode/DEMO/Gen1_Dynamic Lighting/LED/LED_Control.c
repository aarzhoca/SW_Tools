/******************************************************************************//**
 * @file     LED_Control.c
 * @version  V1.00
 * @brief    Control LED lighting effects sample file
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

/*!<Includes */
#include <stdlib.h>
#include "device.h"
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "Platform_HDIV.h"
#include "LED_Control.h"

uint32_t TimeCounterFrameUpdate = 0;
uint8_t LED_Frame_Update_flag = 0;

void * const Mode_Function[LED_MODE_COUNT] = {FUNC_Off,    FUNC_Static, FUNC_Breathing, FUNC_Strobe, FUNC_Cycling,
                                              FUNC_Random, FUNC_Music,  FUNC_Wave,      FUNC_Spring, FUNC_Water,
                                              FUNC_Rainbow};
const char Mode_String[LED_MODE_COUNT][10] = {"Off",   "Static",    "Breathing", "Strobe", "Cycling",
                                              "Random", "Music - ", "Wave",      "Spring", "Water",
                                              "Rainbow"};
const char Music_String[NUM_MUSIC_ACTION][10] = {"POP", "JAZZ", "Mixed"};

/* Initial Strip A Data Array and Setting */
__attribute__((aligned (4))) uint8_t LEDData_Strip_A[LEN_LED_STRIP_A];
__attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_A[NUM_LED_STRIP_A];    // Dynamic Lighting control
__attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_A = {0, FALSE, NUM_LED_STRIP_A, eMode_Static, 255, 0, 0, 0xFF, 0, eDir_Forward, eType_GRB,
                                                                          1, 1, 0, FUNC_Static, LEDData_Strip_A, 0, 0, 0, eMusic_POP, LEN_LED_STRIP_A,
                                                                          0, eColorRed, SEQUENCE_STRIP_A-1, 0, 0, 1, DynamicData_Strip_A};
/* Initial Strip B Data Array and Setting */
__attribute__((aligned (4))) uint8_t LEDData_Strip_B[LEN_LED_STRIP_B];
__attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_B[NUM_LED_STRIP_B];    // Dynamic Lighting control
__attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_B = {0, FALSE, NUM_LED_STRIP_B, eMode_Static, 255, 0, 0, 0xFF, 0, eDir_Forward, eType_GRB,
                                                                          1, 1, 0, FUNC_Static, LEDData_Strip_B, 0, 0, 0, eMusic_POP, LEN_LED_STRIP_B,
                                                                          0, eColorRed, SEQUENCE_STRIP_B-1, 0, 0, 1, DynamicData_Strip_B};
/* Initial Strip C Data Array and Setting */
__attribute__((aligned (4))) uint8_t LEDData_Strip_C[LEN_LED_STRIP_C];
__attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_C[NUM_LED_STRIP_C];    // Dynamic Lighting control
__attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_C = {0, FALSE, NUM_LED_STRIP_C, eMode_Static, 255, 0, 0, 0xFF, 0, eDir_Forward, eType_GRB,
                                                                          1, 1, 0, FUNC_Static, LEDData_Strip_C, 0, 0, 0, eMusic_POP, LEN_LED_STRIP_C,
                                                                          0, eColorRed, SEQUENCE_STRIP_C-1, 0, 0, 1, DynamicData_Strip_C};
/* Initial Strip D Data Array and Setting */
__attribute__((aligned (4))) uint8_t LEDData_Strip_D[LEN_LED_STRIP_D];
__attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_D[NUM_LED_STRIP_D];    // Dynamic Lighting control
__attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_D = {0, FALSE, NUM_LED_STRIP_D, eMode_Static, 255, 0, 0, 0xFF, 0, eDir_Forward, eType_GRB,
                                                                          1, 1, 0, FUNC_Static, LEDData_Strip_D, 0, 0, 0, eMusic_POP, LEN_LED_STRIP_D,
                                                                          0, eColorRed, SEQUENCE_STRIP_D-1, 0, 0, 1, DynamicData_Strip_D};
/* Mapping Table */
uint8_t *LED_Data_Array_Mapping[TOTAL_LED_AREA]        = {LEDData_Strip_A,     LEDData_Strip_B,     LEDData_Strip_C,     LEDData_Strip_D};
const uint32_t LED_Data_Array_Size[TOTAL_LED_AREA]     = {LEN_LED_STRIP_A,     LEN_LED_STRIP_B,     LEN_LED_STRIP_C,     LEN_LED_STRIP_D};
const uint16_t LED_Number_Limit[TOTAL_LED_AREA]        = {NUM_LED_STRIP_A,     NUM_LED_STRIP_B,     NUM_LED_STRIP_C,     NUM_LED_STRIP_D};
volatile LED_Setting_T *LED_Mapping[TOTAL_LED_AREA]    = {&LEDSetting_Strip_A, &LEDSetting_Strip_B, &LEDSetting_Strip_C, &LEDSetting_Strip_D};

#define BreathingArraySize 150
const uint8_t BreathingBright[BreathingArraySize]	= {  0,   0,   0,   0,   1,   1,   2,   3,   4,   5,
                                                       7,   8,  10,  11,  13,  15,  17,  19,  21,  23,
                                                      25,  28,  30,  32,  35,  37,  40,  42,  45,  47,
                                                      50,  52,  55,  57,  60,  62,  65,  67,  70,  72,
                                                      75,  77,  79,  81,  83,  85,  87,  89,  90,  92,
                                                      93,  95,  96,  97,  98,  99,  99, 100, 100, 100,
                                                     100, 100, 100, 100, 100,  99,  99,  98,  97,  96,
                                                      95,  93,  92,  90,  89,  87,  85,  83,  81,  79,
                                                      77,  75,  72,  70,  67,  65,  62,  60,  57,  55,
                                                      52,  50,  47,  45,  42,  40,  37,  34,  32,  30,
                                                      28,  25,  23,  21,  19,  17,  15,  13,  11,  10,
                                                       8,   7,   5,   4,   3,   2,   1,   1,   0,   0,
                                                       0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                                                       0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                                                       0,   0,   0,   0,   0,   0,   0,   0,   0,   0};

/* Number of LED for each mode */
#define cMeteor_LED 4

#define RainbowSize 8
const uint8_t RainbowColor[RainbowSize][3]    // (R, G, B)
              = {{255,   0,   0},   // Red
                 {255,  85,   0},   // Orange
                 {255, 255,   0},   // Yellow
                 {  0, 255,   0},   // Green
                 {  0, 127, 255},   // Cyan
                 {  0,   0, 255},   // Blue
                 {127,   0, 255},   // Indigo
                 {255,   0, 255}};  // Purple

void ARGB_Port_Initial(uint8_t port)
{
    /* Modify function for corresponding platform */
    HAL_ARGB_Port_Initial(port);
}

void PDMA_Initial(uint8_t port)
{
    /* Modify function for corresponding platform */
    HAL_PDMA_Initial(port);
}

/* Modify below IRQ handler for corresponding platform */
// void LED_IF_IRQ_STRIP_A(void);
// void LED_IF_IRQ_STRIP_B(void);
// void LED_IF_IRQ_STRIP_C(void);
// void LED_IF_IRQ_STRIP_D(void);

void Set_Single(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t Data_R, uint8_t Data_G, uint8_t Data_B)
{
    uint32_t i;

    for(i = 0; i < TotalLED; i++)
    {
        *(LED_DATA + Offset + i*3 + 0) = Data_R;
        *(LED_DATA + Offset + i*3 + 1) = Data_G;
        *(LED_DATA + Offset + i*3 + 2) = Data_B;
    }
}

void Set_Array(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright)
{
    uint32_t i;
    uint8_t TempR, TempG, TempB;

    for(i = 0; i < TotalLED; i++)
    {
        TempR = HDIV_Div(*(DisplayData + i*3 + 0) * MaxBright, 0xFF);
        TempG = HDIV_Div(*(DisplayData + i*3 + 1) * MaxBright, 0xFF);
        TempB = HDIV_Div(*(DisplayData + i*3 + 2) * MaxBright, 0xFF);
        *(LED_DATA + Offset + i*3 + 0) = TempR;
        *(LED_DATA + Offset + i*3 + 1) = TempG;
        *(LED_DATA + Offset + i*3 + 2) = TempB;
    }
}

void Set_InverseArray(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright)
{
    uint32_t i, j;
    uint8_t TempR, TempG, TempB;

    for(i = 0, j = TotalLED-1; i < TotalLED; i++, j--)
    {
        TempR = HDIV_Div(*(DisplayData + j*3 + 0) * MaxBright, 0xFF);
        TempG = HDIV_Div(*(DisplayData + j*3 + 1) * MaxBright, 0xFF);
        TempB = HDIV_Div(*(DisplayData + j*3 + 2) * MaxBright, 0xFF);
        *(LED_DATA + Offset + i*3 + 0) = TempR;
        *(LED_DATA + Offset + i*3 + 1) = TempG;
        *(LED_DATA + Offset + i*3 + 2) = TempB;
    }
}

void Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting)
{
    /* Modify function for corresponding platform */
    HAL_Set_LED_Data(LED_Setting);
}

void Clear_LED_Data(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t i, j;

    for(i = 0; i < LED_Setting->Array_Size; i++)
    {
        LED_Setting->LED_Data[i] = 0x0;
    }

    /* Set data */
    Set_LED_Data(LED_Setting);
}

/*------Lighting Mode-----------------------------------------*/
void FUNC_Off(volatile struct LED_Setting_Tag* LED_Setting)
{
    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, 0, 0, 0);
}

void FUNC_Static(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t TempR, TempG, TempB;

    /* Calculate Color */
    TempR = HDIV_Div((LED_Setting->Color_R * LED_Setting->Brightness), 0xFF);
    TempG = HDIV_Div((LED_Setting->Color_G * LED_Setting->Brightness), 0xFF);
    TempB = HDIV_Div((LED_Setting->Color_B * LED_Setting->Brightness), 0xFF);

    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, TempR, TempG, TempB);
}

void FUNC_Breathing(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t Temp, TempR, TempG, TempB;

    /* Calculate Color */
    Temp = HDIV_Mod(HDIV_Div(LED_Setting->TimeCounter, 8 + HDIV_Div(LED_Setting->Speed, 10)), BreathingArraySize);
    TempR = HDIV_Div((LED_Setting->Color_R * LED_Setting->Brightness * *(BreathingBright + Temp)), 0xFF*100);
    TempG = HDIV_Div((LED_Setting->Color_G * LED_Setting->Brightness * *(BreathingBright + Temp)), 0xFF*100);
    TempB = HDIV_Div((LED_Setting->Color_B * LED_Setting->Brightness * *(BreathingBright + Temp)), 0xFF*100);

    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, TempR, TempG, TempB);

    /* Reset CountingTime */
    if(LED_Setting->TimeCounter >= ((8 + HDIV_Div(LED_Setting->Speed, 10)) * BreathingArraySize))
    {
        LED_Setting->TimeCounter -= (8 + HDIV_Div(LED_Setting->Speed, 10)) * BreathingArraySize;
    }
}

void FUNC_Strobe(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t TempR, TempG, TempB;

    /* Reset CountingTime */
    while(LED_Setting->TimeCounter >= (((5 * LED_Setting->Speed) + 275) * 2))
    {
        LED_Setting->TimeCounter -= (((5 * LED_Setting->Speed) + 275) * 2);
    }

    /* Extinguish */
    if(LED_Setting->TimeCounter < ((5 * LED_Setting->Speed) + 275))
    {
        /* Mapping Color to LED Format */
        Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, 0, 0, 0);
    }
    /* Lighten */
    else
    {
        /* Calculate Color */
        TempR = HDIV_Div((LED_Setting->Color_R * LED_Setting->Brightness), 0xFF);
        TempG = HDIV_Div((LED_Setting->Color_G * LED_Setting->Brightness), 0xFF);
        TempB = HDIV_Div((LED_Setting->Color_B * LED_Setting->Brightness), 0xFF);

        /* Mapping Color to LED Format */
        Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, TempR, TempG, TempB);
    }
}

void FUNC_Cycling(volatile struct LED_Setting_Tag* LED_Setting)
{
    /* Reset CountingTime */
    if (LED_Setting->TimeCounter >= (500 + LED_Setting->Speed*10))
    {
        LED_Setting->TimeCounter -= (500 + LED_Setting->Speed*10);
        
        /* Switch to next color state. */
        if(LED_Setting->ColorIndex == eColorRed)
        {
            LED_Setting->ColorIndex = eColorGreen;
        }
        else if(LED_Setting->ColorIndex == eColorGreen)
        {
            LED_Setting->ColorIndex = eColorBlue;
        }
        else if(LED_Setting->ColorIndex == eColorBlue)
        {
            LED_Setting->ColorIndex = eColorRed;
        }
    }
    
    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][0] * LED_Setting->Brightness), 0xFF), \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][1] * LED_Setting->Brightness), 0xFF), \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][2] * LED_Setting->Brightness), 0xFF));
}

void FUNC_Random(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint8_t temp;

    /* Reset CountingTime */
    if (LED_Setting->TimeCounter >= (500 + LED_Setting->Speed*10))
    {
        LED_Setting->TimeCounter -= (500 + LED_Setting->Speed*10);
        
        /* Calculate next random color state. */
        /* If next state is same as current state, random again. */
        do
        {
            temp = ((RainbowSize * (rand() % 1024)) / 1024);
        } while(temp == LED_Setting->ColorIndex);
        /* Set next color state index. */
        LED_Setting->ColorIndex = temp;
    }

    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][0] * LED_Setting->Brightness), 0xFF), \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][1] * LED_Setting->Brightness), 0xFF), \
               HDIV_Div((RainbowColor[LED_Setting->ColorIndex][2] * LED_Setting->Brightness), 0xFF));
}

void FUNC_Music(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t i, j;
    uint8_t POP_Color[3] = {0};
    uint32_t Unit_Volume = HDIV_Div((LED_Setting->Main_Volume * LED_Setting->LEDNum), 100);
    uint8_t JAZZ_Display[LED_Setting->LEDNum][3];

    /* Init Array */
    for(j = 0; j < LED_Setting->LEDNum; j++)
    {
        for(i = 0; i < 3; i++)
            JAZZ_Display[j][i] = 0;
    }

    /* POP */
    if(LED_Setting->Music_Action == eMusic_POP)
    {
        for(i = 0; i < 3; i++)
        {
            POP_Color[i] = HDIV_Div(RainbowColor[eColorBlue][i] * (100 - LED_Setting->Main_Volume), 100)\
                           + HDIV_Div(RainbowColor[eColorRed][i] * LED_Setting->Main_Volume, 100);
        }

        /* Mapping Color to LED Format */
        Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, \
                   HDIV_Div((POP_Color[0] * LED_Setting->Brightness), 0xFF), \
                   HDIV_Div((POP_Color[1] * LED_Setting->Brightness), 0xFF), \
                   HDIV_Div((POP_Color[2] * LED_Setting->Brightness), 0xFF));
    }
    /* JAZZ */
    else if(LED_Setting->Music_Action == eMusic_JAZZ)
    {
        for(j = 0; j < Unit_Volume; j++)
        {
            for(i = 0; i < 3; i++)
            {
                JAZZ_Display[j][i] = *(&LED_Setting->Color_R + i);
            }
        }

        /* Mapping Color to LED Format */
        /* Direction forward or backward */
        if(LED_Setting->Direction == eDir_Forward)
            Set_Array(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)JAZZ_Display, LED_Setting->Brightness);
        else if(LED_Setting->Direction == eDir_Backward)
            Set_InverseArray(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)JAZZ_Display, LED_Setting->Brightness);
    }
    /* Mixed */
    else if (LED_Setting->Music_Action == eMusic_Mixed)
    {
        for(i = 0; i < 3; i++)
        {
            POP_Color[i] = HDIV_Div(RainbowColor[eColorBlue][i] * (100 - LED_Setting->Main_Volume), 100)\
                           + HDIV_Div(RainbowColor[eColorRed][i] * LED_Setting->Main_Volume, 100);
        }

        for(j = 0; j < Unit_Volume; j++)
        {
            for(i = 0; i < 3; i++)
            {
                JAZZ_Display[j][i] = POP_Color[i];
            }
        }

        /* Mapping Color to LED Format */
        /* Direction forward or backward */
        if(LED_Setting->Direction == eDir_Forward)
            Set_Array(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)JAZZ_Display, LED_Setting->Brightness);
        else if(LED_Setting->Direction == eDir_Backward)
            Set_InverseArray(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)JAZZ_Display, LED_Setting->Brightness);
    }
}

void FUNC_Wave(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t i;
    uint32_t DeltaT = 800 + LED_Setting->Speed*4;
    uint32_t CurrentTime;
    uint8_t Color1[3];
    uint8_t Color2[3];
    uint8_t DisplayColor[3];
    uint32_t Temp;

    if(LED_Setting->Direction == eDir_Forward)
    {
        /* Take Color1 and Color2 from Rainbow array by TimeCounter */
        Temp = HDIV_Mod(HDIV_Div(LED_Setting->TimeCounter, DeltaT), RainbowSize);
        for(i = 0; i < 3; i++)
        {
            /* Set Color1 */
            Color1[i] = RainbowColor[Temp][i];
            /* Set Color2 */
            Color2[i] = RainbowColor[HDIV_Mod((Temp+1), RainbowSize)][i];
        }
    }
    else if(LED_Setting->Direction == eDir_Backward)
    {
        /* Take Color1 and Color2 from Rainbow array by TimeCounter */
        Temp = HDIV_Mod(HDIV_Div(LED_Setting->TimeCounter, DeltaT), RainbowSize);
        for(i = 0; i < 3; i++)
        {
            /* Set Color1 */
            Color1[i] = RainbowColor[RainbowSize - 1 - Temp][i];
            /* Set Color2 */
            Color2[i] = RainbowColor[HDIV_Mod((RainbowSize + RainbowSize - 2 - Temp), RainbowSize)][i];
        }
    }

    /* Reset CountingTime */
    if(LED_Setting->TimeCounter >= (DeltaT * RainbowSize))
    {
        LED_Setting->TimeCounter -= (DeltaT * RainbowSize);
    }

    /* Judge current time and set mixed Displaycolor by color1 and color2 */
    CurrentTime = HDIV_Mod(LED_Setting->TimeCounter, DeltaT);
    for(i = 0; i < 3; i++)
    {
        DisplayColor[i] = HDIV_Div(Color1[i] * (DeltaT - CurrentTime), DeltaT) + HDIV_Div(Color2[i] * CurrentTime, DeltaT);
        DisplayColor[i] = HDIV_Div(DisplayColor[i] * LED_Setting->Brightness, 0xFF);
    }

    /* Mapping Color to LED Format */
    Set_Single(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, DisplayColor[0], DisplayColor[1], DisplayColor[2]);
}

void FUNC_Spring(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint8_t DisplayColor[LED_Setting->LEDNum+2*cMeteor_LED][3];
    uint8_t Color[cMeteor_LED][3];
    uint32_t i, j;
    uint32_t Duration;
    uint32_t Loop, DeltaT, DelayT;
    uint32_t TempColor;

    /* Init Array */
    for(j = 0; j < LED_Setting->LEDNum+2*cMeteor_LED; j++)
    {
        for(i = 0; i < 3; i++)
            DisplayColor[j][i] = 0;
    }

    /* DeltaT is unit time */
    DeltaT = 5 + HDIV_Div(LED_Setting->Speed, 20);
    /* Duration is one time pass through */
    Duration = DeltaT * (LED_Setting->LEDNum + cMeteor_LED * 2);
    /* DelayT is delay on two ends */
    DelayT = HDIV_Div(LED_Setting->LEDNum * DeltaT, 2);
    /* Reset CountingTime */
    if(LED_Setting->TimeCounter >= (2 * (Duration + DelayT)))
    {
        LED_Setting->TimeCounter -= 2 * (Duration + DelayT);
    }

    /* Forward */
    if(LED_Setting->TimeCounter < Duration)
    {
        /* Loop to indicate which LED for first Color */
        Loop = HDIV_Div(LED_Setting->TimeCounter, DeltaT);

        for(i = 0; i < 3; i++)
        {
            TempColor = *(&LED_Setting->Color_R + i);

            /* 1st 100%*/
            Color[0][i] = TempColor;
            /* 2nd 75% */
            Color[1][i] = (TempColor * 3) >> 2;
            /* 3rd 50% */
            Color[2][i] = TempColor >> 1;
            /* 4th 25% */
            Color[3][i] = TempColor >> 2;
        }

        for(j = Loop; j < (Loop + cMeteor_LED); j++)
        {
            for(i = 0; i < 3; i++)
                DisplayColor[j][i] = Color[j - Loop][i];
        }
    }
    /* All Extinguish */
    else if(LED_Setting->TimeCounter < (Duration + DelayT) )
    {
        for(j = 0; j < LED_Setting->LEDNum+2*cMeteor_LED; j++)
        {
            for(i = 0; i < 3; i++)
                DisplayColor[j][i] = 0;
        }
    }
    else if(LED_Setting->TimeCounter < (2*Duration + DelayT))
    {
        /* Loop to indicate which LED for first Color */
        Loop = HDIV_Div(LED_Setting->TimeCounter - (Duration + DelayT), DeltaT);

        for(i = 0; i < 3; i++)
        {
            TempColor = *(&LED_Setting->Color_R + i);

            /* 1st 25%*/
            Color[0][i] = TempColor >> 2;
            /* 2nd 50% */
            Color[1][i] = TempColor >> 1;
            /* 3rd 75% */
            Color[2][i] = (TempColor * 3) >> 2;
            /* 4th 100% */
            Color[3][i] = TempColor;
        }

        for(j = (LED_Setting->LEDNum + cMeteor_LED - Loop); j < (LED_Setting->LEDNum + cMeteor_LED - Loop + cMeteor_LED); j++)
        {
            for(i = 0; i < 3; i++)
                DisplayColor[j][i] = Color[j - (LED_Setting->LEDNum + cMeteor_LED - Loop)][i];
        }
    }
    /* All Extinguish */
    else
    {
        for(j = 0; j < LED_Setting->LEDNum+2*cMeteor_LED; j++)
        {
            for(i = 0; i < 3; i++)
                DisplayColor[j][i] = 0;
        }
    }

    /* Mapping Color to LED Format */
    /* Direction forward or backward */
    if(LED_Setting->Direction == eDir_Forward)
        Set_Array(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)(DisplayColor+cMeteor_LED), LED_Setting->Brightness);
    else if(LED_Setting->Direction == eDir_Backward)
        Set_InverseArray(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)(DisplayColor+cMeteor_LED), LED_Setting->Brightness);
}

void FUNC_Water(volatile struct LED_Setting_Tag* LED_Setting)
{
    const uint8_t Brightness[4] = {100, 15, 5, 15};
    const uint8_t MeteorNum = 4;
    uint32_t i, j;
    uint32_t Cursor;
    uint8_t DisplayColor[LED_Setting->LEDNum][3], Color[3];
    uint32_t MotionPeriod, TimeInPhase, PhasePeriod;

    PhasePeriod = 1000 + LED_Setting->Speed * 4;
    MotionPeriod = HDIV_Div(PhasePeriod, 8);
    TimeInPhase = HDIV_Mod(LED_Setting->TimeCounter, PhasePeriod);
    
    /* Reset CountingTime */
    if (LED_Setting->TimeCounter >= PhasePeriod)
    {
        LED_Setting->TimeCounter -= PhasePeriod;

        /* If color index is overflow, reset color index. */    
        LED_Setting->ColorIndex = (LED_Setting->ColorIndex >= (RainbowSize - 1)) ? eColorRed : (LED_Setting->ColorIndex + 1);
    }

    /* Set Mixed Color = Color1 + Color2 */
    for(i = 0; i < 3; i++)
    {
        Color[i] = HDIV_Div(RainbowColor[LED_Setting->ColorIndex][i] * (PhasePeriod - TimeInPhase), PhasePeriod)\
                + HDIV_Div(RainbowColor[HDIV_Mod((LED_Setting->ColorIndex + 1), RainbowSize)][i] * TimeInPhase, PhasePeriod);
    }
    
    /* Calculate the cursor for moving the Brightness */
    Cursor = HDIV_Mod(HDIV_Div(LED_Setting->TimeCounter, MotionPeriod), MeteorNum);

    /* Sets the Light Bar array and modified the brightness for meteor effect. */
    for(j = 0; j < LED_Setting->LEDNum; j++)
    {
        for(i = 0; i< 3; i++)
        { 
            DisplayColor[j][i] = HDIV_Div(Color[i] * Brightness[HDIV_Mod((Cursor + j), MeteorNum)], 100);
        }
    }

    /* Mapping Color to LED Format */
    /* Direction forward or backward */
    if(LED_Setting->Direction == eDir_Forward)
        Set_InverseArray(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)DisplayColor, LED_Setting->Brightness);
    else if(LED_Setting->Direction == eDir_Backward)
        Set_Array(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)DisplayColor, LED_Setting->Brightness);
}

void FUNC_Rainbow(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint8_t DisplayColor[LED_Setting->LEDNum][3];
    uint32_t i, j;
    uint32_t deltaT, TotalDuration, CurrentTime, NextTime;
    uint8_t ColorCursor1, ColorCursor2;

    /* Init Array */
    for(j = 0; j < LED_Setting->LEDNum; j++)
    {
        for(i = 0; i < 3; i++)
            DisplayColor[j][i] = 0;
    }

    /* Duration for one time effect */
    TotalDuration = HDIV_Div(60 * 1000, HDIV_Div(255 - LED_Setting->Speed, 3) + 5);
    /* Next LED time */
    NextTime = HDIV_Div(TotalDuration, 60);
    /* Current Time */
    CurrentTime = HDIV_Mod(LED_Setting->TimeCounter, TotalDuration);
    /* Unit time for each color */
    deltaT = HDIV_Div(TotalDuration, RainbowSize);

    /* Reset CountingTime */
    if(LED_Setting->TimeCounter >= TotalDuration)
    {
        LED_Setting->TimeCounter -= TotalDuration;
    }

    /* Mix Color */
    for(j = 0; j < LED_Setting->LEDNum; j++, CurrentTime += NextTime)
    {
        if(CurrentTime >= TotalDuration)
            CurrentTime -= TotalDuration;

        if(CurrentTime >= (deltaT * RainbowSize))
        {
            /* Color Cursor */
            ColorCursor1 = 0;
            ColorCursor2 = 1;

            for(i = 0; i < 3; i++)
            {
                DisplayColor[LED_Setting->LEDNum-j-1][i] = RainbowColor[ColorCursor1][i];
            }
        }
        else
        {
            /* Color Cursor */
            ColorCursor1 = HDIV_Mod(HDIV_Div(CurrentTime, deltaT), RainbowSize);
            ColorCursor2 = HDIV_Mod((ColorCursor1 + 1), RainbowSize);

            for(i = 0; i < 3; i++)
            {
                DisplayColor[LED_Setting->LEDNum-j-1][i] = HDIV_Div(((RainbowColor[ColorCursor1][i] * ((ColorCursor1 + 1) * deltaT - CurrentTime)) + \
                                                           (RainbowColor[ColorCursor2][i] * (CurrentTime - ColorCursor1 * deltaT))), deltaT);
            }
        }
    }

    /* Mapping Color to LED Format */
    /* Direction forward or backward */
    if(LED_Setting->Direction == eDir_Forward)
        Set_Array(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)DisplayColor, LED_Setting->Brightness);
    else if(LED_Setting->Direction == eDir_Backward)
        Set_InverseArray(LED_Setting->LED_Data, LED_Setting->LEDNum, LED_Setting->LED_Offset, (uint8_t *)DisplayColor, LED_Setting->Brightness);
}
