/******************************************************************************
 * @file     LED_Control.h
 * @brief    Control LED lighting effects header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __LED_Control_H__
#define __LED_Control_H__

#include <stdint.h>
#include "device.h"
#include "Dynamic_Lighting.h"

/*------ARGB LED Specification--------------------------------*/
#define ARGB_LED_PERIOD_NANOSECOND    1200
#define ARGB_LED_T0H_NANOSECOND       300
#define ARGB_LED_T1H_NANOSECOND       900
#define ARGB_LED_RESET_NANOSECOND     250000

/*------Lighting Control--------------------------------------*/
extern uint32_t TimeCounterFrameUpdate;
extern uint8_t LED_Frame_Update_flag;
#define TIMER_FRAME_UPDATE 25
#define LED_MODE_COUNT     11
extern void * const Mode_Function[LED_MODE_COUNT];
extern const char Mode_String[LED_MODE_COUNT][10];
#define NUM_MUSIC_ACTION   3
extern const char Music_String[NUM_MUSIC_ACTION][10];

/*------LED Setting-------------------------------------------*/
struct LED_Setting_Tag;
typedef void (*LED_FUNC)(volatile struct LED_Setting_Tag* LED_Setting);
typedef struct LED_Setting_Tag
{
    uint32_t  TimeCounter;
    uint8_t   AP_Sync;
    uint16_t  LEDNum;
    uint8_t   LightingMode;
    uint8_t   Color_R;
    uint8_t   Color_G;
    uint8_t   Color_B;
    uint8_t   Brightness;
    uint8_t   Speed;
    uint8_t   Direction;
    uint8_t   LED_Type;
    uint8_t   fPDMA_Done;
    uint8_t   RandomFlag;
    uint32_t  Random;
    LED_FUNC  Mode_FUNC;
    uint8_t*  LED_Data;
    uint8_t   Main_Volume;
    uint8_t   Left_Volume;
    uint8_t   Right_Volume;
    uint8_t   Music_Action;
    uint32_t  Array_Size;
    uint16_t  LED_Offset;
    uint8_t   ColorIndex;
    uint8_t   Sequence;
    /* Dynamic Lighting */
    uint8_t   Dynamic_Update_Flag;
    uint16_t  Target_LampID;
    uint8_t   Autonomous_Flag;
    Lamp_RGBI_T*  DynamicData;
} LED_Setting_T;
#define MAX_LEVEL_COLOR_R             255
#define MAX_LEVEL_COLOR_G             255
#define MAX_LEVEL_COLOR_B             255
#define MAX_LEVEL_COLOR_BRIGHTNESS    255
/* Strip A */
#define LEN_LED_STRIP_A (NUM_LED_STRIP_A*3)
extern __attribute__((aligned (4))) uint8_t LEDData_Strip_A[LEN_LED_STRIP_A];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_A[NUM_LED_STRIP_A];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_A;
/* Strip B */
#define LEN_LED_STRIP_B (NUM_LED_STRIP_B*3)
extern __attribute__((aligned (4))) uint8_t LEDData_Strip_B[LEN_LED_STRIP_B];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_B[NUM_LED_STRIP_B];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_B;
/* Strip C */
#define LEN_LED_STRIP_C (NUM_LED_STRIP_C*3)
extern __attribute__((aligned (4))) uint8_t LEDData_Strip_C[LEN_LED_STRIP_C];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_C[NUM_LED_STRIP_C];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_C;
/* Strip D */
#define LEN_LED_STRIP_D (NUM_LED_STRIP_D*3)
extern __attribute__((aligned (4))) uint8_t LEDDataStrip_D[LEN_LED_STRIP_D];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_D[NUM_LED_STRIP_D];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_D;
/* Mapping Table */
extern uint8_t *LED_Data_Array_Mapping[TOTAL_LED_AREA];
extern const uint32_t LED_Data_Array_Size[TOTAL_LED_AREA];
extern const uint16_t LED_Number_Limit[TOTAL_LED_AREA];
extern volatile LED_Setting_T *LED_Mapping[TOTAL_LED_AREA];

/*------Setting Options---------------------------------------*/
enum eLightingMode
{
    eMode_Off       = 0x00,
    eMode_Static    = 0x01,
    eMode_Breathing = 0x02,
    eMode_Strobe    = 0x03,
    eMode_Cycling   = 0x04,
    eMode_Random    = 0x05,
    eMode_Music     = 0x06,
    eMode_Wave      = 0x07,
    eMode_Spring    = 0x08,
    eMode_Water     = 0x09,
    eMode_Rainbow   = 0x0A,
};

enum eDirection
{
    eDir_Forward  = 0x00,
    eDir_Backward = 0x01,
};

enum eMusicAction
{
    eMusic_POP   = 0x01,
    eMusic_JAZZ  = 0x02,
    eMusic_Mixed = 0x03,
};

enum eLEDType
{
    eType_GRB = 0x00,
    eType_RGB = 0x01,
};

enum eColorTable
{
    eColorRed    = 0,
    eColorOrange = 1,
    eColorYellow = 2,
    eColorGreen  = 3,
    eColorCyan   = 4,
    eColorBlue   = 5,
    eColorIndigo = 6,
    eColorPurple = 7,
};

/*------Default Setting---------------------------------------*/
#define DEFAULT_AP_SYNC       FALSE
#define DEFAULT_LED_NUMS      NUM_STRIP_LED_EVB
#define DEFAULT_LIGHTING_MODE eMode_Rainbow
#define DEFAULT_COLOR_R       255
#define DEFAULT_COLOR_G       0
#define DEFAULT_COLOR_B       0
#define DEFAULT_BRIGHTNESS    255
#define DEFAULT_SPEED         215
#define DEFAULT_DIRECTION     eDir_Forward
#define DEFAULT_LED_TYPE      eType_GRB

/*------LED Control Function----------------------------------*/
void ARGB_Port_Initial(uint8_t port);
void PDMA_Initial(uint8_t port);
void Set_Single(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t Data_R, uint8_t Data_G, uint8_t Data_B);
void Set_Array(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright);
void Set_InverseArray(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright);
void Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);
void Clear_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);

/*------Lighting Mode-----------------------------------------*/
void FUNC_Off(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Static(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Breathing(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Cycling(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Random(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Strobe(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Music(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Wave(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Spring(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Water(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Rainbow(volatile struct LED_Setting_Tag* LED_Setting);

#endif  /* __LED_Control_H__ */

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
