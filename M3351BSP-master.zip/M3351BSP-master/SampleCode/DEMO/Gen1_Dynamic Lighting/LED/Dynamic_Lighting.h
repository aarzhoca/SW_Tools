/******************************************************************************
 * @file     Dynamic_Lighting.h
 * @brief    Microsoft Dynamic Lighting control header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __DYNAMIC_LIGHTING_H__
#define __DYNAMIC_LIGHTING_H__

#include <stdint.h>

struct LED_Setting_Tag;

/* Dynamic Lighting control */
#define REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES            0x10    // Get Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST          0x11    // Set Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE         0x12    // Get Report
#define REPORT_ID_FEATURE_LAMP_MULTIUPDATE                0x13    // Set Report
#define REPORT_ID_FEATURE_LAMP_RANGEUPDATE                0x14    // Set Report
#define REPORT_ID_FEATURE_LAMPARRAY_CONTROL               0x15    // Set Report
#define REPORT_ID_FEATURE_LAMP_TOTAL                      6
#define REPORT_ID_FEATURE_LAMP_OFFSET                     0x10

/* Dynamic Lighting Report Size */
#define LAMPARRAY_ATTRIBUTES_REPORT_SIZE                  23    // Get Report
#define LAMP_ATTRIBUTESREQUEST_REPORT_SIZE                3     // Set Report
#define LAMP_ATTRIBUTESRESPONSE_REPORT_SIZE               29    // Get Report
#define LAMP_MULTIUPDATE_REPORT_SIZE                      51    // Set Report
#define LAMP_RANGEUPDATE_REPORT_SIZE                      10    // Set Report
#define LAMPARRAY_CONTROL_REPORT_SIZE                     2     // Set Report

/* Dynamic Lighting: LampArrayAttributes */
#define LAMPARRAYATTRIBUTES_USAGECOUNT    5
enum {
    Index_BoundingBoxWidth  =    0,
    Index_BoundingBoxHeight =    1,
    Index_BoundingBoxDepth  =    2,
    Index_LampArrayKind     =    3,
    Index_MinUpdateInterval =    4,
};

/* Dynamic Lighting: LampAttributesResponse */
#define LAMPATTRIBUTESRESPONSE_USAGECOUNT 5
enum {
    PositionXInMicrometers  =    0,
    PositionYInMicrometers  =    1,
    PositionZInMicrometers  =    2,
    Index_UpdateLatency     =    3,
    Index_LampPurposes      =    4,
};

/* LampArrayKind */
#define LAMPARRAYKIND_UNDEFINED              0x00
#define LAMPARRAYKIND_KEYBOARD               0x01    // Keyboard/Keypad
#define LAMPARRAYKIND_MOUSE                  0x02    // Mouse
#define LAMPARRAYKIND_GAMECONTROLLER         0x03    // Gamepad, Flightstick, Sailing simulation device
#define LAMPARRAYKIND_PERIPHERAL             0x04    // Speakers, Mousepad, Microphone, Webcam
#define LAMPARRAYKIND_SCENE                  0x05    // Room light-bulbs, Spotlights, Washlights, Strobelights, Booth-strips, Billboard/Sign, Camera-flash
#define LAMPARRAYKIND_NOTIFICATION           0x06    // Notification device
#define LAMPARRAYKIND_CHASSIS                0x07    // RAM-stick, Motherboard, Fan
#define LAMPARRAYKIND_WEARABLE               0x08    // Audio-headset, Wristband, Watch, Shoes
#define LAMPARRAYKIND_FURNITURE              0x09    // Chair, Desk, Bookcase
#define LAMPARRAYKIND_ART                    0x0A    // Painting, Sculpture

/* LampPurpose Flags */
#define LAMPPURPOSE_CONTROL                  0x01    // Button/Key/Slider
#define LAMPPURPOSE_ACCENT                   0x02    // Case fan LED, Illuminated side panels on a keyboard
#define LAMPPURPOSE_BRANDING                 0x04    // Manufacturer logo
#define LAMPPURPOSE_STATUS                   0x08    // Unread email, CPU temperature
#define LAMPPURPOSE_ILLUMINATION             0x10    // Stage spotlight, Car headlights, Camera flash
#define LAMPPURPOSE_PRESENTATION             0x20    // Within an artwork or costume

typedef struct Lamp_RGBI_Tag
{
    uint8_t RedUpdate;
    uint8_t GreenUpdate;
    uint8_t BlueUpdate;
    uint8_t IntensityUpdate;
} Lamp_RGBI_T;

#endif  /* __DYNAMIC_LIGHTING_H__ */

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
