/******************************************************************************
 * @file     Platform_HAL.h
 * @brief    Platform HAL Include file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __PLATFORM_HAL_H
#define __PLATFORM_HAL_H

#include "Platform_HAL_NUC1262.h"

#endif  /* __PLATFORM_HAL_H */
