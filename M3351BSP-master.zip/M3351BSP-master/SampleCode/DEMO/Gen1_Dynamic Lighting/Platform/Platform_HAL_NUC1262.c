/******************************************************************************//**
 * @file     Platform_HAL_NUC1262.c
 * @version  V1.00
 * @brief    HAL driver for platform NUC1262 sample file
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

 /*!<Includes */
#include "device.h"
#include "Platform_HAL_NUC1262.h"
#include "NuMicro.h"
#include "Platform_HDIV.h"

/* Mapping Table */
volatile LLSI_T *LED_IF_Port_Mapping[TOTAL_LED_AREA] = {LED_IF_MODULE_STRIP_A, LED_IF_MODULE_STRIP_B, LED_IF_MODULE_STRIP_C, LED_IF_MODULE_STRIP_D};

/* LED control port I/O MFP setting table */
const LED_IO_SETTING LED_IO_Setting[TOTAL_LED_AREA] =
{
    {IO_MFP_REG_STRIP_A, IO_MFP_MSK_STRIP_A, IO_MFP_VAL_STRIP_A},
    {IO_MFP_REG_STRIP_B, IO_MFP_MSK_STRIP_B, IO_MFP_VAL_STRIP_B},
    {IO_MFP_REG_STRIP_C, IO_MFP_MSK_STRIP_C, IO_MFP_VAL_STRIP_C},
    {IO_MFP_REG_STRIP_D, IO_MFP_MSK_STRIP_D, IO_MFP_VAL_STRIP_D},
};
const LED_MODULE_SETTING LED_Module_Setting[TOTAL_LED_AREA] =
{
    {CLK_MODULE_STRIP_A, LED_IF_NUM_STRIP_A, PDMA_CH_STRIP_A},
    {CLK_MODULE_STRIP_B, LED_IF_NUM_STRIP_B, PDMA_CH_STRIP_B},
    {CLK_MODULE_STRIP_C, LED_IF_NUM_STRIP_C, PDMA_CH_STRIP_C},
    {CLK_MODULE_STRIP_D, LED_IF_NUM_STRIP_D, PDMA_CH_STRIP_D},
};

void HAL_ARGB_Port_Initial(uint8_t port)
{
    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Enable LLSI module clock */
    CLK_EnableModuleClock(LED_Module_Setting[port].CLK_Module);

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init I/O Multi-function                                                                                 */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Set LLSI multi-function pin (M3351 GPx_MFP0~3 format) */
    *(LED_IO_Setting[port].MFP_Reg) = (*(LED_IO_Setting[port].MFP_Reg) & ~LED_IO_Setting[port].MFP_Msk) | LED_IO_Setting[port].MFP_Val;

    /* Set LLSI output pin to high slew rate for fast ARGB (WS2812) edges */
    switch(port)
    {
        case 0: GPIO_SetSlewCtl(PA, BIT3, GPIO_SLEWCTL_HIGH); break;    /* Strip A: PA3 */
        case 1: GPIO_SetSlewCtl(PC, BIT2, GPIO_SLEWCTL_HIGH); break;    /* Strip B: PC2 */
        case 2: GPIO_SetSlewCtl(PC, BIT5, GPIO_SLEWCTL_HIGH); break;    /* Strip C: PC5 */
        case 3: GPIO_SetSlewCtl(PB, BIT4, GPIO_SLEWCTL_HIGH); break;    /* Strip D: PB4 */
        default: break;
    }

    /* Set LLSI configuration */
    LLSI_Open((LED_IF_T *)LED_IF_Port_Mapping[port], LLSI_MODE_SW,
              LLSI_FORMAT_GRB, HCLK_CLK, ARGB_LED_PERIOD_NANOSECOND, ARGB_LED_T0H_NANOSECOND, ARGB_LED_T1H_NANOSECOND, ARGB_LED_RESET_NANOSECOND,
              LED_Number_Limit[port], LLSI_IDLE_LOW);

    /* Set LLSI RGB format */
    if(LED_Mapping[port]->LED_Type == eType_RGB)
        LLSI_SET_RGB_FORMAT((LLSI_T *)LED_IF_Port_Mapping[port]);

    /* Enable reset command function */
    LLSI_ENABLE_RESET_COMMAND((LLSI_T *)LED_IF_Port_Mapping[port]);

    /* Enable Reset command interrupt */
    LLSI_EnableInt((LLSI_T *)LED_IF_Port_Mapping[port], LLSI_RSTC_INT_MASK);

    /* Enable LLSI controller (M3351 LLSI_Open does not enable it) */
    LLSI_ENABLE((LLSI_T *)LED_IF_Port_Mapping[port]);

    /* Enable NVIC for LLSI */
    NVIC_EnableIRQ((IRQn_Type)(LLSI0_IRQn + LED_Module_Setting[port].Module_Num));
    /* Change interrupt priority to normal */
    NVIC_SetPriority((IRQn_Type)(LLSI0_IRQn + LED_Module_Setting[port].Module_Num), INT_PRIORITY_HIGH);

    /* Lock protected registers */
    SYS_LockReg();
}

void HAL_PDMA_Initial(uint8_t port)
{
    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Open Channel */
    PDMA_Open(PDMA0, 1 << LED_Module_Setting[port].PDMA_Num);

    /* PDMA Setting for LLSI */
    /* Transfer type is single transfer */
    PDMA_SetBurstType(PDMA0, LED_Module_Setting[port].PDMA_Num, PDMA_REQ_SINGLE, 0);

    /* Set source address, destination address */
    PDMA_SetTransferAddr(PDMA0, LED_Module_Setting[port].PDMA_Num, (uint32_t)LED_Mapping[port]->LED_Data, PDMA_SAR_INC, (uint32_t)&(LED_IF_Port_Mapping[port]->DATA), PDMA_DAR_FIX);

    /* Lock protected registers */
    SYS_LockReg();
}

void LED_IF_IRQ_STRIP_A(void)
{
    if(!LEDSetting_Strip_A.fPDMA_Done)
    {
        LEDSetting_Strip_A.fPDMA_Done = 1;
        LLSI_SET_SW_MODE(LED_IF_MODULE_STRIP_A);
    }

    /* Clear interrupt flag */
    LLSI_ClearIntFlag(LED_IF_MODULE_STRIP_A, LLSI_RSTC_INT_MASK | LLSI_FEND_INT_MASK);
}

void LED_IF_IRQ_STRIP_B(void)
{
    if(!LEDSetting_Strip_B.fPDMA_Done)
    {
        LEDSetting_Strip_B.fPDMA_Done = 1;
        LLSI_SET_SW_MODE(LED_IF_MODULE_STRIP_B);
    }

    /* Clear interrupt flag */
    LLSI_ClearIntFlag(LED_IF_MODULE_STRIP_B, LLSI_RSTC_INT_MASK | LLSI_FEND_INT_MASK);
}

void LED_IF_IRQ_STRIP_C(void)
{
    if(!LEDSetting_Strip_C.fPDMA_Done)
    {
        LEDSetting_Strip_C.fPDMA_Done = 1;
        LLSI_SET_SW_MODE(LED_IF_MODULE_STRIP_C);
    }

    /* Clear interrupt flag */
    LLSI_ClearIntFlag(LED_IF_MODULE_STRIP_C, LLSI_RSTC_INT_MASK | LLSI_FEND_INT_MASK);
}

void LED_IF_IRQ_STRIP_D(void)
{
    if(!LEDSetting_Strip_D.fPDMA_Done)
    {
        LEDSetting_Strip_D.fPDMA_Done = 1;
        LLSI_SET_SW_MODE(LED_IF_MODULE_STRIP_D);
    }

    /* Clear interrupt flag */
    LLSI_ClearIntFlag(LED_IF_MODULE_STRIP_D, LLSI_RSTC_INT_MASK | LLSI_FEND_INT_MASK);
}

void HAL_Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting)
{
    uint32_t u32Count;

    /* Clear done flag */
    LED_Setting->fPDMA_Done = 0;

    /* Calculate transfer count */
    u32Count = LED_Setting->Array_Size / 4;
    if(LED_Setting->Array_Size % 4)
        u32Count++;

    /* Set transfer count */
    PDMA_SetTransferCnt(PDMA0, LED_Module_Setting[LED_Setting->Sequence].PDMA_Num, PDMA_WIDTH_32, u32Count);
    /* Set request source */
    PDMA_SetTransferMode(PDMA0, LED_Module_Setting[LED_Setting->Sequence].PDMA_Num, PDMA_LLSI0_TX + LED_Module_Setting[LED_Setting->Sequence].Module_Num, FALSE, 0);
    /* Change LLSI mode */
    LLSI_SET_PDMA_MODE((LLSI_T *)LED_IF_Port_Mapping[LED_Setting->Sequence]);
}

void HAL_Change_LED_Type(volatile struct LED_Setting_Tag* LED_Setting)
{
    LLSI_T * ptrLLSI;

    /* Change LLSI RGB/GRB mode */
    ptrLLSI = (LLSI_T *)LED_IF_Port_Mapping[LED_Setting->Sequence];
    if(LED_Setting->LED_Type == eType_GRB)
        LLSI_SET_GRB_FORMAT(ptrLLSI);
    else if(LED_Setting->LED_Type == eType_RGB)
        LLSI_SET_RGB_FORMAT(ptrLLSI);
}

void HAL_Button1_Action(void)
{
    /* ToDo */
    /* Change Strip A lighting mode to next one */
    LEDSetting_Strip_A.LightingMode = HDIV_Mod(LEDSetting_Strip_A.LightingMode + 1, LED_MODE_COUNT);
    LEDSetting_Strip_A.Mode_FUNC = Mode_Function[LEDSetting_Strip_A.LightingMode];
    LEDSetting_Strip_A.ColorIndex = 0;
    LEDSetting_Strip_A.TimeCounter = 0;
}

void HAL_Button2_Action(void)
{
    /* ToDo */
    /* Change Strip B lighting mode to next one */
    LEDSetting_Strip_B.LightingMode = HDIV_Mod(LEDSetting_Strip_B.LightingMode + 1, LED_MODE_COUNT);
    LEDSetting_Strip_B.Mode_FUNC = Mode_Function[LEDSetting_Strip_B.LightingMode];
    LEDSetting_Strip_B.ColorIndex = 0;
    LEDSetting_Strip_B.TimeCounter = 0;
}

void HAL_Button3_Action(void)
{
    /* ToDo */
    /* Change Strip C lighting mode to next one */
    LEDSetting_Strip_C.LightingMode = HDIV_Mod(LEDSetting_Strip_C.LightingMode + 1, LED_MODE_COUNT);
    LEDSetting_Strip_C.Mode_FUNC = Mode_Function[LEDSetting_Strip_C.LightingMode];
    LEDSetting_Strip_C.ColorIndex = 0;
    LEDSetting_Strip_C.TimeCounter = 0;
}

void HAL_Button4_Action(void)
{
    /* ToDo */
    /* Change Strip D lighting mode to next one */
    LEDSetting_Strip_D.LightingMode = HDIV_Mod(LEDSetting_Strip_D.LightingMode + 1, LED_MODE_COUNT);
    LEDSetting_Strip_D.Mode_FUNC = Mode_Function[LEDSetting_Strip_D.LightingMode];
    LEDSetting_Strip_D.ColorIndex = 0;
    LEDSetting_Strip_D.TimeCounter = 0;
}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
