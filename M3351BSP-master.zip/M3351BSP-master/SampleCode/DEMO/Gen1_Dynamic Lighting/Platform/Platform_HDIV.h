/******************************************************************************
 * @file     Platform_HDIV.h
 * @brief    Hardware Divider file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __PLATFORM_HDIV_H
#define __PLATFORM_HDIV_H

#include <stdint.h>
#include "NuMicro.h"

void HDIV_Init(void);
int32_t HDIV_Div(int32_t x, int16_t y);
int16_t HDIV_Mod(int32_t x, int16_t y);

#endif  /* __PLATFORM_HDIV_H */
