/******************************************************************************
 * @file     Platform_HAL_NUC1262.h
 * @brief    HAL driver for platform NUC1262 file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __PLATFORM_HAL_NUC1262_H
#define __PLATFORM_HAL_NUC1262_H

#include <stdint.h>
#include "device.h"
#include "NuMicro.h"
#include "LED_Control.h"

#define HCLK_CLK    144000000

/*!<Define Interrupt priority level */
#define INT_PRIORITY_HIGHEST    0
#define INT_PRIORITY_HIGH       1
#define INT_PRIORITY_NORMAL     2
#define INT_PRIORITY_LOW        3

/*------ARGB LED Control Definition---------------------------*/
/* Strip A */
#define LED_IF_NUM_STRIP_A    4
#define LED_IF_MODULE_STRIP_A LLSI4
#define LED_IF_IRQ_STRIP_A    LLSI4_IRQHandler
#define PDMA_CH_STRIP_A       0
/* Strip B */
#define LED_IF_NUM_STRIP_B    3
#define LED_IF_MODULE_STRIP_B LLSI3
#define LED_IF_IRQ_STRIP_B    LLSI3_IRQHandler
#define PDMA_CH_STRIP_B       1
/* Strip C */
#define LED_IF_NUM_STRIP_C    0
#define LED_IF_MODULE_STRIP_C LLSI0
#define LED_IF_IRQ_STRIP_C    LLSI0_IRQHandler
#define PDMA_CH_STRIP_C       2
/* Strip D */
#define LED_IF_NUM_STRIP_D    5
#define LED_IF_MODULE_STRIP_D LLSI5
#define LED_IF_IRQ_STRIP_D    LLSI5_IRQHandler
#define PDMA_CH_STRIP_D       3
/*------IO and LLSI Setting Definition (M3351)----------------*/
/* M3351 uses GPx_MFP0~3 multi-function registers (5-bit field per pin). */
/* Strip A : PA3 -> LLSI4_OUT */
#define IO_MFP_REG_STRIP_A  (&SYS->GPA_MFP0)
#define IO_MFP_MSK_STRIP_A  SYS_GPA_MFP0_PA3MFP_Msk
#define IO_MFP_VAL_STRIP_A  SYS_GPA_MFP0_PA3MFP_LLSI4_OUT
#define CLK_MODULE_STRIP_A  LLSI4_MODULE
/* Strip B : PC2 -> LLSI3_OUT */
#define IO_MFP_REG_STRIP_B  (&SYS->GPC_MFP0)
#define IO_MFP_MSK_STRIP_B  SYS_GPC_MFP0_PC2MFP_Msk
#define IO_MFP_VAL_STRIP_B  SYS_GPC_MFP0_PC2MFP_LLSI3_OUT
#define CLK_MODULE_STRIP_B  LLSI3_MODULE
/* Strip C : PC5 -> LLSI0_OUT */
#define IO_MFP_REG_STRIP_C  (&SYS->GPC_MFP1)
#define IO_MFP_MSK_STRIP_C  SYS_GPC_MFP1_PC5MFP_Msk
#define IO_MFP_VAL_STRIP_C  SYS_GPC_MFP1_PC5MFP_LLSI0_OUT
#define CLK_MODULE_STRIP_C  LLSI0_MODULE
/* Strip D : PB4 -> LLSI5_OUT */
#define IO_MFP_REG_STRIP_D  (&SYS->GPB_MFP1)
#define IO_MFP_MSK_STRIP_D  SYS_GPB_MFP1_PB4MFP_Msk
#define IO_MFP_VAL_STRIP_D  SYS_GPB_MFP1_PB4MFP_LLSI5_OUT
#define CLK_MODULE_STRIP_D  LLSI5_MODULE

/*------LED Control-------------------------------------------*/
#define LED_IF_T LLSI_T
/* LED control port I/O MFP setting table */
typedef struct
{
    __IO uint32_t *MFP_Reg;
    uint32_t       MFP_Msk;
    uint32_t       MFP_Val;
} LED_IO_SETTING;
extern const LED_IO_SETTING LED_IO_Setting[TOTAL_LED_AREA];
typedef struct
{
    uint32_t CLK_Module;
    uint8_t  Module_Num;
    uint8_t  PDMA_Num;
} LED_MODULE_SETTING;
extern const LED_MODULE_SETTING LED_Module_Setting[TOTAL_LED_AREA];

/*------LED Control Function----------------------------------*/
void HAL_ARGB_Port_Initial(uint8_t port);
void HAL_PDMA_Initial(uint8_t port);
void HAL_Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);
void HAL_Change_LED_Type(volatile struct LED_Setting_Tag* LED_Setting);

/*------OLED Control Definition-------------------------------*/
#define I2C_PORT             I2C0
#define I2C_MODULE           I2C0_MODULE
#define I2C_BUS_FREQUENCY    600000
#define I2C_SDA_MFP          SYS->GPC_MFP0
#define I2C_SDA_MFP_MSK      SYS_GPC_MFP0_PC0MFP_Msk
#define I2C_SDA_MFP_FUNC     SYS_GPC_MFP0_PC0MFP_I2C0_SDA
#define I2C_SDA_PORT         PC
#define I2C_SDA_SMT_MSK      GPIO_SMTEN_SMTEN0_Msk
#define I2C_SCL_MFP          SYS->GPC_MFP0
#define I2C_SCL_MFP_MSK      SYS_GPC_MFP0_PC1MFP_Msk
#define I2C_SCL_MFP_FUNC     SYS_GPC_MFP0_PC1MFP_I2C0_SCL
#define I2C_SCL_PORT         PC
#define I2C_SCL_SMT_MSK      GPIO_SMTEN_SMTEN1_Msk

/*------Button Control Definition-----------------------------*/
#define BUTTON_TYPE_INT        0
#define BUTTON_TYPE_POLLING    1
/* Definition of Button 1 */
#define BUTTON1_PORT           PB
#define BUTTON1_BIT            BIT1
#define BUTTON1_NUM            1
#define BUTTON1_PIN            PB1
#define BUTTON1_EVENT_TYPE     BUTTON_TYPE_POLLING
#define BUTTON1_IRQ            GPB_IRQn
/* Definition of Button 2 */
#define BUTTON2_PORT           PB
#define BUTTON2_BIT            BIT0
#define BUTTON2_NUM            0
#define BUTTON2_PIN            PB0
#define BUTTON2_EVENT_TYPE     BUTTON_TYPE_POLLING
#define BUTTON2_IRQ            GPB_IRQn
/* Definition of Button 3 */
#define BUTTON3_PORT           PA
#define BUTTON3_BIT            BIT4
#define BUTTON3_NUM            4
#define BUTTON3_PIN            PA4
#define BUTTON3_EVENT_TYPE     BUTTON_TYPE_POLLING
#define BUTTON3_IRQ            GPA_IRQn
/* Definition of Button 4 */
#define BUTTON4_PORT           PA
#define BUTTON4_BIT            BIT5
#define BUTTON4_NUM            5
#define BUTTON4_PIN            PA5
#define BUTTON4_EVENT_TYPE     BUTTON_TYPE_POLLING
#define BUTTON4_IRQ            GPA_IRQn

/*------Button Function---------------------------------------*/
void HAL_Button1_Action(void);
void HAL_Button2_Action(void);
void HAL_Button3_Action(void);
void HAL_Button4_Action(void);

#endif  /* __PLATFORM_HAL_NUC1262_H */
