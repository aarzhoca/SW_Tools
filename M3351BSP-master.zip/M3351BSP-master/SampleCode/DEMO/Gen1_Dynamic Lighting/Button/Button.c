/******************************************************************************//**
 * @file     Button.c
 * @version  V1.00
 * @brief    Button sample file
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

/*!<Includes */
#include "NuMicro.h"
#include "device.h"
#include "Platform_HAL.h"
#include "Platform_HDIV.h"
#include "Button.h"
#include "LED_Control.h"
#include "OLED_Control.h"

void Button1_Initial(void)
{
    /* Configure as Quasi-bidirectional mode */
    GPIO_SetMode(BUTTON1_PORT, BUTTON1_BIT, GPIO_MODE_QUASI);

    /* Enable interrupt by falling edge trigger */
    GPIO_EnableInt(BUTTON1_PORT, BUTTON1_NUM, GPIO_INT_FALLING);
#if (BUTTON1_EVENT_TYPE == BUTTON_TYPE_INT)
    NVIC_EnableIRQ(BUTTON1_IRQ);
#endif

    /* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 256 clocks of LIRC clock */
    GPIO_SET_DEBOUNCE_TIME(BUTTON1_PORT, GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_256);    // 25 ms
    GPIO_ENABLE_DEBOUNCE(BUTTON1_PORT, BUTTON1_BIT);
}

void Button1_IRQHandler(void)
{
    /* Modify function for corresponding platform */
    HAL_Button1_Action();
}

/* Call in the corresponding GPIO_IRQHanler */
void Button1_IRQCheck(void)
{
    if(GPIO_GET_INT_FLAG(BUTTON1_PORT, BUTTON1_BIT))
    {
        GPIO_CLR_INT_FLAG(BUTTON1_PORT, BUTTON1_BIT);
    
        /* Falling Edge Trigger */
        Button1_IRQHandler();
    }
}

void Button2_Initial(void)
{
    /* Configure as Quasi-bidirectional mode */
    GPIO_SetMode(BUTTON2_PORT, BUTTON2_BIT, GPIO_MODE_QUASI);

    /* Enable interrupt by falling edge trigger */
    GPIO_EnableInt(BUTTON2_PORT, BUTTON2_NUM, GPIO_INT_FALLING);
#if (BUTTON1_EVENT_TYPE == BUTTON_TYPE_INT)
    NVIC_EnableIRQ(BUTTON2_IRQ);
#endif

    /* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 256 clocks of LIRC clock */
    GPIO_SET_DEBOUNCE_TIME(BUTTON2_PORT, GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_256);    // 25 ms
    GPIO_ENABLE_DEBOUNCE(BUTTON2_PORT, BUTTON2_BIT);
}

void Button2_IRQHandler(void)
{
    /* Modify function for corresponding platform */
    HAL_Button2_Action();
}

/* Call in the corresponding GPIO_IRQHanler */
void Button2_IRQCheck(void)
{
    if(GPIO_GET_INT_FLAG(BUTTON2_PORT, BUTTON2_BIT))
    {
        GPIO_CLR_INT_FLAG(BUTTON2_PORT, BUTTON2_BIT);
    
        /* Falling Edge Trigger */
        Button2_IRQHandler();
    }
}

void Button3_Initial(void)
{
    /* Configure as Quasi-bidirectional mode */
    GPIO_SetMode(BUTTON3_PORT, BUTTON3_BIT, GPIO_MODE_QUASI);

    /* Enable interrupt by falling edge trigger */
    GPIO_EnableInt(BUTTON3_PORT, BUTTON3_NUM, GPIO_INT_FALLING);
#if (BUTTON1_EVENT_TYPE == BUTTON_TYPE_INT)
    NVIC_EnableIRQ(BUTTON3_IRQ);
#endif

    /* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 256 clocks of LIRC clock */
    GPIO_SET_DEBOUNCE_TIME(BUTTON3_PORT, GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_256);    // 25 ms
    GPIO_ENABLE_DEBOUNCE(BUTTON3_PORT, BUTTON3_BIT);
}

void Button3_IRQHandler(void)
{
    /* Modify function for corresponding platform */
    HAL_Button3_Action();
}

/* Call in the corresponding GPIO_IRQHanler */
void Button3_IRQCheck(void)
{
    if(GPIO_GET_INT_FLAG(BUTTON3_PORT, BUTTON3_BIT))
    {
        GPIO_CLR_INT_FLAG(BUTTON3_PORT, BUTTON3_BIT);
    
        /* Falling Edge Trigger */
        Button3_IRQHandler();
    }
}

void Button4_Initial(void)
{
    /* Configure as Quasi-bidirectional mode */
    GPIO_SetMode(BUTTON4_PORT, BUTTON4_BIT, GPIO_MODE_QUASI);

    /* Enable interrupt by falling edge trigger */
    GPIO_EnableInt(BUTTON4_PORT, BUTTON4_NUM, GPIO_INT_FALLING);
#if (BUTTON1_EVENT_TYPE == BUTTON_TYPE_INT)
    NVIC_EnableIRQ(BUTTON4_IRQ);
#endif

    /* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 256 clocks of LIRC clock */
    GPIO_SET_DEBOUNCE_TIME(BUTTON4_PORT, GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_256);    // 25 ms
    GPIO_ENABLE_DEBOUNCE(BUTTON4_PORT, BUTTON4_BIT);
}

void Button4_IRQHandler(void)
{
    /* Modify function for corresponding platform */
    HAL_Button4_Action();
}

/* Call in the corresponding GPIO_IRQHanler */
void Button4_IRQCheck(void)
{
    if(GPIO_GET_INT_FLAG(BUTTON4_PORT, BUTTON4_BIT))
    {
        GPIO_CLR_INT_FLAG(BUTTON4_PORT, BUTTON4_BIT);
    
        /* Falling Edge Trigger */
        Button4_IRQHandler();
    }
}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
