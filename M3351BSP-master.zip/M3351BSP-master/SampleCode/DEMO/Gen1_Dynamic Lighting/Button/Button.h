/******************************************************************************
 * @file     Button.h
 * @brief    Button header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __BUTTON_H
#define __BUTTON_H

#include <stdint.h>
#include "NuMicro.h"

/*------Button Function---------------------------------------*/
void Button1_Initial(void);
void Button1_IRQCheck(void);
void Button2_Initial(void);
void Button2_IRQCheck(void);
void Button3_Initial(void);
void Button3_IRQCheck(void);
void Button4_Initial(void);
void Button4_IRQCheck(void);

#endif  /* __BUTTON_H */
