/****************************************************************************//**
 * @file     hid_transfer.h
 * @version  V0.10
 * @brief
 *           HID command transfer header file
 *
 * @copyright (C) 2018 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __USBD_HID_H__
#define __USBD_HID_H__

#include <stdint.h>
#include "device.h"
#include "LED_Control.h"
#include "Dynamic_Lighting.h"

/* Define the vendor id and product id */
#define USBD_VID        0x0416
#define USBD_PID        0x5020

/*!<Define HID Class Specific Request */
#define GET_REPORT          0x01
#define GET_IDLE            0x02
#define GET_PROTOCOL        0x03
#define SET_REPORT          0x09
#define SET_IDLE            0x0A
#define SET_PROTOCOL        0x0B

/*!<USB HID Interface Class protocol */
#define HID_NONE            0x00
#define HID_KEYBOARD        0x01
#define HID_MOUSE           0x02

/*!<USB HID Class Report Type */
#define HID_RPT_TYPE_INPUT      0x01
#define HID_RPT_TYPE_OUTPUT     0x02
#define HID_RPT_TYPE_FEATURE    0x03

/*-------------------------------------------------------------*/
/* Define EP maximum packet size */
#define EP0_MAX_PKT_SIZE    8
#define EP1_MAX_PKT_SIZE    EP0_MAX_PKT_SIZE
#define EP2_MAX_PKT_SIZE    64
#define EP3_MAX_PKT_SIZE    64

#define SETUP_BUF_BASE  0
#define SETUP_BUF_LEN   8
#define EP0_BUF_BASE    (SETUP_BUF_BASE + SETUP_BUF_LEN)
#define EP0_BUF_LEN     EP0_MAX_PKT_SIZE
#define EP1_BUF_BASE    (SETUP_BUF_BASE + SETUP_BUF_LEN)
#define EP1_BUF_LEN     EP1_MAX_PKT_SIZE
#define EP2_BUF_BASE    (EP1_BUF_BASE + EP1_BUF_LEN)
#define EP2_BUF_LEN     EP2_MAX_PKT_SIZE
#define EP3_BUF_BASE    (EP2_BUF_BASE + EP2_BUF_LEN)
#define EP3_BUF_LEN     EP3_MAX_PKT_SIZE

/* Define the EP number */
#define INT_IN_EP_NUM                   0x01
#define INT_OUT_EP_NUM                  0x02
#define CTRL_IN_STRIP_A_EP_NUM          0x03
#define CTRL_IN_STRIP_B_EP_NUM          0x04
#define CTRL_IN_STRIP_C_EP_NUM          0x05
#define CTRL_IN_STRIP_D_EP_NUM          0x06

/* Define Descriptor information */
#define HID_DEFAULT_INT_IN_INTERVAL     1
#define USBD_SELF_POWERED               0
#define USBD_REMOTE_WAKEUP              0
#define USBD_MAX_POWER                  250  /* The unit is in 2mA. ex: 50 * 2mA = 100mA */

#define NUM_USB_INTERFACE               (TOTAL_LED_AREA + 1)
#define NUM_USB_HID                     (TOTAL_LED_AREA + 1)
#define LEN_CONFIG_AND_SUBORDINATE      (LEN_CONFIG + LEN_INTERFACE*NUM_USB_INTERFACE + LEN_HID*NUM_USB_HID + LEN_ENDPOINT*2 + LEN_ENDPOINT*TOTAL_LED_AREA)
#define NUM_USB_STRING_DESCRIPTOR       (4 + TOTAL_LED_AREA)
#define NUM_USB_HID_REPORT_DESCRIPTOR   (2 + TOTAL_LED_AREA)
/* Dynamic Lighting */
#define USB_INTERFACE_NUM_STRIP_A       1
#define USB_STRINDINDEX_NUM_STRIP_A     4
#define USB_CONFIG_HID_INDEX_STRIP_A    (LEN_CONFIG + LEN_INTERFACE + LEN_HID + LEN_ENDPOINT*2 + LEN_INTERFACE                              )
#define USB_INTERFACE_NUM_STRIP_B       2
#define USB_STRINDINDEX_NUM_STRIP_B     5
#define USB_CONFIG_HID_INDEX_STRIP_B    (LEN_CONFIG + LEN_INTERFACE + LEN_HID + LEN_ENDPOINT*2 + LEN_INTERFACE + (LEN_HID + LEN_INTERFACE + LEN_ENDPOINT)*1)
#define USB_INTERFACE_NUM_STRIP_C       3
#define USB_STRINDINDEX_NUM_STRIP_C     6
#define USB_CONFIG_HID_INDEX_STRIP_C    (LEN_CONFIG + LEN_INTERFACE + LEN_HID + LEN_ENDPOINT*2 + LEN_INTERFACE + (LEN_HID + LEN_INTERFACE + LEN_ENDPOINT)*2)
#define USB_INTERFACE_NUM_STRIP_D       4
#define USB_STRINDINDEX_NUM_STRIP_D     7
#define USB_CONFIG_HID_INDEX_STRIP_D    (LEN_CONFIG + LEN_INTERFACE + LEN_HID + LEN_ENDPOINT*2 + LEN_INTERFACE + (LEN_HID + LEN_INTERFACE + LEN_ENDPOINT)*3)

/*-------------------------------------------------------------*/
/* USB HID Command */
extern uint8_t RcvBuffer[512];
extern volatile uint8_t set_report_flag;

/* Report ID List */
/* For NuLEDCtrl Tool */
#define REPORT_ID_IN_OUT_GENERAL_CMD                        0x01
#define REPORT_ID_IN_OUT_LEDSETSTRIP                        0x02
#define REPORT_ID_IN_OUT_LEDSETMODE                         0x03
#define REPORT_ID_FEATURE_LEDAPSYNC                         0x04
/* Dynamic Lighting */
/* Strip A */
#define REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_A      (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A    )    // Get Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_A    (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A + 1)    // Set Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_A   (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A + 2)    // Get Report
#define REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_A          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A + 3)    // Set Report
#define REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_A          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A + 4)    // Set Report
#define REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_A         (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_A + 5)    // Set Report
/* Strip B */
#define REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_B      (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B    )    // Get Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_B    (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B + 1)    // Set Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_B   (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B + 2)    // Get Report
#define REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_B          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B + 3)    // Set Report
#define REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_B          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B + 4)    // Set Report
#define REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_B         (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_B + 5)    // Set Report
/* Strip C */
#define REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_C      (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C    )    // Get Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_C    (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C + 1)    // Set Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_C   (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C + 2)    // Get Report
#define REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_C          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C + 3)    // Set Report
#define REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_C          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C + 4)    // Set Report
#define REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_C         (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_C + 5)    // Set Report
/* Strip D */
#define REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_D      (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D    )    // Get Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_D    (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D + 1)    // Set Report
#define REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_D   (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D + 2)    // Get Report
#define REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_D          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D + 3)    // Set Report
#define REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_D          (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D + 4)    // Set Report
#define REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_D         (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES*SEQUENCE_STRIP_D + 5)    // Set Report
/* Dynamic Lighting Attributes */
/* Dynamic Lighting: LampArrayAttributes */
extern const uint32_t LampArrayAttributes[TOTAL_LED_AREA][LAMPARRAYATTRIBUTES_USAGECOUNT];
/* Dynamic Lighting: LampAttributesResponse */
extern const uint32_t LampAttributesReponse[TOTAL_LED_AREA][LAMPATTRIBUTESRESPONSE_USAGECOUNT];
/* Strip A */
#define UPDATEINTERVAL_MICROSEC_STRIP_A    (TIMER_FRAME_UPDATE*1000)
#define UPDATELATENCY_MICROSEC_STRIP_A     1000
/* Strip B */
#define UPDATEINTERVAL_MICROSEC_STRIP_B    (TIMER_FRAME_UPDATE*1000)
#define UPDATELATENCY_MICROSEC_STRIP_B     1000
/* Strip C */
#define UPDATEINTERVAL_MICROSEC_STRIP_C    (TIMER_FRAME_UPDATE*1000)
#define UPDATELATENCY_MICROSEC_STRIP_C     1000
/* Strip D */
#define UPDATEINTERVAL_MICROSEC_STRIP_D    (TIMER_FRAME_UPDATE*1000)
#define UPDATELATENCY_MICROSEC_STRIP_D     1000

/* Report Count of each Report ID */
#define LEN_PACKET_GENERAL_CMD                 16
#define LEN_IN_OUT_GENERAL_CMD                 (LEN_PACKET_GENERAL_CMD - 1)    // Decrease Report ID
#define LEN_PACKET_LEDSETSTRIP                 16
#define LEN_IN_OUT_LEDSETSTRIP                 (LEN_PACKET_LEDSETSTRIP - 1)    // Decrease Report ID
#define LEN_PACKET_LEDSETMODE                  16
#define LEN_IN_OUT_LEDSETMODE                  (LEN_PACKET_LEDSETMODE - 1)     // Decrease Report ID
#define MAX_NUM_LEDAPSYNC                      144
#define LEN_HAED_LEDAPSYNC                     3
#define LEN_FEATURE_LEDAPSYNC                  (MAX_NUM_LEDAPSYNC*3 + LEN_HAED_LEDAPSYNC - 1)    // Decrease Report ID

#define MAX_SINGLE_REPORT_COUNT                0xFE
#define GET_MSB_REPORT_COUNT(x)                ((uint8_t)((x & 0xFF00) >> 8))
#define GET_LSB_REPORT_COUNT(x)                ((uint8_t)((x & 0x00FF)     ))

/* HID Transfer Commands */
#define HID_CMD_ACK             0x5A
#define HID_CMD_GET_FW_VERSION  0xA0
#define HID_CMD_GET_FW_CHECKSUM 0xA1
#define HID_CMD_START_ISP       0xB0
#define HID_CMD_SET_VOLUME      0xC0

/*-------------------------------------------------------------*/
void HID_Init(void);
void HID_ClassRequest(void);

void EP2_Handler(void);
void EP3_Handler(void);
void HID_SetInReport(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Get_General_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Get_LEDSetStrip_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Set_LEDMode_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
int Check_Repeat(uint16_t *src, uint8_t size);

#endif  /* __USBD_HID_H_ */

/*** (C) COPYRIGHT 2018 Nuvoton Technology Corp. ***/
