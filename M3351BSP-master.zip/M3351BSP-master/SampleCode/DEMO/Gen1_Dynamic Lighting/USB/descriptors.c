/******************************************************************************//**
 * @file     descriptors.c
 * @version  V0.10
 * @brief    M251 series USBD descriptor
 *
 * @copyright (C) 2018 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
/*!<Includes */
#include "NuMicro.h"
#include "Platform_usbd.h"
#include "hid_transfer.h"

/*!<USB HID Report Descriptor */
const uint8_t HID_DeviceReportDescriptor[] =
{
    0x06, 0x00, 0xFF,  //   Usage Page = 0xFF00 (Vendor Defined Page 1)
    0x09, 0x01,        //   Usage (Vendor Usage 1)
    0xA1, 0x01,        //   Collection (Application)
    /* General Command */
    0x85,
    REPORT_ID_IN_OUT_GENERAL_CMD,
                       //   Report ID
    0x09, 0x01,        //   Usage (0x01)
    0x15, 0x00,        //   Logical Minimum (0)
    0x26, 0xFF, 0x00,  //   Logical Maximum (255)
    0x75, 0x08,        //   Report Size (8)
#if(LEN_IN_OUT_GENERAL_CMD > MAX_SINGLE_REPORT_COUNT)
    0x96,
    GET_LSB_REPORT_COUNT(LEN_IN_OUT_GENERAL_CMD),
    GET_MSB_REPORT_COUNT(LEN_IN_OUT_GENERAL_CMD),
                       //   Report Count
#else
    0x95,
    LEN_IN_OUT_GENERAL_CMD,
                       //   Report Count
#endif
    0x81, 0x02,        //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x09, 0x01,        //   Usage (0x01)
    0x91, 0x02,        //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    /* LED Set Strip */
    0x85,
    REPORT_ID_IN_OUT_LEDSETSTRIP,
                       //   Report ID
    0x09, 0x01,        //   Usage (0x01)
    0x15, 0x00,        //   Logical Minimum (0)
    0x26, 0xFF, 0x00,  //   Logical Maximum (255)
    0x75, 0x08,        //   Report Size (8)
#if(LEN_IN_OUT_LEDSETSTRIP > MAX_SINGLE_REPORT_COUNT)
    0x96,
    GET_LSB_REPORT_COUNT(LEN_IN_OUT_LEDSETSTRIP),
    GET_MSB_REPORT_COUNT(LEN_IN_OUT_LEDSETSTRIP),
                       //   Report Count
#else
    0x95,
    LEN_IN_OUT_LEDSETSTRIP,
                       //   Report Count
#endif
    0x81, 0x02,        //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x09, 0x01,        //   Usage (0x01)
    0x91, 0x02,        //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    /* LED Set Mode */
    0x85,
    REPORT_ID_IN_OUT_LEDSETMODE,
                       //   Report ID
    0x09, 0x01,        //   Usage (0x01)
    0x15, 0x00,        //   Logical Minimum (0)
    0x26, 0xFF, 0x00,  //   Logical Maximum (255)
    0x75, 0x08,        //   Report Size (8)
#if(LEN_IN_OUT_LEDSETMODE > MAX_SINGLE_REPORT_COUNT)
    0x96,
    GET_LSB_REPORT_COUNT(LEN_IN_OUT_LEDSETMODE),
    GET_MSB_REPORT_COUNT(LEN_IN_OUT_LEDSETMODE),
                       //   Report Count
#else
    0x95,
    LEN_IN_OUT_LEDSETMODE,
                       //   Report Count
#endif
    0x81, 0x02,        //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x09, 0x01,        //   Usage (0x01)
    0x91, 0x02,        //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    /* LED AP Sync */
    0x85,
    REPORT_ID_FEATURE_LEDAPSYNC,
                       //   Report ID
    0x09, 0x01,        //   Usage (0x01)
    0x15, 0x00,        //   Logical Minimum (0)
    0x26, 0xFF, 0x00,  //   Logical Maximum (255)
    0x75, 0x08,        //   Report Size (8)
#if(LEN_FEATURE_LEDAPSYNC > MAX_SINGLE_REPORT_COUNT)
    0x96,
    GET_LSB_REPORT_COUNT(LEN_FEATURE_LEDAPSYNC),
    GET_MSB_REPORT_COUNT(LEN_FEATURE_LEDAPSYNC),
                       //   Report Count
#else
    0x95,
    LEN_FEATURE_LEDAPSYNC,
                       //   Report Count
#endif
    0xB1, 0x02,        //   Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)

    0xC0,              //   End Collection
};

const uint8_t HID_DynamicLightingReportDescriptor_Strip_A[] = {
    0x05, 0x59,        // Usage Page (0x59) (Lighting And Illumination Page)
    0x09, 0x01,        // Usage (0x01) (LampArray)
    0xA1, 0x01,        // Collection (Application)
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_A,
                       //   Report ID
    0x09, 0x02,        //   Usage (0x02) (LampArrayAttributesReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x04,        //     Usage (0x04) (BoundingBoxWidthInMicrometers)
    0x09, 0x05,        //     Usage (0x05) (BoundingBoxHeightInMicrometers)
    0x09, 0x06,        //     Usage (0x06) (BoundingBoxDepthInMicrometers)
    0x09, 0x07,        //     Usage (0x07) (LampArrayKind)
    0x09, 0x08,        //     Usage (0x08) (MinUpdateIntervalInMicroseconds)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_A,
                       //   Report ID
    0x09, 0x20,        //   Usage (0x20) (LampAttributesRequestReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_A,
                       //   Report ID
    0x09, 0x22,        //   Usage (0x22) (LampAttributesResponseReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x23,        //     Usage (0x23) (PositionXInMicrometers)
    0x09, 0x24,        //     Usage (0x24) (PositionYInMicrometers)
    0x09, 0x25,        //     Usage (0x25) (PositionZInMicrometers)
    0x09, 0x27,        //     Usage (0x27) (UpdateLatencyInMicroseconds)
    0x09, 0x26,        //     Usage (0x26) (LampPurposes)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x28,        //     Usage (0x28) (RedLevelCount)
    0x09, 0x29,        //     Usage (0x29) (GreenLevelCount)
    0x09, 0x2A,        //     Usage (0x2A) (BlueLevelCount)
    0x09, 0x2B,        //     Usage (0x2B) (IntensityLevelCount)
    0x09, 0x2C,        //     Usage (0x2C) (IsProgrammable)
    0x09, 0x2D,        //     Usage (0x2D) (InputBinding)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x06,        //     Report Count (6)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_A,
                       //   Report ID
    0x09, 0x50,        //   Usage (0x50) (LampMultiUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x08,        //     Report Count (8)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) #1 (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52)    (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53)    (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54)    (IntensityUpdateChannel)
    0x09, 0x51,        //     Usage (0x51) #2
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #3
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #4
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #5
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #6
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #7
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #8
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x20,        //     Report Count (32)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_A,
                       //   Report ID
    0x09, 0x60,        //   Usage (0x60) (LampRangeUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x61,        //     Usage (0x61) (LampIdStart)
    0x09, 0x62,        //     Usage (0x62) (LampIdEnd)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52) (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53) (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54) (IntensityUpdateChannel)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x04,        //     Report Count (4)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_A,
                       //   Report ID
    0x09, 0x70,        //   Usage (0x70) (LampArrayControlReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x71,        //     Usage (0x71) (AutonomousMode)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x01,        //     Logical Maximum (1)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0xC0,              // End Collection
};

const uint8_t HID_DynamicLightingReportDescriptor_Strip_B[] = {
    0x05, 0x59,        // Usage Page (0x59) (Lighting And Illumination Page)
    0x09, 0x01,        // Usage (0x01) (LampArray)
    0xA1, 0x01,        // Collection (Application)
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_B,
                       //   Report ID
    0x09, 0x02,        //   Usage (0x02) (LampArrayAttributesReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x04,        //     Usage (0x04) (BoundingBoxWidthInMicrometers)
    0x09, 0x05,        //     Usage (0x05) (BoundingBoxHeightInMicrometers)
    0x09, 0x06,        //     Usage (0x06) (BoundingBoxDepthInMicrometers)
    0x09, 0x07,        //     Usage (0x07) (LampArrayKind)
    0x09, 0x08,        //     Usage (0x08) (MinUpdateIntervalInMicroseconds)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_B,
                       //   Report ID
    0x09, 0x20,        //   Usage (0x20) (LampAttributesRequestReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_B,
                       //   Report ID
    0x09, 0x22,        //   Usage (0x22) (LampAttributesResponseReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x23,        //     Usage (0x23) (PositionXInMicrometers)
    0x09, 0x24,        //     Usage (0x24) (PositionYInMicrometers)
    0x09, 0x25,        //     Usage (0x25) (PositionZInMicrometers)
    0x09, 0x27,        //     Usage (0x27) (UpdateLatencyInMicroseconds)
    0x09, 0x26,        //     Usage (0x26) (LampPurposes)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x28,        //     Usage (0x28) (RedLevelCount)
    0x09, 0x29,        //     Usage (0x29) (GreenLevelCount)
    0x09, 0x2A,        //     Usage (0x2A) (BlueLevelCount)
    0x09, 0x2B,        //     Usage (0x2B) (IntensityLevelCount)
    0x09, 0x2C,        //     Usage (0x2C) (IsProgrammable)
    0x09, 0x2D,        //     Usage (0x2D) (InputBinding)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x06,        //     Report Count (6)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_B,
                       //   Report ID
    0x09, 0x50,        //   Usage (0x50) (LampMultiUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x08,        //     Report Count (8)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) #1 (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52)    (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53)    (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54)    (IntensityUpdateChannel)
    0x09, 0x51,        //     Usage (0x51) #2
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #3
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #4
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #5
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #6
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #7
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #8
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x20,        //     Report Count (32)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_B,
                       //   Report ID
    0x09, 0x60,        //   Usage (0x60) (LampRangeUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x61,        //     Usage (0x61) (LampIdStart)
    0x09, 0x62,        //     Usage (0x62) (LampIdEnd)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52) (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53) (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54) (IntensityUpdateChannel)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x04,        //     Report Count (4)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_B,
                       //   Report ID
    0x09, 0x70,        //   Usage (0x70) (LampArrayControlReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x71,        //     Usage (0x71) (AutonomousMode)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x01,        //     Logical Maximum (1)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0xC0,              // End Collection
};

const uint8_t HID_DynamicLightingReportDescriptor_Strip_C[] = {
    0x05, 0x59,        // Usage Page (0x59) (Lighting And Illumination Page)
    0x09, 0x01,        // Usage (0x01) (LampArray)
    0xA1, 0x01,        // Collection (Application)
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_C,
                       //   Report ID
    0x09, 0x02,        //   Usage (0x02) (LampArrayAttributesReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x04,        //     Usage (0x04) (BoundingBoxWidthInMicrometers)
    0x09, 0x05,        //     Usage (0x05) (BoundingBoxHeightInMicrometers)
    0x09, 0x06,        //     Usage (0x06) (BoundingBoxDepthInMicrometers)
    0x09, 0x07,        //     Usage (0x07) (LampArrayKind)
    0x09, 0x08,        //     Usage (0x08) (MinUpdateIntervalInMicroseconds)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_C,
                       //   Report ID
    0x09, 0x20,        //   Usage (0x20) (LampAttributesRequestReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_C,
                       //   Report ID
    0x09, 0x22,        //   Usage (0x22) (LampAttributesResponseReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x23,        //     Usage (0x23) (PositionXInMicrometers)
    0x09, 0x24,        //     Usage (0x24) (PositionYInMicrometers)
    0x09, 0x25,        //     Usage (0x25) (PositionZInMicrometers)
    0x09, 0x27,        //     Usage (0x27) (UpdateLatencyInMicroseconds)
    0x09, 0x26,        //     Usage (0x26) (LampPurposes)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x28,        //     Usage (0x28) (RedLevelCount)
    0x09, 0x29,        //     Usage (0x29) (GreenLevelCount)
    0x09, 0x2A,        //     Usage (0x2A) (BlueLevelCount)
    0x09, 0x2B,        //     Usage (0x2B) (IntensityLevelCount)
    0x09, 0x2C,        //     Usage (0x2C) (IsProgrammable)
    0x09, 0x2D,        //     Usage (0x2D) (InputBinding)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x06,        //     Report Count (6)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_C,
                       //   Report ID
    0x09, 0x50,        //   Usage (0x50) (LampMultiUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x08,        //     Report Count (8)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) #1 (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52)    (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53)    (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54)    (IntensityUpdateChannel)
    0x09, 0x51,        //     Usage (0x51) #2
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #3
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #4
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #5
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #6
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #7
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #8
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x20,        //     Report Count (32)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_C,
                       //   Report ID
    0x09, 0x60,        //   Usage (0x60) (LampRangeUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x61,        //     Usage (0x61) (LampIdStart)
    0x09, 0x62,        //     Usage (0x62) (LampIdEnd)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52) (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53) (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54) (IntensityUpdateChannel)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x04,        //     Report Count (4)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_C,
                       //   Report ID
    0x09, 0x70,        //   Usage (0x70) (LampArrayControlReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x71,        //     Usage (0x71) (AutonomousMode)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x01,        //     Logical Maximum (1)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0xC0,              // End Collection
};

const uint8_t HID_DynamicLightingReportDescriptor_Strip_D[] = {
    0x05, 0x59,        // Usage Page (0x59) (Lighting And Illumination Page)
    0x09, 0x01,        // Usage (0x01) (LampArray)
    0xA1, 0x01,        // Collection (Application)
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES_STRIP_D,
                       //   Report ID
    0x09, 0x02,        //   Usage (0x02) (LampArrayAttributesReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x04,        //     Usage (0x04) (BoundingBoxWidthInMicrometers)
    0x09, 0x05,        //     Usage (0x05) (BoundingBoxHeightInMicrometers)
    0x09, 0x06,        //     Usage (0x06) (BoundingBoxDepthInMicrometers)
    0x09, 0x07,        //     Usage (0x07) (LampArrayKind)
    0x09, 0x08,        //     Usage (0x08) (MinUpdateIntervalInMicroseconds)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x03,        //     Feature (Const,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST_STRIP_D,
                       //   Report ID
    0x09, 0x20,        //   Usage (0x20) (LampAttributesRequestReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE_STRIP_D,
                       //   Report ID
    0x09, 0x22,        //   Usage (0x22) (LampAttributesResponseReport) (Get Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x23,        //     Usage (0x23) (PositionXInMicrometers)
    0x09, 0x24,        //     Usage (0x24) (PositionYInMicrometers)
    0x09, 0x25,        //     Usage (0x25) (PositionZInMicrometers)
    0x09, 0x27,        //     Usage (0x27) (UpdateLatencyInMicroseconds)
    0x09, 0x26,        //     Usage (0x26) (LampPurposes)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0xFF, 0x7F,
                       //     Logical Maximum (2147483646)
    0x75, 0x20,        //     Report Size (32)
    0x95, 0x05,        //     Report Count (5)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x28,        //     Usage (0x28) (RedLevelCount)
    0x09, 0x29,        //     Usage (0x29) (GreenLevelCount)
    0x09, 0x2A,        //     Usage (0x2A) (BlueLevelCount)
    0x09, 0x2B,        //     Usage (0x2B) (IntensityLevelCount)
    0x09, 0x2C,        //     Usage (0x2C) (IsProgrammable)
    0x09, 0x2D,        //     Usage (0x2D) (InputBinding)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x06,        //     Report Count (6)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_MULTIUPDATE_STRIP_D,
                       //   Report ID
    0x09, 0x50,        //   Usage (0x50) (LampMultiUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x03,        //     Usage (0x03) (LampCount)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x21,        //     Usage (0x21) (LampId)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x08,        //     Report Count (8)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) #1 (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52)    (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53)    (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54)    (IntensityUpdateChannel)
    0x09, 0x51,        //     Usage (0x51) #2
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #3
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #4
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #5
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #6
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #7
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x09, 0x51,        //     Usage (0x51) #8
    0x09, 0x52,        //     Usage (0x52)
    0x09, 0x53,        //     Usage (0x53)
    0x09, 0x54,        //     Usage (0x54)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x20,        //     Report Count (32)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMP_RANGEUPDATE_STRIP_D,
                       //   Report ID
    0x09, 0x60,        //   Usage (0x60) (LampRangeUpdateReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x55,        //     Usage (0x55) (LampUpdateFlags)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x08,        //     Logical Maximum (8)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x61,        //     Usage (0x61) (LampIdStart)
    0x09, 0x62,        //     Usage (0x62) (LampIdEnd)
    0x15, 0x00,        //     Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,
                       //     Logical Maximum (65534)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x02,        //     Report Count (2)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x09, 0x51,        //     Usage (0x51) (RedUpdateChannel)
    0x09, 0x52,        //     Usage (0x52) (GreenUpdateChannel)
    0x09, 0x53,        //     Usage (0x53) (BlueUpdateChannel)
    0x09, 0x54,        //     Usage (0x54) (IntensityUpdateChannel)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x00,  //     Logical Maximum (255)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x04,        //     Report Count (4)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0x85,
    REPORT_ID_FEATURE_LAMPARRAY_CONTROL_STRIP_D,
                       //   Report ID
    0x09, 0x70,        //   Usage (0x70) (LampArrayControlReport) (Set Report)
    0xA1, 0x02,        //   Collection (Logical)
    0x09, 0x71,        //     Usage (0x71) (AutonomousMode)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x01,        //     Logical Maximum (1)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0xB1, 0x02,        //     Feature (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,              //   End Collection
    0xC0,              // End Collection
};

/*----------------------------------------------------------------------------*/
/*!<USB Device Descriptor */
const uint8_t gu8DeviceDescriptor[] =
{
    LEN_DEVICE,     /* bLength */
    DESC_DEVICE,    /* bDescriptorType */
#ifdef SUPPORT_LPM
    0x01, 0x02,     /* bcdUSB => 0x0201 to support LPM */
#else
    0x10, 0x01,     /* bcdUSB */
#endif
    0x00,           /* bDeviceClass */
    0x00,           /* bDeviceSubClass */
    0x00,           /* bDeviceProtocol */
    EP0_MAX_PKT_SIZE,   /* bMaxPacketSize0 */
    /* idVendor */
    USBD_VID & 0x00FF,
    (USBD_VID & 0xFF00) >> 8,
                        /* idProduct */
                        USBD_PID & 0x00FF,
                        (USBD_PID & 0xFF00) >> 8,
                        0x00, 0x00,     /* bcdDevice */
                        0x01,           /* iManufacture */
                        0x02,           /* iProduct */
                        0x03,           /* iSerialNumber */
                        0x01            /* bNumConfigurations */
};

/*!<USB Configure Descriptor */
const uint8_t gu8ConfigDescriptor[] =
{
    LEN_CONFIG,     /* bLength */
    DESC_CONFIG,    /* bDescriptorType */
    /* wTotalLength */
    LEN_CONFIG_AND_SUBORDINATE & 0x00FF,
    (LEN_CONFIG_AND_SUBORDINATE & 0xFF00) >> 8,
    NUM_USB_INTERFACE,
                    /* bNumInterfaces */
    0x01,           /* bConfigurationValue */
    0x00,           /* iConfiguration */
    0x80 | (USBD_SELF_POWERED << 6) | (USBD_REMOTE_WAKEUP << 5),/* bmAttributes */
    USBD_MAX_POWER,         /* MaxPower */

    /* I/F descr: HID */
    LEN_INTERFACE,  /* bLength */
    DESC_INTERFACE, /* bDescriptorType */
    0x00,           /* bInterfaceNumber */
    0x00,           /* bAlternateSetting */
    0x02,           /* bNumEndpoints */
    0x03,           /* bInterfaceClass */
    0x00,           /* bInterfaceSubClass */
    0x00,           /* bInterfaceProtocol */
    0x00,           /* iInterface */

    /* HID Descriptor */
    LEN_HID,        /* Size of this descriptor in UINT8s. */
    DESC_HID,       /* HID descriptor type. */
    0x11, 0x01,     /* HID Class Spec. release number. */
    0x00,           /* H/W target country. */
    0x01,           /* Number of HID class descriptors to follow. */
    DESC_HID_RPT,   /* Descriptor type. */
    /* Total length of report descriptor. */
    sizeof(HID_DeviceReportDescriptor) & 0x00FF,
    (sizeof(HID_DeviceReportDescriptor) & 0xFF00) >> 8,

    /* EP Descriptor: interrupt in. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (INT_IN_EP_NUM | EP_INPUT), /* bEndpointAddress */
    EP_INT,         /* bmAttributes */
    /* wMaxPacketSize */
    EP2_MAX_PKT_SIZE & 0x00FF,
    (EP2_MAX_PKT_SIZE & 0xFF00) >> 8,
    HID_DEFAULT_INT_IN_INTERVAL,        /* bInterval */

    /* EP Descriptor: interrupt out. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (INT_OUT_EP_NUM | EP_OUTPUT),   /* bEndpointAddress */
    EP_INT,         /* bmAttributes */
    /* wMaxPacketSize */
    EP3_MAX_PKT_SIZE & 0x00FF,
    (EP3_MAX_PKT_SIZE & 0xFF00) >> 8,
    HID_DEFAULT_INT_IN_INTERVAL,    /* bInterval */

    /* I/F descr: HID */
    LEN_INTERFACE,  /* bLength */
    DESC_INTERFACE, /* bDescriptorType */
    USB_INTERFACE_NUM_STRIP_A,
                    /* bInterfaceNumber */
    0x00,           /* bAlternateSetting */
    0x01,           /* bNumEndpoints */
    0x03,           /* bInterfaceClass */
    0x00,           /* bInterfaceSubClass */
    0x00,           /* bInterfaceProtocol */
    USB_STRINDINDEX_NUM_STRIP_A,
                    /* iInterface */

    /* HID Descriptor */
    LEN_HID,        /* Size of this descriptor in UINT8s. */
    DESC_HID,       /* HID descriptor type. */
    0x11, 0x01,     /* HID Class Spec. release number. */
    0x00,           /* H/W target country. */
    0x01,           /* Number of HID class descriptors to follow. */
    DESC_HID_RPT,   /* Descriptor type. */
    /* Total length of report descriptor. */
    sizeof(HID_DynamicLightingReportDescriptor_Strip_A) & 0x00FF,
    (sizeof(HID_DynamicLightingReportDescriptor_Strip_A) & 0xFF00) >> 8,

    /* EP Descriptor: control in. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (CTRL_IN_STRIP_A_EP_NUM | EP_INPUT),
                    /* bEndpointAddress */
    0x00,           /* bmAttributes */
    /* wMaxPacketSize */
    EP0_MAX_PKT_SIZE & 0x00FF,
    (EP0_MAX_PKT_SIZE & 0xFF00) >> 8,
    0,              /* bInterval */

    /* I/F descr: HID */
    LEN_INTERFACE,  /* bLength */
    DESC_INTERFACE, /* bDescriptorType */
    USB_INTERFACE_NUM_STRIP_B,
                    /* bInterfaceNumber */
    0x00,           /* bAlternateSetting */
    0x01,           /* bNumEndpoints */
    0x03,           /* bInterfaceClass */
    0x00,           /* bInterfaceSubClass */
    0x00,           /* bInterfaceProtocol */
    USB_STRINDINDEX_NUM_STRIP_B,
                    /* iInterface */

    /* HID Descriptor */
    LEN_HID,        /* Size of this descriptor in UINT8s. */
    DESC_HID,       /* HID descriptor type. */
    0x11, 0x01,     /* HID Class Spec. release number. */
    0x00,           /* H/W target country. */
    0x01,           /* Number of HID class descriptors to follow. */
    DESC_HID_RPT,   /* Descriptor type. */
    /* Total length of report descriptor. */
    sizeof(HID_DynamicLightingReportDescriptor_Strip_B) & 0x00FF,
    (sizeof(HID_DynamicLightingReportDescriptor_Strip_B) & 0xFF00) >> 8,

    /* EP Descriptor: control in. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (CTRL_IN_STRIP_B_EP_NUM | EP_INPUT),
                    /* bEndpointAddress */
    0x00,           /* bmAttributes */
    /* wMaxPacketSize */
    EP0_MAX_PKT_SIZE & 0x00FF,
    (EP0_MAX_PKT_SIZE & 0xFF00) >> 8,
    0,              /* bInterval */

    /* I/F descr: HID */
    LEN_INTERFACE,  /* bLength */
    DESC_INTERFACE, /* bDescriptorType */
    USB_INTERFACE_NUM_STRIP_C,
                    /* bInterfaceNumber */
    0x00,           /* bAlternateSetting */
    0x01,           /* bNumEndpoints */
    0x03,           /* bInterfaceClass */
    0x00,           /* bInterfaceSubClass */
    0x00,           /* bInterfaceProtocol */
    USB_STRINDINDEX_NUM_STRIP_C,
                    /* iInterface */

    /* HID Descriptor */
    LEN_HID,        /* Size of this descriptor in UINT8s. */
    DESC_HID,       /* HID descriptor type. */
    0x11, 0x01,     /* HID Class Spec. release number. */
    0x00,           /* H/W target country. */
    0x01,           /* Number of HID class descriptors to follow. */
    DESC_HID_RPT,   /* Descriptor type. */
    /* Total length of report descriptor. */
    sizeof(HID_DynamicLightingReportDescriptor_Strip_C) & 0x00FF,
    (sizeof(HID_DynamicLightingReportDescriptor_Strip_C) & 0xFF00) >> 8,

    /* EP Descriptor: control in. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (CTRL_IN_STRIP_C_EP_NUM | EP_INPUT),
                    /* bEndpointAddress */
    0x00,           /* bmAttributes */
    /* wMaxPacketSize */
    EP0_MAX_PKT_SIZE & 0x00FF,
    (EP0_MAX_PKT_SIZE & 0xFF00) >> 8,
    0,              /* bInterval */

    /* I/F descr: HID */
    LEN_INTERFACE,  /* bLength */
    DESC_INTERFACE, /* bDescriptorType */
    USB_INTERFACE_NUM_STRIP_D,
                    /* bInterfaceNumber */
    0x00,           /* bAlternateSetting */
    0x01,           /* bNumEndpoints */
    0x03,           /* bInterfaceClass */
    0x00,           /* bInterfaceSubClass */
    0x00,           /* bInterfaceProtocol */
    USB_STRINDINDEX_NUM_STRIP_D,
                    /* iInterface */

    /* HID Descriptor */
    LEN_HID,        /* Size of this descriptor in UINT8s. */
    DESC_HID,       /* HID descriptor type. */
    0x11, 0x01,     /* HID Class Spec. release number. */
    0x00,           /* H/W target country. */
    0x01,           /* Number of HID class descriptors to follow. */
    DESC_HID_RPT,   /* Descriptor type. */
    /* Total length of report descriptor. */
    sizeof(HID_DynamicLightingReportDescriptor_Strip_D) & 0x00FF,
    (sizeof(HID_DynamicLightingReportDescriptor_Strip_D) & 0xFF00) >> 8,

    /* EP Descriptor: control in. */
    LEN_ENDPOINT,   /* bLength */
    DESC_ENDPOINT,  /* bDescriptorType */
    (CTRL_IN_STRIP_D_EP_NUM | EP_INPUT),
                    /* bEndpointAddress */
    0x00,           /* bmAttributes */
    /* wMaxPacketSize */
    EP0_MAX_PKT_SIZE & 0x00FF,
    (EP0_MAX_PKT_SIZE & 0xFF00) >> 8,
    0,              /* bInterval */
};

/*!<USB Language String Descriptor */
const uint8_t gu8StringLang[4] =
{
    4,              /* bLength */

    DESC_STRING,    /* bDescriptorType */
    0x09, 0x04
};

/*!<USB Vendor String Descriptor */
const uint8_t gu8VendorStringDesc[] =
{
    16,
    DESC_STRING,
    'N', 0, 'u', 0, 'v', 0, 'o', 0, 't', 0, 'o', 0, 'n', 0
};

/*!<USB Product String Descriptor */
const uint8_t gu8ProductStringDesc[] =
{
    26,             /* bLength          */
    DESC_STRING,    /* bDescriptorType  */
    'L', 0, 'E', 0, 'D', 0, ' ', 0, 'L', 0, 'i', 0, 'g', 0, 'h', 0, 't', 0, 'i', 0, 'n', 0, 'g', 0
};



const uint8_t gu8StringSerial[26] =
{
    26,             // bLength
    DESC_STRING,    // bDescriptorType
    'A', 0, '0', 0, '2', 0, '0', 0, '2', 0, '4', 0, '0', 0, '1', 0, '0', 0, '1', 0, '0', 0, '0', 0
};

/*!<USB Interface String Descriptor */
const uint8_t gu8DynamicStringDesc_Strip_A[] =
{
    14,             /* bLength          */
    DESC_STRING,    /* bDescriptorType  */
    'S', 0, 't', 0, 'r', 0, 'i', 0, 'p', 0, 'A', 0,
};

/*!<USB Interface String Descriptor */
const uint8_t gu8DynamicStringDesc_Strip_B[] =
{
    14,             /* bLength          */
    DESC_STRING,    /* bDescriptorType  */
    'S', 0, 't', 0, 'r', 0, 'i', 0, 'p', 0, 'B', 0,
};

/*!<USB Interface String Descriptor */
const uint8_t gu8DynamicStringDesc_Strip_C[] =
{
    14,             /* bLength          */
    DESC_STRING,    /* bDescriptorType  */
    'S', 0, 't', 0, 'r', 0, 'i', 0, 'p', 0, 'C', 0,
};

/*!<USB Interface String Descriptor */
const uint8_t gu8DynamicStringDesc_Strip_D[] =
{
    14,             /* bLength          */
    DESC_STRING,    /* bDescriptorType  */
    'S', 0, 't', 0, 'r', 0, 'i', 0, 'p', 0, 'D', 0,
};

const uint8_t *gpu8UsbString[NUM_USB_STRING_DESCRIPTOR] =
{
    gu8StringLang,
    gu8VendorStringDesc,
    gu8ProductStringDesc,
    gu8StringSerial,
    gu8DynamicStringDesc_Strip_A,
    gu8DynamicStringDesc_Strip_B,
    gu8DynamicStringDesc_Strip_C,
    gu8DynamicStringDesc_Strip_D,
};

const uint8_t *gpu8UsbHidReport[NUM_USB_HID_REPORT_DESCRIPTOR] =
{
    HID_DeviceReportDescriptor,
    HID_DynamicLightingReportDescriptor_Strip_A,
    HID_DynamicLightingReportDescriptor_Strip_B,
    HID_DynamicLightingReportDescriptor_Strip_C,
    HID_DynamicLightingReportDescriptor_Strip_D,
    NULL
};

const uint32_t gu32UsbHidReportLen[NUM_USB_HID_REPORT_DESCRIPTOR] =
{
    sizeof(HID_DeviceReportDescriptor),
    sizeof(HID_DynamicLightingReportDescriptor_Strip_A),
    sizeof(HID_DynamicLightingReportDescriptor_Strip_B),
    sizeof(HID_DynamicLightingReportDescriptor_Strip_C),
    sizeof(HID_DynamicLightingReportDescriptor_Strip_D),
    0
};

const uint32_t gu32ConfigHidDescIdx[NUM_USB_HID_REPORT_DESCRIPTOR] =
{
    (LEN_CONFIG + LEN_INTERFACE),
    USB_CONFIG_HID_INDEX_STRIP_A,
    USB_CONFIG_HID_INDEX_STRIP_B,
    USB_CONFIG_HID_INDEX_STRIP_C,
    USB_CONFIG_HID_INDEX_STRIP_D,
    0
};

#ifdef SUPPORT_LPM
const uint8_t gu8BosDescriptor[] =
{
    LEN_BOS,        /* bLength */
    DESC_BOS,       /* bDescriptorType */
    /* wTotalLength */
    0x0C & 0x00FF,
    (0x0C & 0xFF00) >> 8,
    0x01,           /* bNumDeviceCaps */

    /* Device Capability */
    LEN_DEVCAP,     /* bLength */
    DESC_DEVCAP,/* bDescriptorType */
    0x02,  /* bDevCapabilityType, 0x02 is USB 2.0 Extension */
    0x06, 0x04, 0x00, 0x00  /* bmAttributes, 32 bits */
                            /* bit 0 : Reserved. Must 0. */
                            /* bit 1 : 1 to support LPM. */
                            /* bit 2 : 1 to support BSL & Alternat HIRD. */
                            /* bit 3 : 1 to recommend Baseline BESL. */
                            /* bit 4 : 1 to recommand Deep BESL. */
                            /* bit 11:8 : Recommend Baseline BESL value. Ignore by bit3 is zero. */
                            /* bit 15:12 : Recommend Deep BESL value. Ignore by bit4 is zero. */
                            /* bit 31:16 : Reserved. Must 0. */
};
#endif

const S_USBD_INFO_T gsInfo =
{
    gu8DeviceDescriptor,
    gu8ConfigDescriptor,
    gpu8UsbString,
    gpu8UsbHidReport,
    gu32UsbHidReportLen,
    gu32ConfigHidDescIdx,
#ifdef SUPPORT_LPM
    gu8BosDescriptor
#else
    NULL
#endif
};

