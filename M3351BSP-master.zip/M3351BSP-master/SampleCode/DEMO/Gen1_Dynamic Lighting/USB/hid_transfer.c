/******************************************************************************//**
 * @file     hid_transfer.c
 * @version  V0.10
 * @brief    HID command transfer source file
 *
 * @copyright (C) 2018 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

/*!<Includes */
#include <stdio.h>
#include <string.h>
#include "device.h"
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "LED_Control.h"
#include "Flash.h"
#include "Platform_usbd.h"
#include "hid_transfer.h"
#include "OLED_Control.h"

uint8_t SendBuffer[512];
uint8_t RcvBuffer[512];

volatile uint8_t set_report_flag = 0;
extern volatile uint32_t g_usbd_CtrlOutSize;
extern volatile uint32_t g_usbd_CtrlOutSizeLimit;

uint8_t g_u8Idle = 0, g_u8Protocol = 0;

/* Dynamic Lighting: LampArrayAttributes */
const uint32_t LampArrayAttributes[TOTAL_LED_AREA][LAMPARRAYATTRIBUTES_USAGECOUNT]
    = {
       {WIDTH_MICROMETER_STRIP_A,          // BoundingBoxWidthInMicrometers
        HEIGHT_MICROMETER_STRIP_A,         // BoundingBoxHeightInMicrometers
        DEPTH_MICROMETER_STRIP_A,          // BoundingBoxDepthInMicrometers
        LAMPARRAYKIND_STRIP_A,             // LampArrayKind
        UPDATEINTERVAL_MICROSEC_STRIP_A},  // MinUpdateIntervalInMicroseconds
       {WIDTH_MICROMETER_STRIP_B,          // BoundingBoxWidthInMicrometers
        HEIGHT_MICROMETER_STRIP_B,         // BoundingBoxHeightInMicrometers
        DEPTH_MICROMETER_STRIP_B,          // BoundingBoxDepthInMicrometers
        LAMPARRAYKIND_STRIP_B,             // LampArrayKind
        UPDATEINTERVAL_MICROSEC_STRIP_B},  // MinUpdateIntervalInMicroseconds
       {WIDTH_MICROMETER_STRIP_C,          // BoundingBoxWidthInMicrometers
        HEIGHT_MICROMETER_STRIP_C,         // BoundingBoxHeightInMicrometers
        DEPTH_MICROMETER_STRIP_C,          // BoundingBoxDepthInMicrometers
        LAMPARRAYKIND_STRIP_C,             // LampArrayKind
        UPDATEINTERVAL_MICROSEC_STRIP_C},  // MinUpdateIntervalInMicroseconds
       {WIDTH_MICROMETER_STRIP_D,          // BoundingBoxWidthInMicrometers
        HEIGHT_MICROMETER_STRIP_D,         // BoundingBoxHeightInMicrometers
        DEPTH_MICROMETER_STRIP_D,          // BoundingBoxDepthInMicrometers
        LAMPARRAYKIND_STRIP_D,             // LampArrayKind
        UPDATEINTERVAL_MICROSEC_STRIP_D},  // MinUpdateIntervalInMicroseconds
      };

/* Dynamic Lighting: LampAttributesResponse */
const uint32_t LampAttributesReponse[TOTAL_LED_AREA][LAMPATTRIBUTESRESPONSE_USAGECOUNT]
    = {
       {POSITION_START_X_STRIP_A,          // PositionXInMicrometers
        POSITION_START_Y_STRIP_A,          // PositionYInMicrometers
        POSITION_START_Z_STRIP_A,          // PositionZInMicrometers
        UPDATELATENCY_MICROSEC_STRIP_A,    // UpdateLatencyInMicroseconds
        LAMPPURPOSE_STRIP_A},              // LampPurposes
       {POSITION_START_X_STRIP_B,          // PositionXInMicrometers
        POSITION_START_Y_STRIP_B,          // PositionYInMicrometers
        POSITION_START_Z_STRIP_B,          // PositionZInMicrometers
        UPDATELATENCY_MICROSEC_STRIP_B,    // UpdateLatencyInMicroseconds
        LAMPPURPOSE_STRIP_B},              // LampPurposes
       {POSITION_START_X_STRIP_C,          // PositionXInMicrometers
        POSITION_START_Y_STRIP_C,          // PositionYInMicrometers
        POSITION_START_Z_STRIP_C,          // PositionZInMicrometers
        UPDATELATENCY_MICROSEC_STRIP_C,    // UpdateLatencyInMicroseconds
        LAMPPURPOSE_STRIP_C},              // LampPurposes
       {POSITION_START_X_STRIP_D,          // PositionXInMicrometers
        POSITION_START_Y_STRIP_D,          // PositionYInMicrometers
        POSITION_START_Z_STRIP_D,          // PositionZInMicrometers
        UPDATELATENCY_MICROSEC_STRIP_D,    // UpdateLatencyInMicroseconds
        LAMPPURPOSE_STRIP_D},              // LampPurposes
      };
const uint32_t LampAttributesPosition[TOTAL_LED_AREA][3]
    = {
       {POSITION_OFFSET_X_STRIP_A,         // PositionXInMicrometers
        POSITION_OFFSET_Y_STRIP_A,         // PositionYInMicrometers
        POSITION_OFFSET_Z_STRIP_A},        // PositionZInMicrometers
       {POSITION_OFFSET_X_STRIP_B,         // PositionXInMicrometers
        POSITION_OFFSET_Y_STRIP_B,         // PositionYInMicrometers
        POSITION_OFFSET_Z_STRIP_B},        // PositionZInMicrometers
       {POSITION_OFFSET_X_STRIP_C,         // PositionXInMicrometers
        POSITION_OFFSET_Y_STRIP_C,         // PositionYInMicrometers
        POSITION_OFFSET_Z_STRIP_C},        // PositionZInMicrometers
       {POSITION_OFFSET_X_STRIP_D,         // PositionXInMicrometers
        POSITION_OFFSET_Y_STRIP_D,         // PositionYInMicrometers
        POSITION_OFFSET_Z_STRIP_D},        // PositionZInMicrometers
      };

void USBD_IRQHandler(void)
{
    uint32_t u32IntSts = USBD_GET_INT_FLAG();
    uint32_t u32State = USBD_GET_BUS_STATE();

    //------------------------------------------------------------------
    if (u32IntSts & USBD_INTSTS_FLDET)
    {
        // Floating detect
        USBD_CLR_INT_FLAG(USBD_INTSTS_FLDET);

        if (USBD_IS_ATTACHED())
        {
            /* USB Plug In */
            USBD_ENABLE_USB();
        }
        else
        {
            /* USB Un-plug */
            USBD_DISABLE_USB();

            for(uint8_t i = 0; i < TOTAL_LED_AREA; i++)
            {
                /* Enable Autonomous mode when USB is disconnected with Dynamic Lighting control */
                LED_Mapping[i]->Autonomous_Flag = TRUE;
            }
        }
    }

    //------------------------------------------------------------------
    if (u32IntSts & USBD_INTSTS_BUS)
    {
        /* Clear event flag */
        USBD_CLR_INT_FLAG(USBD_INTSTS_BUS);

        if (u32State & USBD_STATE_USBRST)
        {
            /* Bus reset */
            USBD_ENABLE_USB();
            USBD_SwReset();
        }

        if (u32State & USBD_STATE_SUSPEND)
        {
            /* Enable USB but disable PHY */
            USBD_DISABLE_PHY();
        }

        if (u32State & USBD_STATE_RESUME)
        {
            /* Enable USB and enable PHY */
            USBD_ENABLE_USB();
        }
    }

    //------------------------------------------------------------------
    if (u32IntSts & USBD_INTSTS_USB)
    {
        // USB event
        if (u32IntSts & USBD_INTSTS_SETUP)
        {
            // Setup packet
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_SETUP);

            /* Clear the data IN/OUT ready flag of control end-points */
            USBD_STOP_TRANSACTION(EP0);
            USBD_STOP_TRANSACTION(EP1);

            USBD_ProcessSetupPacket();
        }

        // EP events
        if (u32IntSts & USBD_INTSTS_EP0)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP0);
            // control IN
            USBD_CtrlIn();
        }

        if (u32IntSts & USBD_INTSTS_EP1)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP1);

            // control OUT
            USBD_CtrlOut();

            uint8_t target_port;
            if((set_report_flag == 1) && (g_usbd_CtrlOutSize >= g_usbd_CtrlOutSizeLimit))
            {
                /* Check Report ID */
                for(target_port = 0; target_port < TOTAL_LED_AREA; target_port++)
                {
                    /* AP Sync */
                    if(RcvBuffer[0] == REPORT_ID_FEATURE_LEDAPSYNC)
                    {
                        /* Get Area Number */
                        uint16_t u16Temp = (uint16_t)(RcvBuffer[1] | (RcvBuffer[2] << 8));

                        /* Get AP Sync LED Data */
                        if(u16Temp & (BIT0 << target_port))
                        {
                            if(LED_Mapping[target_port]->AP_Sync == TRUE)
                            {
                                USBD_MemCopy(LED_Mapping[target_port]->LED_Data, &RcvBuffer[3], LED_Mapping[target_port]->LEDNum * 3);
                            }
                        }

                    }
                    /* Dynamic Lighting: LampAttributesRequest */
                    else if(RcvBuffer[0] == (REPORT_ID_FEATURE_LAMP_ATTRIBUTESREQUEST + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
                    {
                        /* LampId */
                        uint16_t lampid;
                        lampid = (RcvBuffer[2] << 8) | RcvBuffer[1];
                        /* Check LampId */
                        if(lampid < LED_Number_Limit[target_port])
                            LED_Mapping[target_port]->Target_LampID = lampid;

                        break;
                    }
                    /* Dynamic Lighting: LampMultiUpdate */
                    else if(RcvBuffer[0] == (REPORT_ID_FEATURE_LAMP_MULTIUPDATE + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
                    {
                        /* LampCount */
                        uint8_t lampcout = RcvBuffer[1];
                        /* LampId */
                        uint16_t lampid[lampcout];
                        uint8_t i;
                        for(i = 0; i < lampcout; i++)
                        {
                            lampid[i] = (RcvBuffer[4 + 2*i] << 8) | RcvBuffer[3 + 2*i];
                            /* Check if LampId is over the max LampCount */
                            if(lampid[i] >= LED_Number_Limit[target_port])
                                break;
                        }
                        /* All LampId is in valid range */
                        if(i == lampcout)
                        {
                            /* Check if identical LampId in multiple slots */
                            if(Check_Repeat(lampid, lampcout) == 0)
                            {
                                /* RedUpdateChannel, GreenUpdateChannel, BlueUpdateChannel and IntensityUpdateChannel to target LampId */
                                for(i = 0; i < lampcout; i++)
                                {
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].RedUpdate       = RcvBuffer[19 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].GreenUpdate     = RcvBuffer[20 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].BlueUpdate      = RcvBuffer[21 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].IntensityUpdate = RcvBuffer[22 + 4*i];
                                }

                                /* LampUpdateFlags */
                                LED_Mapping[target_port]->Dynamic_Update_Flag = RcvBuffer[2];
                            }
                        }

                        break;
                    }
                    /* Dynamic Lighting: LampMultiUpdate */
                    else if(RcvBuffer[0] == (REPORT_ID_FEATURE_LAMP_RANGEUPDATE + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
                    {
                        /* LampIdStart */
                        uint16_t start = (RcvBuffer[3] << 8) | RcvBuffer[2];
                        /* LampIdEnd */
                        uint16_t end = (RcvBuffer[5] << 8) | RcvBuffer[4];
                        /* Check if LampIdStart is larger than LampIdEnd */
                        if(start <= end)
                        {
                            /* Check if LampIdStart or LampIdEnd is over the max LampCount */
                            if((start < LED_Number_Limit[target_port]) && (end < LED_Number_Limit[target_port]))
                            {
                                for(uint16_t i = start; i < (end+1); i++)
                                {
                                    LED_Mapping[target_port]->DynamicData[i].RedUpdate       = RcvBuffer[6];
                                    LED_Mapping[target_port]->DynamicData[i].GreenUpdate     = RcvBuffer[7];
                                    LED_Mapping[target_port]->DynamicData[i].BlueUpdate      = RcvBuffer[8];
                                    LED_Mapping[target_port]->DynamicData[i].IntensityUpdate = RcvBuffer[9];
                                }

                                /* LampUpdateFlags */
                                LED_Mapping[target_port]->Dynamic_Update_Flag = RcvBuffer[1];
                            }
                        }

                        break;
                    }
                    /* Dynamic Lighting: LampArrayControl */
                    else if(RcvBuffer[0] == (REPORT_ID_FEATURE_LAMPARRAY_CONTROL + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
                    {
                        /* AutonomousMode */
                        LED_Mapping[target_port]->Autonomous_Flag = RcvBuffer[1];

                        break;
                    }
                }

                set_report_flag = 0;
            }
        }

        if (u32IntSts & USBD_INTSTS_EP2)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP2);
            // Interrupt IN
            EP2_Handler();
        }

        if (u32IntSts & USBD_INTSTS_EP3)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP3);
            // Interrupt OUT
            EP3_Handler();
        }

        if (u32IntSts & USBD_INTSTS_EP4)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP4);
        }

        if (u32IntSts & USBD_INTSTS_EP5)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP5);
        }

        if (u32IntSts & USBD_INTSTS_EP6)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP6);
        }

        if (u32IntSts & USBD_INTSTS_EP7)
        {
            /* Clear event flag */
            USBD_CLR_INT_FLAG(USBD_INTSTS_EP7);
        }
    }
}

void EP2_Handler(void)  /* Interrupt IN handler */
{
 
}

void EP3_Handler(void)  /* Interrupt OUT handler */
{
    uint8_t *ptr;
    /* Interrupt OUT */
    ptr = (uint8_t *)(USBD_BUF_BASE + USBD_GET_EP_BUF_ADDR(EP3));

    /* Check Command Type */
    if(*ptr == REPORT_ID_IN_OUT_GENERAL_CMD)
    {
        HID_Get_General_CMD(ptr, USBD_GET_PAYLOAD_LEN(EP3));
    }
    else if(*ptr == REPORT_ID_IN_OUT_LEDSETSTRIP)
    {
        HID_Get_LEDSetStrip_CMD(ptr, USBD_GET_PAYLOAD_LEN(EP3));
    }
    else if(*ptr == REPORT_ID_IN_OUT_LEDSETMODE)
    {
        HID_Set_LEDMode_CMD(ptr, USBD_GET_PAYLOAD_LEN(EP3));
    }

    USBD_SET_PAYLOAD_LEN(EP3, EP3_MAX_PKT_SIZE);
}


/*--------------------------------------------------------------------------*/
/**
  * @brief  USBD Endpoint Config.
  * @param  None.
  * @retval None.
  */
void HID_Init(void)
{
    /* Init setup packet buffer */
    /* Buffer range for setup packet -> [0 ~ 0x7] */
    USBD->STBUFSEG = SETUP_BUF_BASE;

    /*****************************************************/
    /* EP0 ==> control IN endpoint, address 0 */
    USBD_CONFIG_EP(EP0, USBD_CFG_CSTALL | USBD_CFG_EPMODE_IN | 0);
    /* Buffer range for EP0 */
    USBD_SET_EP_BUF_ADDR(EP0, EP0_BUF_BASE);

    /* EP1 ==> control OUT endpoint, address 0 */
    USBD_CONFIG_EP(EP1, USBD_CFG_CSTALL | USBD_CFG_EPMODE_OUT | 0);
    /* Buffer range for EP1 */
    USBD_SET_EP_BUF_ADDR(EP1, EP1_BUF_BASE);

    /*****************************************************/
    /* EP2 ==> Interrupt IN endpoint, address 1 */
    USBD_CONFIG_EP(EP2, USBD_CFG_EPMODE_IN | INT_IN_EP_NUM);
    /* Buffer range for EP2 */
    USBD_SET_EP_BUF_ADDR(EP2, EP2_BUF_BASE);

    /* EP3 ==> Interrupt OUT endpoint, address 2 */
    USBD_CONFIG_EP(EP3, USBD_CFG_EPMODE_OUT | INT_OUT_EP_NUM);
    /* Buffer range for EP3 */
    USBD_SET_EP_BUF_ADDR(EP3, EP3_BUF_BASE);
    /* trigger to receive OUT data */
    USBD_SET_PAYLOAD_LEN(EP3, EP3_MAX_PKT_SIZE);

}

uint8_t g_SendLen;
int32_t HID_CtrlSetupGetReport(void)
{
    uint8_t buf[8];
    uint16_t len;
    uint8_t i;
    uint8_t target_port;

    USBD_MemCopy(buf, (uint8_t *)USBD_BUF_BASE, 8);

    /* Check report ID */
    for(target_port = 0; target_port < TOTAL_LED_AREA; target_port++)
    {
        /* Dynamic Lighting: LampArrayAttributes */
        if(buf[2] == (REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
        {
            /* Report ID */
            SendBuffer[0] = REPORT_ID_FEATURE_LAMPARRAY_ATTRIBUTES + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port);
            /* LampCount */
            SendBuffer[1] = (uint8_t)((LED_Number_Limit[target_port] & 0x00FF)     );
            SendBuffer[2] = (uint8_t)((LED_Number_Limit[target_port] & 0xFF00) >> 8);
            /* BoundingBoxWidthInMicrometers */
            SendBuffer[3] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x000000FF)      );
            SendBuffer[4] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x0000FF00) >>  8);
            SendBuffer[5] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x00FF0000) >> 16);
            SendBuffer[6] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0xFF000000) >> 24);
            /* BoundingBoxHeightInMicrometers */
            SendBuffer[7]  = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x000000FF)      );
            SendBuffer[8]  = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x0000FF00) >>  8);
            SendBuffer[9]  = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x00FF0000) >> 16);
            SendBuffer[10] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0xFF000000) >> 24);
            /* BoundingBoxDepthInMicrometers */
            SendBuffer[11] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x000000FF)      );
            SendBuffer[12] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x0000FF00) >>  8);
            SendBuffer[13] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x00FF0000) >> 16);
            SendBuffer[14] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0xFF000000) >> 24);
            /* LampArrayKind */
            SendBuffer[15] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x000000FF)      );
            SendBuffer[16] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x0000FF00) >>  8);
            SendBuffer[17] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x00FF0000) >> 16);
            SendBuffer[18] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0xFF000000) >> 24);
            /* MinUpdateIntervalInMicroseconds */
            SendBuffer[19] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x000000FF)      );
            SendBuffer[20] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x0000FF00) >>  8);
            SendBuffer[21] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x00FF0000) >> 16);
            SendBuffer[22] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0xFF000000) >> 24);

            g_SendLen = LAMPARRAY_ATTRIBUTES_REPORT_SIZE;

            break;
        }
        /* Dynamic Lighting: LampAttributesResponse */
        else if(buf[2] == (REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port)))
        {
            /* Report ID */
            SendBuffer[0] = REPORT_ID_FEATURE_LAMP_ATTRIBUTESRESPONSE + (REPORT_ID_FEATURE_LAMP_OFFSET*target_port);
            /* LampId */
            SendBuffer[1] = (uint8_t)((LED_Mapping[target_port]->Target_LampID & 0x00FF)     );
            SendBuffer[2] = (uint8_t)((LED_Mapping[target_port]->Target_LampID & 0xFF00) >> 8);
            /* PositionXInMicrometers */
            uint32_t position;
            position = LampAttributesReponse[target_port][PositionXInMicrometers] + \
                       LampAttributesPosition[target_port][PositionXInMicrometers]*LED_Mapping[target_port]->Target_LampID;
            SendBuffer[3] = (uint8_t)((position & 0x000000FF)      );
            SendBuffer[4] = (uint8_t)((position & 0x0000FF00) >>  8);
            SendBuffer[5] = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[6] = (uint8_t)((position & 0xFF000000) >> 24);
            /* PositionYInMicrometers */
            position = LampAttributesReponse[target_port][PositionYInMicrometers] + \
                       LampAttributesPosition[target_port][PositionYInMicrometers]*LED_Mapping[target_port]->Target_LampID;
            SendBuffer[7]  = (uint8_t)((position & 0x000000FF)      );
            SendBuffer[8]  = (uint8_t)((position & 0x0000FF00) >>  8);
            SendBuffer[9]  = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[10] = (uint8_t)((position & 0xFF000000) >> 24);
            /* PositionZInMicrometers */
            position = LampAttributesReponse[target_port][PositionZInMicrometers] + \
                       LampAttributesPosition[target_port][PositionZInMicrometers]*LED_Mapping[target_port]->Target_LampID;
            SendBuffer[11] = (uint8_t)((position & 0x000000FF)      );
            SendBuffer[12] = (uint8_t)((position & 0x0000FF00) >>  8);
            SendBuffer[13] = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[14] = (uint8_t)((position & 0xFF000000) >> 24);
            /* UpdateLatencyInMicroseconds */
            SendBuffer[15] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x000000FF)      );
            SendBuffer[16] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x0000FF00) >>  8);
            SendBuffer[17] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x00FF0000) >> 16);
            SendBuffer[18] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0xFF000000) >> 24);
            /* LampPurposes */
            SendBuffer[19] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x000000FF)      );
            SendBuffer[20] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x0000FF00) >>  8);
            SendBuffer[21] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x00FF0000) >> 16);
            SendBuffer[22] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0xFF000000) >> 24);
            /* RedLevelCount */
            SendBuffer[23] = MAX_LEVEL_COLOR_R;
            /* GreenLevelCount */
            SendBuffer[24] = MAX_LEVEL_COLOR_G;
            /* BlueLevelCount */
            SendBuffer[25] = MAX_LEVEL_COLOR_B;
            /* IntensityLevelCount */
            SendBuffer[26] = MAX_LEVEL_COLOR_BRIGHTNESS;
            /* IsProgrammable */
            SendBuffer[27] = 0x01;
            /* InputBinding */
            SendBuffer[28] = 0x00;

            /* Increment LampID automatically */
            LED_Mapping[target_port]->Target_LampID += 1;
            if(LED_Mapping[target_port]->Target_LampID == LED_Number_Limit[target_port])
                LED_Mapping[target_port]->Target_LampID = 0;    // Reset LampID to 0

            g_SendLen = LAMP_ATTRIBUTESRESPONSE_REPORT_SIZE;

            break;
        }
    }

    /* Find no valid report ID */
    if(target_port == TOTAL_LED_AREA)
    {
        USBD_SetStall(0);
        USBD_SetStall(1);
        return FALSE;
    }

    len = (buf[7] << 8) | buf[6];
    if(len >= g_SendLen)
        len = g_SendLen;

    USBD_PrepareCtrlIn((uint8_t *)&SendBuffer[0], len);
    USBD_PrepareCtrlOut(0,0);

    return TRUE;
}

int32_t HID_CtrlSetupSetReport(void)
{
    uint8_t buf[8];
    uint8_t report_type;
    uint32_t u32Len;

    USBD_MemCopy(buf, (uint8_t *)USBD_BUF_BASE, 8);
    report_type= buf[3];
    u32Len = (buf[7] << 8) | buf[6];

    if (report_type == 1)
    {
        /* EN: Report Type = input */
        // Trigger next Control Out DATA1 Transaction.
        USBD_SET_DATA1(EP1);
        USBD_SET_PAYLOAD_LEN(EP1, 0);

        //DBG_PRINTF(" - Input\n");
    }
    else if (report_type == 2)
    {
        /* EN: Report Type = Output */
        USBD_PrepareCtrlOut((uint8_t *)&RcvBuffer, u32Len);
        USBD_PrepareCtrlIn(0,0);

        //DBG_PRINTF(" - Output\n");
    }
    else if (report_type == 3)
    {
        /* Request Type = Feature */
//        USBD_SET_DATA1(EP1);
//        USBD_SET_PAYLOAD_LEN(EP1, 0);
        USBD_PrepareCtrlOut((uint8_t *)&RcvBuffer, u32Len);
        USBD_PrepareCtrlIn(0,0);

        set_report_flag = 1;
        //DBG_PRINTF(" - Feature\n");
    }
    else
    {
        // Not support. Reply STALL.
        USBD_SetStall(0);
        USBD_SetStall(1);

        //DBG_PRINTF(" - Unknown\n");
    }

    return TRUE;
}

void HID_ClassRequest(void)
{
    uint8_t u8Buf[8];

    USBD_GetSetupPacket(u8Buf);

    if (u8Buf[0] & 0x80)   /* request data transfer direction */
    {
        // Device to host
        switch (u8Buf[1])
        {
            case GET_REPORT:
            {
                HID_CtrlSetupGetReport();
                break;
            }
            case GET_IDLE:
            {
                USBD_SET_PAYLOAD_LEN(EP1, u8Buf[6]);
                /* Data stage */
                USBD_PrepareCtrlIn(&g_u8Idle, u8Buf[6]);
                /* Status stage */
                USBD_PrepareCtrlOut(0, 0);
                break;
            }
            case GET_PROTOCOL:
            {
                USBD_SET_PAYLOAD_LEN(EP1, u8Buf[6]);
                /* Data stage */
                USBD_PrepareCtrlIn(&g_u8Protocol, u8Buf[6]);
                /* Status stage */
                USBD_PrepareCtrlOut(0, 0);
                break;
            }
            default:
            {
                /* Setup error, stall the device */
                USBD_SetStall(EP0);
                USBD_SetStall(EP1);
                break;
            }
        }
    }
    else
    {
        // Host to device
        switch (u8Buf[1])
        {
            case SET_REPORT:
            {
                HID_CtrlSetupSetReport();
                break;
            }

            case SET_IDLE:
            {
                g_u8Idle = u8Buf[3];
                /* Status stage */
                USBD_SET_DATA1(EP0);
                USBD_SET_PAYLOAD_LEN(EP0, 0);
                break;
            }
            case SET_PROTOCOL:
            {
                g_u8Protocol = u8Buf[2];
                /* Status stage */
                USBD_SET_DATA1(EP0);
                USBD_SET_PAYLOAD_LEN(EP0, 0);
                break;
            }
            default:
            {
                // Stall
                /* Setup error, stall the device */
                USBD_SetStall(EP0);
                USBD_SetStall(EP1);
                break;
            }
        }
    }
}

/***************************************************************/
void HID_SetInReport(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t *ptr;

    /* Prepare the data for next HID IN transfer */
    ptr = (uint8_t *)(USBD_BUF_BASE + USBD_GET_EP_BUF_ADDR(EP2));
    USBD_MemCopy(ptr, pu8EpBuf, u32Size);
    USBD_SET_PAYLOAD_LEN(EP2, u32Size);
}

void HID_Get_General_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t u8Command;
    uint8_t	ReplyBuf[LEN_PACKET_GENERAL_CMD];
    uint32_t Checksum;
    uint8_t Area;
    uint8_t i;

    /* Get Command */
    u8Command = pu8EpBuf[1];

    switch(u8Command)
    {
        case HID_CMD_GET_FW_VERSION:
        {
            /* Report ID */
            ReplyBuf[0] = REPORT_ID_IN_OUT_GENERAL_CMD;
            /* Command: ACK */
            ReplyBuf[1] = HID_CMD_ACK;
            /* Version Major */
            ReplyBuf[2] = FW_VERSION_MAJOR;
            /* Version Minor */
            ReplyBuf[3] = FW_VERSION_MINOR;
            /* Reserved */
            for(i = 4; i < LEN_PACKET_GENERAL_CMD; i++)
                ReplyBuf[i] = 0x00;
 
            /* Prepare for HID IN */
            HID_SetInReport(ReplyBuf, LEN_PACKET_GENERAL_CMD);

            break;
        }
        case HID_CMD_GET_FW_CHECKSUM:
        {
            /* Read Checksum */
            SYS_UnlockReg();
            FMC_Open();
            FMC_ENABLE_AP_UPDATE();
            Checksum = FMC_Read(DATAFLASH_BASE_ADDR + OFFSET_CHECKSUM);
            FMC_DISABLE_AP_UPDATE();
            FMC_Close();
            SYS_LockReg();

            /* Report ID */
            ReplyBuf[0] = REPORT_ID_IN_OUT_GENERAL_CMD;
            /* Command: ACK */
            ReplyBuf[1] = HID_CMD_ACK;
            /* Checksum Low Byte */
            ReplyBuf[2] = (uint8_t)((Checksum >> 0) & 0xFF);
            /* Checksum High Byte */
            ReplyBuf[3] = (uint8_t)((Checksum >> 8) & 0xFF);
            /* Reserved */
            for(i = 4; i < LEN_PACKET_GENERAL_CMD; i++)
                ReplyBuf[i] = 0x00;
 
            /* Prepare for HID IN */
            HID_SetInReport(ReplyBuf, LEN_PACKET_GENERAL_CMD);

            break;
        }
        case HID_CMD_START_ISP:
        {
            /* Lower the protity of USB interrupt */
            NVIC_SetPriority(USBD_IRQn, INT_PRIORITY_LOW);

            /* Reset Lighting Bar */
            /* Wait for whole data transmission done */
            for(i = 0; i < TOTAL_LED_AREA; i++)
                while(LED_Mapping[i]->fPDMA_Done == 0);

            for(i = 0; i < TOTAL_LED_AREA; i++)
            {
                Clear_LED_Data(LED_Mapping[i]);
            }
            for(i = 0; i < TOTAL_LED_AREA; i++)
                while(!LED_Mapping[i]->fPDMA_Done);

            /* Show Updating on OLED */
            ssd1306_Fill(Black);
            ssd1306_SetCursor(START_POSITION_X, START_POSITION_Y[1]);
            ssd1306_WriteString("Updating FW...", STRING_FONT, White);
            ssd1306_UpdateScreen();

            /* Set the protity of USB interrupt */
            NVIC_SetPriority(USBD_IRQn, INT_PRIORITY_NORMAL);
            USBD->INTEN &= ~(USBD_INTEN_SOFIEN_Msk | USBD_INTEN_WKEN_Msk);

            /* Boot from LDROM */
            SYS_UnlockReg();
            FMC_Open();
            FMC->ISPCTL |= FMC_ISPCTL_BS_Msk;    // Boot from LDROM (set BS bit)
            NVIC->ICPR[0] = 0xFFFFFFFF;    // Clear Pending Interrupt
            /* Set VECMAP to LDROM for booting from LDROM */
            FMC_SetVectorPageAddr(FMC_LDROM_BASE);
            SYS_ResetCPU();

            break;
        }
        case HID_CMD_SET_VOLUME:
        {
            /* Change Current Setting */
            for(i = 0; i < TOTAL_LED_AREA; i++)
            {
                /* Main Volume */
                LED_Mapping[i]->Main_Volume  = pu8EpBuf[2];
                /* Left Volume */
                LED_Mapping[i]->Left_Volume  = pu8EpBuf[3];
                /* Right Volume */
                LED_Mapping[i]->Right_Volume = pu8EpBuf[4];
                /* Action*/
                LED_Mapping[i]->Music_Action = pu8EpBuf[5];
            }
            
            break;
        }
    }
}

void HID_Get_LEDSetStrip_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t i;
    uint16_t Area;

    /* Get Area Number */
    Area = (uint16_t)(pu8EpBuf[1] | (pu8EpBuf[2] << 8));

    /* Change Current Setting */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        if(Area & (1 << i))
        {
            /* LED Numbers */
            LED_Mapping[i]->LEDNum = (uint16_t)(pu8EpBuf[3] | (pu8EpBuf[4] << 8));
            if(LED_Mapping[i]->LEDNum > LED_Number_Limit[i])
                LED_Mapping[i]->LEDNum = LED_Number_Limit[i];
            /* LED_Type */
            LED_Mapping[i]->LED_Type = pu8EpBuf[5];
            /* Change LED RGB/GRB mode */
            HAL_Change_LED_Type(LED_Mapping[i]);
            /* Direction */
            LED_Mapping[i]->Direction = pu8EpBuf[6];
            /* AP Sync */
            LED_Mapping[i]->AP_Sync = pu8EpBuf[7];
            if(LED_Mapping[i]->AP_Sync)
            {
                memset((void *)LED_Mapping[i]->LED_Data, 0x00, LED_Mapping[i]->Array_Size);
            }

            /* Set Store Setting Flag */
            WriteSetting_Flag = 1;

            /* Reset Timer Counter */
            LED_Mapping[i]->TimeCounter = 0;
        }
    }
}

void HID_Set_LEDMode_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t i;
    uint16_t Area;

    /* Get Area Number */
    Area = (uint16_t)(pu8EpBuf[1] | (pu8EpBuf[2] << 8));

    /* Change Current Setting */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        if(Area & (1 << i))
        {
            /* Lighting Mode */
            LED_Mapping[i]->LightingMode = pu8EpBuf[3];
            if(LED_Mapping[i]->LightingMode >= LED_MODE_COUNT)
                LED_Mapping[i]->LightingMode = 0;
            LED_Mapping[i]->Mode_FUNC = (LED_FUNC)Mode_Function[LED_Mapping[i]->LightingMode];
            /* LED Color */
            LED_Mapping[i]->Color_R = pu8EpBuf[4];
            LED_Mapping[i]->Color_G = pu8EpBuf[5];
            LED_Mapping[i]->Color_B = pu8EpBuf[6];
            /* Brightness */
            LED_Mapping[i]->Brightness = pu8EpBuf[7];
            /* Speed */
            LED_Mapping[i]->Speed = pu8EpBuf[8];

            /* Set Store Setting Flag */
            WriteSetting_Flag = 1;

            /* Reset Timer Counter */
            LED_Mapping[i]->TimeCounter = 0;
            /* Reset ColorIndex */
            LED_Mapping[i]->ColorIndex = eColorRed;
        }
    }
}

int Check_Repeat(uint16_t *src, uint8_t size)
{
    uint8_t i, j;

    for(i = 0; i < size-1; i++)
    {
        for(j = i+1; j < size; j++)
        {
            if(src[i] == src[j])
                return 1;
        }
    }

    return 0;
}
