# 1 "../USB/hid_transfer.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 416 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "../USB/hid_transfer.c" 2
# 10 "../USB/hid_transfer.c"
# 1 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 1 3
# 53 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
    typedef unsigned int size_t;
# 68 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
    typedef __builtin_va_list __va_list;
# 87 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
typedef struct __fpos_t_struct {
    unsigned long long int __pos;





    struct {
        unsigned int __state1, __state2;
    } __mbstate;
} fpos_t;
# 108 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
typedef struct __FILE FILE;
# 119 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
struct __FILE {
    union {
        long __FILE_alignment;



        char __FILE_size[84];

    } __FILE_opaque;
};
# 138 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern FILE __stdin, __stdout, __stderr;
extern FILE *__aeabi_stdin, *__aeabi_stdout, *__aeabi_stderr;
# 224 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int remove(const char * ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) int rename(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 243 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) FILE *tmpfile(void);






extern __attribute__((__nothrow__)) char *tmpnam(char * );
# 265 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fclose(FILE * ) __attribute__((__nonnull__(1)));
# 275 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fflush(FILE * );
# 285 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) FILE *fopen(const char * __restrict ,
                           const char * __restrict ) __attribute__((__nonnull__(1,2)));
# 329 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) FILE *freopen(const char * __restrict ,
                    const char * __restrict ,
                    FILE * __restrict ) __attribute__((__nonnull__(2,3)));
# 342 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) void setbuf(FILE * __restrict ,
                    char * __restrict ) __attribute__((__nonnull__(1)));






extern __attribute__((__nothrow__)) int setvbuf(FILE * __restrict ,
                   char * __restrict ,
                   int , size_t ) __attribute__((__nonnull__(1)));
# 370 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __printf_args
extern __attribute__((__nothrow__)) int fprintf(FILE * __restrict ,
                    const char * __restrict , ...) __attribute__((__nonnull__(1,2)));
# 393 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __printf_args
extern __attribute__((__nothrow__)) int _fprintf(FILE * __restrict ,
                     const char * __restrict , ...) __attribute__((__nonnull__(1,2)));





#pragma __printf_args
extern __attribute__((__nothrow__)) int printf(const char * __restrict , ...) __attribute__((__nonnull__(1)));






#pragma __printf_args
extern __attribute__((__nothrow__)) int _printf(const char * __restrict , ...) __attribute__((__nonnull__(1)));





#pragma __printf_args
extern __attribute__((__nothrow__)) int sprintf(char * __restrict , const char * __restrict , ...) __attribute__((__nonnull__(1,2)));








#pragma __printf_args
extern __attribute__((__nothrow__)) int _sprintf(char * __restrict , const char * __restrict , ...) __attribute__((__nonnull__(1,2)));






#pragma __printf_args
extern __attribute__((__nothrow__)) int __ARM_snprintf(char * __restrict , size_t ,
                     const char * __restrict , ...) __attribute__((__nonnull__(3)));


#pragma __printf_args
extern __attribute__((__nothrow__)) int snprintf(char * __restrict , size_t ,
                     const char * __restrict , ...) __attribute__((__nonnull__(3)));
# 460 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __printf_args
extern __attribute__((__nothrow__)) int _snprintf(char * __restrict , size_t ,
                      const char * __restrict , ...) __attribute__((__nonnull__(3)));





#pragma __scanf_args
extern __attribute__((__nothrow__)) int fscanf(FILE * __restrict ,
                    const char * __restrict , ...) __attribute__((__nonnull__(1,2)));
# 503 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __scanf_args
extern __attribute__((__nothrow__)) int _fscanf(FILE * __restrict ,
                     const char * __restrict , ...) __attribute__((__nonnull__(1,2)));





#pragma __scanf_args
extern __attribute__((__nothrow__)) int scanf(const char * __restrict , ...) __attribute__((__nonnull__(1)));








#pragma __scanf_args
extern __attribute__((__nothrow__)) int _scanf(const char * __restrict , ...) __attribute__((__nonnull__(1)));





#pragma __scanf_args
extern __attribute__((__nothrow__)) int sscanf(const char * __restrict ,
                    const char * __restrict , ...) __attribute__((__nonnull__(1,2)));
# 541 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __scanf_args
extern __attribute__((__nothrow__)) int _sscanf(const char * __restrict ,
                     const char * __restrict , ...) __attribute__((__nonnull__(1,2)));







extern __attribute__((__nothrow__)) int vfscanf(FILE * __restrict , const char * __restrict , __va_list) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) int vscanf(const char * __restrict , __va_list) __attribute__((__nonnull__(1)));
extern __attribute__((__nothrow__)) int vsscanf(const char * __restrict , const char * __restrict , __va_list) __attribute__((__nonnull__(1,2)));

extern __attribute__((__nothrow__)) int _vfscanf(FILE * __restrict , const char * __restrict , __va_list) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) int _vscanf(const char * __restrict , __va_list) __attribute__((__nonnull__(1)));
extern __attribute__((__nothrow__)) int _vsscanf(const char * __restrict , const char * __restrict , __va_list) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) int __ARM_vsscanf(const char * __restrict , const char * __restrict , __va_list) __attribute__((__nonnull__(1,2)));

extern __attribute__((__nothrow__)) int vprintf(const char * __restrict , __va_list ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) int _vprintf(const char * __restrict , __va_list ) __attribute__((__nonnull__(1)));





extern __attribute__((__nothrow__)) int vfprintf(FILE * __restrict ,
                    const char * __restrict , __va_list ) __attribute__((__nonnull__(1,2)));
# 584 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int vsprintf(char * __restrict ,
                     const char * __restrict , __va_list ) __attribute__((__nonnull__(1,2)));
# 594 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int __ARM_vsnprintf(char * __restrict , size_t ,
                     const char * __restrict , __va_list ) __attribute__((__nonnull__(3)));

extern __attribute__((__nothrow__)) int vsnprintf(char * __restrict , size_t ,
                     const char * __restrict , __va_list ) __attribute__((__nonnull__(3)));
# 609 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int _vsprintf(char * __restrict ,
                      const char * __restrict , __va_list ) __attribute__((__nonnull__(1,2)));





extern __attribute__((__nothrow__)) int _vfprintf(FILE * __restrict ,
                     const char * __restrict , __va_list ) __attribute__((__nonnull__(1,2)));





extern __attribute__((__nothrow__)) int _vsnprintf(char * __restrict , size_t ,
                      const char * __restrict , __va_list ) __attribute__((__nonnull__(3)));
# 635 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
#pragma __printf_args
extern __attribute__((__nothrow__)) int __ARM_asprintf(char ** , const char * __restrict , ...) __attribute__((__nonnull__(2)));
extern __attribute__((__nothrow__)) int __ARM_vasprintf(char ** , const char * __restrict , __va_list ) __attribute__((__nonnull__(2)));
# 649 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fgetc(FILE * ) __attribute__((__nonnull__(1)));
# 659 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) char *fgets(char * __restrict , int ,
                    FILE * __restrict ) __attribute__((__nonnull__(1,3)));
# 673 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fputc(int , FILE * ) __attribute__((__nonnull__(2)));
# 683 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fputs(const char * __restrict , FILE * __restrict ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) int getc(FILE * ) __attribute__((__nonnull__(1)));
# 704 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
    extern __attribute__((__nothrow__)) int (getchar)(void);
# 713 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) char *gets(char * ) __attribute__((__nonnull__(1)));
# 725 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int putc(int , FILE * ) __attribute__((__nonnull__(2)));
# 737 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
    extern __attribute__((__nothrow__)) int (putchar)(int );






extern __attribute__((__nothrow__)) int puts(const char * ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) int ungetc(int , FILE * ) __attribute__((__nonnull__(2)));
# 778 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) size_t fread(void * __restrict ,
                    size_t , size_t , FILE * __restrict ) __attribute__((__nonnull__(1,4)));
# 794 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) size_t __fread_bytes_avail(void * __restrict ,
                    size_t , FILE * __restrict ) __attribute__((__nonnull__(1,3)));
# 810 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) size_t fwrite(const void * __restrict ,
                    size_t , size_t , FILE * __restrict ) __attribute__((__nonnull__(1,4)));
# 822 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fgetpos(FILE * __restrict , fpos_t * __restrict ) __attribute__((__nonnull__(1,2)));
# 833 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fseek(FILE * , long int , int ) __attribute__((__nonnull__(1)));
# 850 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int fsetpos(FILE * __restrict , const fpos_t * __restrict ) __attribute__((__nonnull__(1,2)));
# 863 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) long int ftell(FILE * ) __attribute__((__nonnull__(1)));
# 877 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) void rewind(FILE * ) __attribute__((__nonnull__(1)));
# 886 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) void clearerr(FILE * ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) int feof(FILE * ) __attribute__((__nonnull__(1)));




extern __attribute__((__nothrow__)) int ferror(FILE * ) __attribute__((__nonnull__(1)));




extern __attribute__((__nothrow__)) void perror(const char * );
# 917 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdio.h" 3
extern __attribute__((__nothrow__)) int _fisatty(FILE * ) __attribute__((__nonnull__(1)));



extern __attribute__((__nothrow__)) void __use_no_semihosting_swi(void);
extern __attribute__((__nothrow__)) void __use_no_semihosting(void);
# 11 "../USB/hid_transfer.c" 2
# 1 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 1 3
# 58 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void *memcpy(void * __restrict ,
                    const void * __restrict , size_t ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) void *memmove(void * ,
                    const void * , size_t ) __attribute__((__nonnull__(1,2)));
# 77 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strcpy(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) char *strncpy(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(1,2)));
# 93 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strcat(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) char *strncat(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(1,2)));
# 117 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int memcmp(const void * , const void * , size_t ) __attribute__((__nonnull__(1,2)));







extern __attribute__((__nothrow__)) int strcmp(const char * , const char * ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) int strncmp(const char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 141 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int strcasecmp(const char * , const char * ) __attribute__((__nonnull__(1,2)));







extern __attribute__((__nothrow__)) int strncasecmp(const char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 158 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int strcoll(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 169 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strxfrm(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(2)));
# 193 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void *memchr(const void * , int , size_t ) __attribute__((__nonnull__(1)));
# 209 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strchr(const char * , int ) __attribute__((__nonnull__(1)));
# 218 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strcspn(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 232 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strpbrk(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 247 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strrchr(const char * , int ) __attribute__((__nonnull__(1)));
# 257 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strspn(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 270 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strstr(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 280 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strtok(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(2)));
extern __attribute__((__nothrow__)) char *_strtok_r(char * , const char * , char ** ) __attribute__((__nonnull__(2,3)));
# 321 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void *memset(void * , int , size_t ) __attribute__((__nonnull__(1)));





extern __attribute__((__nothrow__)) char *strerror(int );







extern __attribute__((__nothrow__)) size_t strlen(const char * ) __attribute__((__nonnull__(1)));





extern __attribute__((__nothrow__)) size_t strnlen(const char * , size_t ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) size_t strlcpy(char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 369 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strlcat(char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 395 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void _membitcpybl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpybb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpyhl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpyhb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpywl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpywb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovebl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovebb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovehl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovehb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovewl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovewb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
# 12 "../USB/hid_transfer.c" 2
# 1 "..\\device.h" 1
# 13 "../USB/hid_transfer.c" 2
# 1 "../Platform\\Platform_HAL.h" 1
# 11 "../Platform\\Platform_HAL.h"
# 1 "../Platform\\Platform_HAL_NUC1262.h" 1
# 11 "../Platform\\Platform_HAL_NUC1262.h"
# 1 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdint.h" 1 3
# 56 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdint.h" 3
typedef signed char int8_t;
typedef signed short int int16_t;
typedef signed int int32_t;
typedef signed long long int int64_t;


typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;





typedef signed char int_least8_t;
typedef signed short int int_least16_t;
typedef signed int int_least32_t;
typedef signed long long int int_least64_t;


typedef unsigned char uint_least8_t;
typedef unsigned short int uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long int uint_least64_t;




typedef signed int int_fast8_t;
typedef signed int int_fast16_t;
typedef signed int int_fast32_t;
typedef signed long long int int_fast64_t;


typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long int uint_fast64_t;






typedef signed int intptr_t;
typedef unsigned int uintptr_t;



typedef signed long long intmax_t;
typedef unsigned long long uintmax_t;
# 12 "../Platform\\Platform_HAL_NUC1262.h" 2
# 1 "..\\device.h" 1
# 13 "../Platform\\Platform_HAL_NUC1262.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\NuMicro.h" 1
# 14 "../../../../Library/Device/Nuvoton/M3351/Include\\NuMicro.h"
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 1
# 68 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\irqn.h" 1
# 15 "../../../../Library/Device/Nuvoton/M3351/Include\\irqn.h"
typedef enum IRQn
{

    NonMaskableInt_IRQn = -14,
    HardFault_IRQn = -13,
    MemoryManagement_IRQn = -12,
    BusFault_IRQn = -11,
    UsageFault_IRQn = -10,
    SecureFault_IRQn = -9,



    SVCall_IRQn = -5,
    DebugMonitor_IRQn = -4,

    PendSV_IRQn = -2,
    SysTick_IRQn = -1,


    BODOUT_IRQn = 0,
    IRC_IRQn = 1,
    PWRWU_IRQn = 2,
    SRAMPERR_IRQn = 3,
    CKFAIL_IRQn = 4,
    ISP_IRQn = 5,
    RTC_IRQn = 6,

    WDT0_IRQn = 8,
    WWDT0_IRQn = 9,

    EINT0_IRQn = 10,
    EINT1_IRQn = 11,
    EINT2_IRQn = 12,
    EINT3_IRQn = 13,
    EINT4_IRQn = 14,
    EINT5_IRQn = 15,
    GPA_IRQn = 16,
    GPB_IRQn = 17,
    GPC_IRQn = 18,
    GPD_IRQn = 19,

    GPE_IRQn = 20,
    GPF_IRQn = 21,
    QSPI0_IRQn = 22,
    SPI0_IRQn = 23,
    BRAKE0_IRQn = 24,
    PWM0P0_IRQn = 25,
    PWM0P1_IRQn = 26,
    PWM0P2_IRQn = 27,
    BRAKE1_IRQn = 28,
    PWM1P0_IRQn = 29,

    PWM1P1_IRQn = 30,
    PWM1P2_IRQn = 31,
    TIMER0_IRQn = 32,
    TIMER1_IRQn = 33,
    TIMER2_IRQn = 34,
    TIMER3_IRQn = 35,
    UART0_IRQn = 36,
    UART1_IRQn = 37,
    I2C0_IRQn = 38,
    I2C1_IRQn = 39,

    PDMA0_IRQn = 40,
    DAC0_IRQn = 41,
    EADC00_IRQn = 42,
    EADC01_IRQn = 43,
    ACMP01_IRQn = 44,

    EADC02_IRQn = 46,
    EADC03_IRQn = 47,
    UART2_IRQn = 48,
    UART3_IRQn = 49,


    SPI1_IRQn = 51,

    USBD_IRQn = 53,
    USBH_IRQn = 54,

    ETI_IRQn = 56,
    CRC_IRQn = 57,

    NS_ISP_IRQn = 59,

    SCU_IRQn = 60,






    WDT1_IRQn = 67,




    CRYPTO_IRQn = 71,
    GPG_IRQn = 72,
    EINT6_IRQn = 73,
    UART4_IRQn = 74,
    UART5_IRQn = 75,
    USCI0_IRQn = 76,
    USCI1_IRQn = 77,
    BPWM0_IRQn = 78,
    BPWM1_IRQn = 79,



    I2C2_IRQn = 82,

    EQEI0_IRQn = 84,
    EQEI1_IRQn = 85,
    ECAP0_IRQn = 86,

    GPH_IRQn = 88,
    EINT7_IRQn = 89,


    WWDT1_IRQn = 91,




    NS_SRAMPE_IRQn = 96,
    CACHE_IRQn = 97,

    UART8_IRQn = 99,

    UART9_IRQn = 100,
    TRNG_IRQn = 101,
    UART6_IRQn = 102,
    UART7_IRQn = 103,
    EADC10_IRQn = 104,
    EADC11_IRQn = 105,
    EADC12_IRQn = 106,
    EADC13_IRQn = 107,
    I3C0_IRQn = 108,



    DFMC_IRQn = 111,
    CANFD00_IRQn = 112,
    CANFD01_IRQn = 113,
    CANFD10_IRQn = 114,
    CANFD11_IRQn = 115,



    NS_DFMC_IRQn = 119,
# 174 "../../../../Library/Device/Nuvoton/M3351/Include\\irqn.h"
    LLSI0_IRQn = 128,
    LLSI1_IRQn = 129,

    LLSI2_IRQn = 130,
    LLSI3_IRQn = 131,
    LLSI4_IRQn = 132,
    LLSI5_IRQn = 133,
    LLSI6_IRQn = 134,
    LLSI7_IRQn = 135,
    LLSI8_IRQn = 136,
    LLSI9_IRQn = 137,
    ELLSI0_IRQn = 138,
    ELLSI1_IRQn = 139,


    IRQ_OFFSET = 16,
    TOTAL_IRQn_CNT = ELLSI1_IRQn + IRQ_OFFSET,

} IRQn_Type;
# 69 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 80 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wc11-extensions"
#pragma clang diagnostic ignored "-Wreserved-id-macro"
# 109 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 1
# 27 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
# 63 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_version.h" 1 3
# 27 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_version.h" 3
# 64 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 2 3
# 225 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_compiler.h" 1 3
# 32 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_compiler.h" 3
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 1 3
# 29 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3


# 1 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 1 3
# 45 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__)) __wfi(void) {
  __builtin_arm_wfi();
}



static __inline__ void __attribute__((__always_inline__, __nodebug__)) __wfe(void) {
  __builtin_arm_wfe();
}



static __inline__ void __attribute__((__always_inline__, __nodebug__)) __sev(void) {
  __builtin_arm_sev();
}



static __inline__ void __attribute__((__always_inline__, __nodebug__)) __sevl(void) {
  __builtin_arm_sevl();
}



static __inline__ void __attribute__((__always_inline__, __nodebug__)) __yield(void) {
  __builtin_arm_yield();
}
# 87 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 3
static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__swp(uint32_t __x, volatile uint32_t *__p) {
  uint32_t v;
  do
    v = __builtin_arm_ldrex(__p);
  while (__builtin_arm_strex(__x, __p));
  return v;
}
# 121 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__)) __nop(void) {
  __builtin_arm_nop();
}





static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__ror(uint32_t __x, uint32_t __y) {
  __y %= 32;
  if (__y == 0)
    return __x;
  return (__x >> __y) | (__x << (32 - __y));
}

static __inline__ uint64_t __attribute__((__always_inline__, __nodebug__))
__rorll(uint64_t __x, uint32_t __y) {
  __y %= 64;
  if (__y == 0)
    return __x;
  return (__x >> __y) | (__x << (64 - __y));
}

static __inline__ unsigned long __attribute__((__always_inline__, __nodebug__))
__rorl(unsigned long __x, uint32_t __y) {

  return __ror(__x, __y);



}



static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__clz(uint32_t __t) {
  return __builtin_arm_clz(__t);
}

static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__clzl(unsigned long __t) {

  return __builtin_arm_clz(__t);



}

static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__clzll(uint64_t __t) {
  return __builtin_arm_clz64(__t);
}


static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__cls(uint32_t __t) {
  return __builtin_arm_cls(__t);
}

static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__clsl(unsigned long __t) {

  return __builtin_arm_cls(__t);



}

static __inline__ unsigned int __attribute__((__always_inline__, __nodebug__))
__clsll(uint64_t __t) {
  return __builtin_arm_cls64(__t);
}


static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__rev(uint32_t __t) {
  return __builtin_bswap32(__t);
}

static __inline__ unsigned long __attribute__((__always_inline__, __nodebug__))
__revl(unsigned long __t) {

  return __builtin_bswap32(__t);



}

static __inline__ uint64_t __attribute__((__always_inline__, __nodebug__))
__revll(uint64_t __t) {
  return __builtin_bswap64(__t);
}


static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__rev16(uint32_t __t) {
  return __ror(__rev(__t), 16);
}

static __inline__ uint64_t __attribute__((__always_inline__, __nodebug__))
__rev16ll(uint64_t __t) {
  return (((uint64_t)__rev16(__t >> 32)) << 32) | (uint64_t)__rev16((uint32_t)__t);
}

static __inline__ unsigned long __attribute__((__always_inline__, __nodebug__))
__rev16l(unsigned long __t) {

    return __rev16(__t);



}


static __inline__ int16_t __attribute__((__always_inline__, __nodebug__))
__revsh(int16_t __t) {
  return (int16_t)__builtin_bswap16((uint16_t)__t);
}


static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__rbit(uint32_t __t) {
  return __builtin_arm_rbit(__t);
}

static __inline__ uint64_t __attribute__((__always_inline__, __nodebug__))
__rbitll(uint64_t __t) {

  return (((uint64_t)__builtin_arm_rbit(__t)) << 32) |
         __builtin_arm_rbit(__t >> 32);



}

static __inline__ unsigned long __attribute__((__always_inline__, __nodebug__))
__rbitl(unsigned long __t) {

  return __rbit(__t);



}



static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smulbb(int32_t __a, int32_t __b) {
  return __builtin_arm_smulbb(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smulbt(int32_t __a, int32_t __b) {
  return __builtin_arm_smulbt(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smultb(int32_t __a, int32_t __b) {
  return __builtin_arm_smultb(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smultt(int32_t __a, int32_t __b) {
  return __builtin_arm_smultt(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smulwb(int32_t __a, int32_t __b) {
  return __builtin_arm_smulwb(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__,__nodebug__))
__smulwt(int32_t __a, int32_t __b) {
  return __builtin_arm_smulwt(__a, __b);
}
# 308 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 3
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__qadd(int32_t __t, int32_t __v) {
  return __builtin_arm_qadd(__t, __v);
}

static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__qsub(int32_t __t, int32_t __v) {
  return __builtin_arm_qsub(__t, __v);
}

static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__qdbl(int32_t __t) {
  return __builtin_arm_qadd(__t, __t);
}




static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlabb(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlabb(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlabt(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlabt(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlatb(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlatb(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlatt(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlatt(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlawb(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlawb(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlawt(int32_t __a, int32_t __b, int32_t __c) {
  return __builtin_arm_smlawt(__a, __b, __c);
}
# 361 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\arm_acle.h" 3
typedef int32_t int8x4_t;
typedef int32_t int16x2_t;
typedef uint32_t uint8x4_t;
typedef uint32_t uint16x2_t;

static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__sxtab16(int16x2_t __a, int8x4_t __b) {
  return __builtin_arm_sxtab16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__sxtb16(int8x4_t __a) {
  return __builtin_arm_sxtb16(__a);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__uxtab16(int16x2_t __a, int8x4_t __b) {
  return __builtin_arm_uxtab16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__uxtb16(int8x4_t __a) {
  return __builtin_arm_uxtb16(__a);
}




static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__sel(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_sel(__a, __b);
}




static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__qadd8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_qadd8(__a, __b);
}
static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__qsub8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_qsub8(__a, __b);
}
static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__sadd8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_sadd8(__a, __b);
}
static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__shadd8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_shadd8(__a, __b);
}
static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__shsub8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_shsub8(__a, __b);
}
static __inline__ int8x4_t __attribute__((__always_inline__, __nodebug__))
__ssub8(int8x4_t __a, int8x4_t __b) {
  return __builtin_arm_ssub8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__uadd8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_uadd8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__uhadd8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_uhadd8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__uhsub8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_uhsub8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__uqadd8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_uqadd8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__uqsub8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_uqsub8(__a, __b);
}
static __inline__ uint8x4_t __attribute__((__always_inline__, __nodebug__))
__usub8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_usub8(__a, __b);
}




static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__usad8(uint8x4_t __a, uint8x4_t __b) {
  return __builtin_arm_usad8(__a, __b);
}
static __inline__ uint32_t __attribute__((__always_inline__, __nodebug__))
__usada8(uint8x4_t __a, uint8x4_t __b, uint32_t __c) {
  return __builtin_arm_usada8(__a, __b, __c);
}




static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__qadd16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_qadd16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__qasx(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_qasx(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__qsax(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_qsax(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__qsub16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_qsub16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__sadd16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_sadd16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__sasx(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_sasx(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__shadd16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_shadd16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__shasx(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_shasx(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__shsax(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_shsax(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__shsub16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_shsub16(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__ssax(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_ssax(__a, __b);
}
static __inline__ int16x2_t __attribute__((__always_inline__, __nodebug__))
__ssub16(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_ssub16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uadd16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uadd16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uasx(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uasx(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uhadd16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uhadd16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uhasx(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uhasx(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uhsax(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uhsax(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uhsub16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uhsub16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uqadd16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uqadd16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uqasx(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uqasx(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uqsax(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uqsax(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__uqsub16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_uqsub16(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__usax(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_usax(__a, __b);
}
static __inline__ uint16x2_t __attribute__((__always_inline__, __nodebug__))
__usub16(uint16x2_t __a, uint16x2_t __b) {
  return __builtin_arm_usub16(__a, __b);
}




static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlad(int16x2_t __a, int16x2_t __b, int32_t __c) {
  return __builtin_arm_smlad(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smladx(int16x2_t __a, int16x2_t __b, int32_t __c) {
  return __builtin_arm_smladx(__a, __b, __c);
}
static __inline__ int64_t __attribute__((__always_inline__, __nodebug__))
__smlald(int16x2_t __a, int16x2_t __b, int64_t __c) {
  return __builtin_arm_smlald(__a, __b, __c);
}
static __inline__ int64_t __attribute__((__always_inline__, __nodebug__))
__smlaldx(int16x2_t __a, int16x2_t __b, int64_t __c) {
  return __builtin_arm_smlaldx(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlsd(int16x2_t __a, int16x2_t __b, int32_t __c) {
  return __builtin_arm_smlsd(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smlsdx(int16x2_t __a, int16x2_t __b, int32_t __c) {
  return __builtin_arm_smlsdx(__a, __b, __c);
}
static __inline__ int64_t __attribute__((__always_inline__, __nodebug__))
__smlsld(int16x2_t __a, int16x2_t __b, int64_t __c) {
  return __builtin_arm_smlsld(__a, __b, __c);
}
static __inline__ int64_t __attribute__((__always_inline__, __nodebug__))
__smlsldx(int16x2_t __a, int16x2_t __b, int64_t __c) {
  return __builtin_arm_smlsldx(__a, __b, __c);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smuad(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_smuad(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smuadx(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_smuadx(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smusd(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_smusd(__a, __b);
}
static __inline__ int32_t __attribute__((__always_inline__, __nodebug__))
__smusdx(int16x2_t __a, int16x2_t __b) {
  return __builtin_arm_smusdx(__a, __b);
}
# 32 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 2 3
# 71 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"
  struct __attribute__((packed, aligned(1))) T_UINT16_WRITE { uint16_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"
  struct __attribute__((packed, aligned(1))) T_UINT16_READ { uint16_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"
  struct __attribute__((packed, aligned(1))) T_UINT32_WRITE { uint32_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"
  struct __attribute__((packed, aligned(1))) T_UINT32_READ { uint32_t v; };
#pragma clang diagnostic pop
# 408 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint32_t __RRX(uint32_t value)
{
  uint32_t result;

  __asm volatile ("rrx %0, %1" : "=r" (result) : "r" (value));
  return (result);
}
# 423 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint8_t __LDRBT(volatile uint8_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrbt %0, %1" : "=r" (result) : "Q" (*ptr) );
  return ((uint8_t)result);
}
# 438 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint16_t __LDRHT(volatile uint16_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrht %0, %1" : "=r" (result) : "Q" (*ptr) );
  return ((uint16_t)result);
}
# 453 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint32_t __LDRT(volatile uint32_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrt %0, %1" : "=r" (result) : "Q" (*ptr) );
  return (result);
}
# 470 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint8_t __LDAB(volatile uint8_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldab %0, %1" : "=r" (result) : "Q" (*ptr) : "memory" );
  return ((uint8_t)result);
}
# 485 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint16_t __LDAH(volatile uint16_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldah %0, %1" : "=r" (result) : "Q" (*ptr) : "memory" );
  return ((uint16_t)result);
}
# 500 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint32_t __LDA(volatile uint32_t *ptr)
{
  uint32_t result;

  __asm volatile ("lda %0, %1" : "=r" (result) : "Q" (*ptr) : "memory" );
  return (result);
}
# 515 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __STLB(uint8_t value, volatile uint8_t *ptr)
{
  __asm volatile ("stlb %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) : "memory" );
}
# 527 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __STLH(uint16_t value, volatile uint16_t *ptr)
{
  __asm volatile ("stlh %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) : "memory" );
}
# 539 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __STL(uint32_t value, volatile uint32_t *ptr)
{
  __asm volatile ("stl %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) : "memory" );
}
# 621 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __enable_irq(void)
{
  __asm volatile ("cpsie i" : : : "memory");
}
# 634 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __disable_irq(void)
{
  __asm volatile ("cpsid i" : : : "memory");
}
# 646 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline void __enable_fault_irq(void)
{
  __asm volatile ("cpsie f" : : : "memory");
}







__attribute__((always_inline)) static inline void __disable_fault_irq(void)
{
  __asm volatile ("cpsid f" : : : "memory");
}
# 670 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
__attribute__((always_inline)) static inline uint32_t __get_FPSCR(void)
{

  return (__builtin_arm_get_fpscr());



}







__attribute__((always_inline)) static inline void __set_FPSCR(uint32_t fpscr)
{

  __builtin_arm_set_fpscr(fpscr);



}
# 702 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 3
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 1 3
# 27 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
# 86 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __STRBT(uint8_t value, volatile uint8_t *ptr)
{
  __asm volatile ("strbt %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) );
}
# 98 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __STRHT(uint16_t value, volatile uint16_t *ptr)
{
  __asm volatile ("strht %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) );
}
# 110 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __STRT(uint32_t value, volatile uint32_t *ptr)
{
  __asm volatile ("strt %1, %0" : "=Q" (*ptr) : "r" (value) );
}
# 128 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_CONTROL(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, control" : "=r" (result) );
  return (result);
}
# 158 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_CONTROL(uint32_t control)
{
  __asm volatile ("MSR control, %0" : : "r" (control) : "memory");
  __builtin_arm_isb(0xF);
}
# 184 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_IPSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, ipsr" : "=r" (result) );
  return (result);
}







__attribute__((always_inline)) static inline uint32_t __get_APSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, apsr" : "=r" (result) );
  return (result);
}







__attribute__((always_inline)) static inline uint32_t __get_xPSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, xpsr" : "=r" (result) );
  return (result);
}







__attribute__((always_inline)) static inline uint32_t __get_PSP(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, psp" : "=r" (result) );
  return (result);
}
# 256 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_PSP(uint32_t topOfProcStack)
{
  __asm volatile ("MSR psp, %0" : : "r" (topOfProcStack) : );
}
# 280 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_MSP(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, msp" : "=r" (result) );
  return (result);
}
# 310 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_MSP(uint32_t topOfMainStack)
{
  __asm volatile ("MSR msp, %0" : : "r" (topOfMainStack) : );
}
# 361 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_PRIMASK(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, primask" : "=r" (result) );
  return (result);
}
# 391 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_PRIMASK(uint32_t priMask)
{
  __asm volatile ("MSR primask, %0" : : "r" (priMask) : "memory");
}
# 416 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_BASEPRI(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, basepri" : "=r" (result) );
  return (result);
}
# 446 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_BASEPRI(uint32_t basePri)
{
  __asm volatile ("MSR basepri, %0" : : "r" (basePri) : "memory");
}
# 471 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_BASEPRI_MAX(uint32_t basePri)
{
  __asm volatile ("MSR basepri_max, %0" : : "r" (basePri) : "memory");
}







__attribute__((always_inline)) static inline uint32_t __get_FAULTMASK(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, faultmask" : "=r" (result) );
  return (result);
}
# 512 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_FAULTMASK(uint32_t faultMask)
{
  __asm volatile ("MSR faultmask, %0" : : "r" (faultMask) : "memory");
}
# 543 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_PSPLIM(void)
{






  uint32_t result;
  __asm volatile ("MRS %0, psplim" : "=r" (result) );
  return (result);

}
# 590 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_PSPLIM(uint32_t ProcStackPtrLimit)
{






  __asm volatile ("MSR psplim, %0" : : "r" (ProcStackPtrLimit));

}
# 633 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline uint32_t __get_MSPLIM(void)
{






  uint32_t result;
  __asm volatile ("MRS %0, msplim" : "=r" (result) );
  return (result);

}
# 680 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline void __set_MSPLIM(uint32_t MainStackPtrLimit)
{






  __asm volatile ("MSR msplim, %0" : : "r" (MainStackPtrLimit));

}
# 808 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\./m-profile/cmsis_armclang_m.h" 3
__attribute__((always_inline)) static inline int32_t __SMMLA (int32_t op1, int32_t op2, int32_t op3)
{
  int32_t result;

  __asm volatile ("smmla %0, %1, %2, %3" : "=r" (result): "r" (op1), "r" (op2), "r" (op3) );
  return (result);
}
# 703 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_armclang.h" 2 3
# 33 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\cmsis_compiler.h" 2 3
# 226 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 2 3
# 338 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef union
{
  struct
  {
    uint32_t _reserved0:16;
    uint32_t GE:4;
    uint32_t _reserved1:7;
    uint32_t Q:1;
    uint32_t V:1;
    uint32_t C:1;
    uint32_t Z:1;
    uint32_t N:1;
  } b;
  uint32_t w;
} APSR_Type;
# 377 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef union
{
  struct
  {
    uint32_t ISR:9;
    uint32_t _reserved0:23;
  } b;
  uint32_t w;
} IPSR_Type;
# 395 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef union
{
  struct
  {
    uint32_t ISR:9;
    uint32_t _reserved0:7;
    uint32_t GE:4;
    uint32_t _reserved1:4;
    uint32_t T:1;
    uint32_t IT:2;
    uint32_t Q:1;
    uint32_t V:1;
    uint32_t C:1;
    uint32_t Z:1;
    uint32_t N:1;
  } b;
  uint32_t w;
} xPSR_Type;
# 446 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef union
{
  struct
  {
    uint32_t nPRIV:1;
    uint32_t SPSEL:1;
    uint32_t FPCA:1;
    uint32_t SFPA:1;
    uint32_t _reserved1:28;
  } b;
  uint32_t w;
} CONTROL_Type;
# 485 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t ISER[16U];
        uint32_t RESERVED0[16U];
  volatile uint32_t ICER[16U];
        uint32_t RESERVED1[16U];
  volatile uint32_t ISPR[16U];
        uint32_t RESERVED2[16U];
  volatile uint32_t ICPR[16U];
        uint32_t RESERVED3[16U];
  volatile uint32_t IABR[16U];
        uint32_t RESERVED4[16U];
  volatile uint32_t ITNS[16U];
        uint32_t RESERVED5[16U];
  volatile uint8_t IPR[496U];
        uint32_t RESERVED6[580U];
  volatile uint32_t STIR;
} NVIC_Type;
# 521 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile const uint32_t CPUID;
  volatile uint32_t ICSR;
  volatile uint32_t VTOR;
  volatile uint32_t AIRCR;
  volatile uint32_t SCR;
  volatile uint32_t CCR;
  volatile uint8_t SHPR[12U];
  volatile uint32_t SHCSR;
  volatile uint32_t CFSR;
  volatile uint32_t HFSR;
  volatile uint32_t DFSR;
  volatile uint32_t MMFAR;
  volatile uint32_t BFAR;
  volatile uint32_t AFSR;
  volatile const uint32_t ID_PFR[2U];
  volatile const uint32_t ID_DFR;
  volatile const uint32_t ID_AFR;
  volatile const uint32_t ID_MMFR[4U];
  volatile const uint32_t ID_ISAR[6U];
  volatile const uint32_t CLIDR;
  volatile const uint32_t CTR;
  volatile const uint32_t CCSIDR;
  volatile uint32_t CSSELR;
  volatile uint32_t CPACR;
  volatile uint32_t NSACR;
        uint32_t RESERVED7[21U];
  volatile uint32_t SFSR;
  volatile uint32_t SFAR;
        uint32_t RESERVED3[69U];
  volatile uint32_t STIR;
        uint32_t RESERVED4[15U];
  volatile const uint32_t MVFR0;
  volatile const uint32_t MVFR1;
  volatile const uint32_t MVFR2;
        uint32_t RESERVED5[1U];
  volatile uint32_t ICIALLU;
        uint32_t RESERVED6[1U];
  volatile uint32_t ICIMVAU;
  volatile uint32_t DCIMVAC;
  volatile uint32_t DCISW;
  volatile uint32_t DCCMVAU;
  volatile uint32_t DCCMVAC;
  volatile uint32_t DCCSW;
  volatile uint32_t DCCIMVAC;
  volatile uint32_t DCCISW;
  volatile uint32_t BPIALL;
} SCB_Type;
# 957 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
        uint32_t RESERVED0[1U];
  volatile const uint32_t ICTR;
  volatile uint32_t ACTLR;
  volatile uint32_t CPPWR;
} SCnSCB_Type;
# 995 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t CTRL;
  volatile uint32_t LOAD;
  volatile uint32_t VAL;
  volatile const uint32_t CALIB;
} SysTick_Type;
# 1047 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile union
  {
    volatile uint8_t u8;
    volatile uint16_t u16;
    volatile uint32_t u32;
  } PORT [32U];
        uint32_t RESERVED0[864U];
  volatile uint32_t TER;
        uint32_t RESERVED1[15U];
  volatile uint32_t TPR;
        uint32_t RESERVED2[15U];
  volatile uint32_t TCR;
        uint32_t RESERVED3[27U];
  volatile const uint32_t ITREAD;
        uint32_t RESERVED4[1U];
  volatile uint32_t ITWRITE;
        uint32_t RESERVED5[1U];
  volatile uint32_t ITCTRL;
        uint32_t RESERVED6[46U];
  volatile const uint32_t DEVARCH;
        uint32_t RESERVED7[3U];
  volatile const uint32_t DEVTYPE;
} ITM_Type;
# 1146 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t CTRL;
  volatile uint32_t CYCCNT;
  volatile uint32_t CPICNT;
  volatile uint32_t EXCCNT;
  volatile uint32_t SLEEPCNT;
  volatile uint32_t LSUCNT;
  volatile uint32_t FOLDCNT;
  volatile const uint32_t PCSR;
  volatile uint32_t COMP0;
        uint32_t RESERVED1[1U];
  volatile uint32_t FUNCTION0;
        uint32_t RESERVED2[1U];
  volatile uint32_t COMP1;
        uint32_t RESERVED3[1U];
  volatile uint32_t FUNCTION1;
        uint32_t RESERVED4[1U];
  volatile uint32_t COMP2;
        uint32_t RESERVED5[1U];
  volatile uint32_t FUNCTION2;
        uint32_t RESERVED6[1U];
  volatile uint32_t COMP3;
        uint32_t RESERVED7[1U];
  volatile uint32_t FUNCTION3;
        uint32_t RESERVED14[984U];
  volatile const uint32_t DEVARCH;
        uint32_t RESERVED15[3U];
  volatile const uint32_t DEVTYPE;
} DWT_Type;
# 1284 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile const uint32_t SSPSR;
  volatile uint32_t CSPSR;
        uint32_t RESERVED0[2U];
  volatile uint32_t ACPR;
        uint32_t RESERVED1[55U];
  volatile uint32_t SPPR;
        uint32_t RESERVED2[131U];
  volatile const uint32_t FFSR;
  volatile uint32_t FFCR;
  volatile uint32_t PSCR;
        uint32_t RESERVED3[759U];
  volatile const uint32_t TRIGGER;
  volatile const uint32_t ITFTTD0;
  volatile uint32_t ITATBCTR2;
        uint32_t RESERVED4[1U];
  volatile const uint32_t ITATBCTR0;
  volatile const uint32_t ITFTTD1;
  volatile uint32_t ITCTRL;
        uint32_t RESERVED5[39U];
  volatile uint32_t CLAIMSET;
  volatile uint32_t CLAIMCLR;
        uint32_t RESERVED7[8U];
  volatile const uint32_t DEVID;
  volatile const uint32_t DEVTYPE;
} TPIU_Type;
# 1462 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile const uint32_t TYPE;
  volatile uint32_t CTRL;
  volatile uint32_t RNR;
  volatile uint32_t RBAR;
  volatile uint32_t RLAR;
  volatile uint32_t RBAR_A1;
  volatile uint32_t RLAR_A1;
  volatile uint32_t RBAR_A2;
  volatile uint32_t RLAR_A2;
  volatile uint32_t RBAR_A3;
  volatile uint32_t RLAR_A3;
        uint32_t RESERVED0[1];
  union {
  volatile uint32_t MAIR[2];
  struct {
  volatile uint32_t MAIR0;
  volatile uint32_t MAIR1;
  };
  };
} MPU_Type;
# 1664 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
        uint32_t RESERVED0[1U];
  volatile uint32_t FPCCR;
  volatile uint32_t FPCAR;
  volatile uint32_t FPDSCR;
  volatile const uint32_t MVFR0;
  volatile const uint32_t MVFR1;
  volatile const uint32_t MVFR2;
} FPU_Type;
# 1799 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t DHCSR;
  volatile uint32_t DCRSR;
  volatile uint32_t DCRDR;
  volatile uint32_t DEMCR;
        uint32_t RESERVED0[1U];
  volatile uint32_t DAUTHCTRL;
  volatile uint32_t DSCSR;
} DCB_Type;
# 1955 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t DLAR;
  volatile const uint32_t DLSR;
  volatile const uint32_t DAUTHSTATUS;
  volatile const uint32_t DDEVARCH;
  volatile const uint32_t DDEVTYPE;
} DIB_Type;
# 2123 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
typedef struct
{
  volatile uint32_t DHCSR;
  volatile uint32_t DCRSR;
  volatile uint32_t DCRDR;
  volatile uint32_t DEMCR;
        uint32_t RESERVED0[1U];
  volatile uint32_t DAUTHCTRL;
  volatile uint32_t DSCSR;
} CoreDebug_Type;
# 2340 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_SetPriorityGrouping(uint32_t PriorityGroup)
{
  uint32_t reg_value;
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);

  reg_value = ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR;
  reg_value &= ~((uint32_t)((0xFFFFUL << 16U) | (7UL << 8U)));
  reg_value = (reg_value |
                ((uint32_t)0x5FAUL << 16U) |
                (PriorityGroupTmp << 8U) );
  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR = reg_value;
}







static inline uint32_t __NVIC_GetPriorityGrouping(void)
{
  return ((uint32_t)((((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR & (7UL << 8U)) >> 8U));
}
# 2371 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_EnableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    __asm volatile("":::"memory");
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
    __asm volatile("":::"memory");
  }
}
# 2390 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t __NVIC_GetEnableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISER[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 2409 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_DisableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ICER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
    __builtin_arm_dsb(0xF);
    __builtin_arm_isb(0xF);
  }
}
# 2428 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t __NVIC_GetPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISPR[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 2447 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_SetPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISPR[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
  }
}
# 2462 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_ClearPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ICPR[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
  }
}
# 2479 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t __NVIC_GetActive(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IABR[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 2568 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_SetPriority(IRQn_Type IRQn, uint32_t priority)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IPR[((uint32_t)IRQn)] = (uint8_t)((priority << (8U - 3U)) & (uint32_t)0xFFUL);
  }
  else
  {
    ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHPR[(((uint32_t)IRQn) & 0xFUL)-4UL] = (uint8_t)((priority << (8U - 3U)) & (uint32_t)0xFFUL);
  }
}
# 2590 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t __NVIC_GetPriority(IRQn_Type IRQn)
{

  if ((int32_t)(IRQn) >= 0)
  {
    return(((uint32_t)((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IPR[((uint32_t)IRQn)] >> (8U - 3U)));
  }
  else
  {
    return(((uint32_t)((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHPR[(((uint32_t)IRQn) & 0xFUL)-4UL] >> (8U - 3U)));
  }
}
# 2615 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t NVIC_EncodePriority (uint32_t PriorityGroup, uint32_t PreemptPriority, uint32_t SubPriority)
{
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);
  uint32_t PreemptPriorityBits;
  uint32_t SubPriorityBits;

  PreemptPriorityBits = ((7UL - PriorityGroupTmp) > (uint32_t)(3U)) ? (uint32_t)(3U) : (uint32_t)(7UL - PriorityGroupTmp);
  SubPriorityBits = ((PriorityGroupTmp + (uint32_t)(3U)) < (uint32_t)7UL) ? (uint32_t)0UL : (uint32_t)((PriorityGroupTmp - 7UL) + (uint32_t)(3U));

  return (
           ((PreemptPriority & (uint32_t)((1UL << (PreemptPriorityBits)) - 1UL)) << SubPriorityBits) |
           ((SubPriority & (uint32_t)((1UL << (SubPriorityBits )) - 1UL)))
         );
}
# 2642 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void NVIC_DecodePriority (uint32_t Priority, uint32_t PriorityGroup, uint32_t* const pPreemptPriority, uint32_t* const pSubPriority)
{
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);
  uint32_t PreemptPriorityBits;
  uint32_t SubPriorityBits;

  PreemptPriorityBits = ((7UL - PriorityGroupTmp) > (uint32_t)(3U)) ? (uint32_t)(3U) : (uint32_t)(7UL - PriorityGroupTmp);
  SubPriorityBits = ((PriorityGroupTmp + (uint32_t)(3U)) < (uint32_t)7UL) ? (uint32_t)0UL : (uint32_t)((PriorityGroupTmp - 7UL) + (uint32_t)(3U));

  *pPreemptPriority = (Priority >> SubPriorityBits) & (uint32_t)((1UL << (PreemptPriorityBits)) - 1UL);
  *pSubPriority = (Priority ) & (uint32_t)((1UL << (SubPriorityBits )) - 1UL);
}
# 2665 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void __NVIC_SetVector(IRQn_Type IRQn, uint32_t vector)
{
  uint32_t *vectors = (uint32_t *) ((uintptr_t) ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->VTOR);
  vectors[(int32_t)IRQn + 16] = vector;
  __builtin_arm_dsb(0xF);
}
# 2681 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t __NVIC_GetVector(IRQn_Type IRQn)
{
  uint32_t *vectors = (uint32_t *) ((uintptr_t) ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->VTOR);
  return vectors[(int32_t)IRQn + 16];
}






__attribute__((__noreturn__)) static inline void __NVIC_SystemReset(void)
{
  __builtin_arm_dsb(0xF);

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR = (uint32_t)((0x5FAUL << 16U) |
                           (((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR & (7UL << 8U)) |
                            (1UL << 2U) );
  __builtin_arm_dsb(0xF);

  for(;;)
  {
    __nop();
  }
}
# 2915 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
# 1 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 1 3
# 30 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
# 182 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
typedef struct {
  uint32_t RBAR;
  uint32_t RLAR;
} ARM_MPU_Region_t;





static inline uint32_t ARM_MPU_TYPE(void)
{
  return ((((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->TYPE) >> 8);
}




static inline void ARM_MPU_Enable(uint32_t MPU_Control)
{
  __builtin_arm_dmb(0xF);
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->CTRL = MPU_Control | (1UL );

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHCSR |= (1UL << 16U);

  __builtin_arm_dsb(0xF);
  __builtin_arm_isb(0xF);
}



static inline void ARM_MPU_Disable(void)
{
  __builtin_arm_dmb(0xF);

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHCSR &= ~(1UL << 16U);

  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->CTRL &= ~(1UL );
  __builtin_arm_dsb(0xF);
  __builtin_arm_isb(0xF);
}
# 257 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
static inline void ARM_MPU_SetMemAttrEx(MPU_Type* mpu, uint8_t idx, uint8_t attr)
{
  const uint8_t reg = idx / 4U;
  const uint32_t pos = ((idx % 4U) * 8U);
  const uint32_t mask = 0xFFU << pos;

  if (reg >= (sizeof(mpu->MAIR) / sizeof(mpu->MAIR[0]))) {
    return;
  }

  mpu->MAIR[reg] = ((mpu->MAIR[reg] & ~mask) | ((attr << pos) & mask));
}





static inline void ARM_MPU_SetMemAttr(uint8_t idx, uint8_t attr)
{
  ARM_MPU_SetMemAttrEx(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) ), idx, attr);
}
# 294 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
static inline void ARM_MPU_ClrRegionEx(MPU_Type* mpu, uint32_t rnr)
{
  mpu->RNR = rnr;
  mpu->RLAR = 0U;
}




static inline void ARM_MPU_ClrRegion(uint32_t rnr)
{
  ARM_MPU_ClrRegionEx(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) ), rnr);
}
# 324 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
static inline void ARM_MPU_SetRegionEx(MPU_Type* mpu, uint32_t rnr, uint32_t rbar, uint32_t rlar)
{
  mpu->RNR = rnr;
  mpu->RBAR = rbar;
  mpu->RLAR = rlar;
}






static inline void ARM_MPU_SetRegion(uint32_t rnr, uint32_t rbar, uint32_t rlar)
{
  ARM_MPU_SetRegionEx(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) ), rnr, rbar, rlar);
}
# 358 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\m-profile/armv8m_mpu.h" 3
static inline void ARM_MPU_OrderedMemcpy(volatile uint32_t* dst, const uint32_t* __restrict src, uint32_t len)
{
  uint32_t i;
  for (i = 0U; i < len; ++i)
  {
    dst[i] = src[i];
  }
}







static inline void ARM_MPU_LoadEx(MPU_Type* mpu, uint32_t rnr, ARM_MPU_Region_t const* table, uint32_t cnt)
{
  const uint32_t rowWordSize = sizeof(ARM_MPU_Region_t)/4U;
  if (cnt == 1U) {
    mpu->RNR = rnr;
    ARM_MPU_OrderedMemcpy(&(mpu->RBAR), &(table->RBAR), rowWordSize);
  } else {
    uint32_t rnrBase = rnr & ~(4U -1U);
    uint32_t rnrOffset = rnr % 4U;

    mpu->RNR = rnrBase;
    while ((rnrOffset + cnt) > 4U) {
      uint32_t c = 4U - rnrOffset;
      ARM_MPU_OrderedMemcpy(&(mpu->RBAR)+(rnrOffset*2U), &(table->RBAR), c*rowWordSize);
      table += c;
      cnt -= c;
      rnrOffset = 0U;
      rnrBase += 4U;
      mpu->RNR = rnrBase;
    }

    ARM_MPU_OrderedMemcpy(&(mpu->RBAR)+(rnrOffset*2U), &(table->RBAR), cnt*rowWordSize);
  }
}






static inline void ARM_MPU_Load(uint32_t rnr, ARM_MPU_Region_t const* table, uint32_t cnt)
{
  ARM_MPU_LoadEx(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) ), rnr, table, cnt);
}
# 2916 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 2 3
# 2936 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t SCB_GetFPUType(void)
{
  uint32_t mvfr0;

  mvfr0 = ((FPU_Type *) ((0xE000E000UL) + 0x0F30UL) )->MVFR0;
  if ((mvfr0 & ((0xFUL << 4U) | (0xFUL << 8U))) == 0x220U)
  {
    return 2U;
  }
  else if ((mvfr0 & ((0xFUL << 4U) | (0xFUL << 8U))) == 0x020U)
  {
    return 1U;
  }
  else
  {
    return 0U;
  }
}
# 3010 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline void DCB_SetAuthCtrl(uint32_t value)
{
    __builtin_arm_dsb(0xF);
    __builtin_arm_isb(0xF);
    ((DCB_Type *) (0xE000EDF0UL) )->DAUTHCTRL = value;
    __builtin_arm_dsb(0xF);
    __builtin_arm_isb(0xF);
}







static inline uint32_t DCB_GetAuthCtrl(void)
{
    return (((DCB_Type *) (0xE000EDF0UL) )->DAUTHCTRL);
}
# 3077 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t DIB_GetAuthStatus(void)
{
    return (((DIB_Type *) (0xE000EFB0UL) )->DAUTHSTATUS);
}
# 3121 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t SysTick_Config(uint32_t ticks)
{
  if ((ticks - 1UL) > (0xFFFFFFUL ))
  {
    return (1UL);
  }

  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->LOAD = (uint32_t)(ticks - 1UL);
  __NVIC_SetPriority (SysTick_IRQn, (1UL << 3U) - 1UL);
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->VAL = 0UL;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL = (1UL << 2U) |
                   (1UL << 1U) |
                   (1UL );
  return (0UL);
}
# 3181 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
extern volatile int32_t ITM_RxBuffer;
# 3193 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline uint32_t ITM_SendChar (uint32_t ch)
{
  if (((((ITM_Type *) (0xE0000000UL) )->TCR & (1UL )) != 0UL) &&
      ((((ITM_Type *) (0xE0000000UL) )->TER & 1UL ) != 0UL) )
  {
    while (((ITM_Type *) (0xE0000000UL) )->PORT[0U].u32 == 0UL)
    {
      __nop();
    }
    ((ITM_Type *) (0xE0000000UL) )->PORT[0U].u8 = (uint8_t)ch;
  }
  return (ch);
}
# 3214 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline int32_t ITM_ReceiveChar (void)
{
  int32_t ch = -1;

  if (ITM_RxBuffer != ((int32_t)0x5AA55AA5U))
  {
    ch = ITM_RxBuffer;
    ITM_RxBuffer = ((int32_t)0x5AA55AA5U);
  }

  return (ch);
}
# 3234 "C:/Users/scli2/AppData/Local/Arm/Packs/ARM/CMSIS/6.3.0/CMSIS/Core/Include\\core_cm33.h" 3
static inline int32_t ITM_CheckChar (void)
{

  if (ITM_RxBuffer == ((int32_t)0x5AA55AA5U))
  {
    return (0);
  }
  else
  {
    return (1);
  }
}
# 110 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\system_M3351.h" 1
# 21 "../../../../Library/Device/Nuvoton/M3351/Include\\system_M3351.h"
# 1 "../../../../Library/StdDriver/inc\\partition_M3351_template.h" 1
# 22 "../../../../Library/Device/Nuvoton/M3351/Include\\system_M3351.h" 2





# 1 "../../../../Library/StdDriver/inc\\mpu_config_M3351_template.h" 1
# 437 "../../../../Library/StdDriver/inc\\mpu_config_M3351_template.h"
typedef enum
{
    eMPU_ATTR_DEV_nGnRnE,
    eMPU_ATTR_DEV_nGnRE,
    eMPU_ATTR_DEV_nGRE,
    eMPU_ATTR_DEV_GRE,
    eMPU_ATTR_NON_CACHEABLE,
    eMPU_ATTR_CACHEABLE_WTRA,
    eMPU_ATTR_CACHEABLE_WBWARA,
} E_MPU_ATTR;

typedef enum
{
    eMPU_RBAR_SH,
    eMPU_RBAR_RO,
    eMPU_RBAR_NP,
    eMPU_RBAR_XN,
} E_MPU_RBAR;
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\system_M3351.h" 2
# 108 "../../../../Library/Device/Nuvoton/M3351/Include\\system_M3351.h"
extern uint32_t CyclesPerUs;
extern uint32_t SystemCoreClock;
extern uint32_t PllClock;




typedef void(*VECTOR_TABLE_Type)(void);






extern void SystemInit(void);







extern void SystemCoreClockUpdate(void);





extern void SetDebugUartMFP(void);




extern void SetDebugUartCLK(void);




extern void InitDebugUart(void);






extern int32_t InitPreDefMPURegion(const ARM_MPU_Region_t *psMPURegion, uint32_t u32RegionCnt);
# 111 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 132 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\acmp_reg.h" 1
# 32 "../../../../Library/Device/Nuvoton/M3351/Include\\acmp_reg.h"
typedef struct
{
# 221 "../../../../Library/Device/Nuvoton/M3351/Include\\acmp_reg.h"
    volatile uint32_t CTL[2];
    volatile uint32_t STATUS;
    volatile uint32_t VREF;
    volatile uint32_t CALCTL;
    volatile uint32_t CALSTS;

} ACMP_T;
# 133 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\bpwm_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\bpwm_reg.h"
typedef struct
{
# 45 "../../../../Library/Device/Nuvoton/M3351/Include\\bpwm_reg.h"
    volatile uint32_t RCAPDAT;
    volatile uint32_t FCAPDAT;
} BCAPDAT_T;

typedef struct
{
# 1090 "../../../../Library/Device/Nuvoton/M3351/Include\\bpwm_reg.h"
    volatile uint32_t CTL0;
    volatile uint32_t CTL1;

    volatile const uint32_t RESERVE0[2];

    volatile uint32_t CLKSRC;
    volatile uint32_t CLKPSC;

    volatile const uint32_t RESERVE1[2];

    volatile uint32_t CNTEN;
    volatile uint32_t CNTCLR;

    volatile const uint32_t RESERVE2[2];

    volatile uint32_t PERIOD;

    volatile const uint32_t RESERVE3[7];

    volatile uint32_t CMPDAT[6];

    volatile const uint32_t RESERVE4[10];

    volatile const uint32_t CNT;

    volatile const uint32_t RESERVE5[7];

    volatile uint32_t WGCTL0;
    volatile uint32_t WGCTL1;
    volatile uint32_t MSKEN;
    volatile uint32_t MSK;

    volatile const uint32_t RESERVE6[5];

    volatile uint32_t POLCTL;
    volatile uint32_t POEN;

    volatile const uint32_t RESERVE7[1];

    volatile uint32_t INTEN;

    volatile const uint32_t RESERVE8[1];

    volatile uint32_t INTSTS;

    volatile const uint32_t RESERVE9[3];

    volatile uint32_t EADCTS0;
    volatile uint32_t EADCTS1;

    volatile const uint32_t RESERVE10[4];

    volatile uint32_t SSCTL;
    volatile uint32_t SSTRG;

    volatile const uint32_t RESERVE11[2];

    volatile uint32_t STATUS;

    volatile const uint32_t RESERVE12[55];

    volatile uint32_t CAPINEN;
    volatile uint32_t CAPCTL;
    volatile const uint32_t CAPSTS;
    BCAPDAT_T CAPDAT[6];
# 1168 "../../../../Library/Device/Nuvoton/M3351/Include\\bpwm_reg.h"
    volatile const uint32_t RESERVE13[5];

    volatile uint32_t CAPIEN;
    volatile uint32_t CAPIF;

    volatile const uint32_t RESERVE14[43];

    volatile const uint32_t PBUF;

    volatile const uint32_t RESERVE15[5];

    volatile const uint32_t CMPBUF[6];
} BPWM_T;
# 134 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\cache_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\cache_reg.h"
typedef struct
{
# 85 "../../../../Library/Device/Nuvoton/M3351/Include\\cache_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t STS;
    volatile const uint32_t HIT;
    volatile const uint32_t MISS;
    volatile uint32_t ERRADDR;
    volatile const uint32_t Reserved[11];
    volatile uint32_t PARITY;

} CACHE_T;
# 135 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\canfd_reg.h" 1
# 32 "../../../../Library/Device/Nuvoton/M3351/Include\\canfd_reg.h"
typedef struct
{
# 1090 "../../../../Library/Device/Nuvoton/M3351/Include\\canfd_reg.h"
    volatile const uint32_t RESERVE0[3];
    volatile uint32_t DBTP;
    volatile uint32_t TEST;
    volatile uint32_t RWD;
    volatile uint32_t CCCR;
    volatile uint32_t NBTP;
    volatile uint32_t TSCC;
    volatile uint32_t TSCV;
    volatile uint32_t TOCC;
    volatile uint32_t TOCV;
    volatile const uint32_t RESERVE1[4];
    volatile const uint32_t ECR;
    volatile const uint32_t PSR;
    volatile uint32_t TDCR;
    volatile const uint32_t RESERVE2[1];
    volatile uint32_t IR;
    volatile uint32_t IE;
    volatile uint32_t ILS;
    volatile uint32_t ILE;
    volatile const uint32_t RESERVE3[8];
    volatile uint32_t GFC;
    volatile uint32_t SIDFC;
    volatile uint32_t XIDFC;
    volatile const uint32_t RESERVE4[1];
    volatile uint32_t XIDAM;
    volatile const uint32_t HPMS;
    volatile uint32_t NDAT1;
    volatile uint32_t NDAT2;
    volatile uint32_t RXF0C;
    volatile const uint32_t RXF0S;
    volatile uint32_t RXF0A;
    volatile uint32_t RXBC;
    volatile uint32_t RXF1C;
    volatile const uint32_t RXF1S;
    volatile uint32_t RXF1A;
    volatile uint32_t RXESC;
    volatile uint32_t TXBC;
    volatile const uint32_t TXFQS;
    volatile uint32_t TXESC;
    volatile const uint32_t TXBRP;
    volatile uint32_t TXBAR;
    volatile uint32_t TXBCR;
    volatile const uint32_t TXBTO;
    volatile const uint32_t TXBCF;
    volatile uint32_t TXBTIE;
    volatile uint32_t TXBCIE;
    volatile const uint32_t RESERVE5[2];
    volatile uint32_t TXEFC;
    volatile const uint32_t TXEFS;
    volatile uint32_t TXEFA;
    volatile uint32_t STSEL;

} CANFD_T;
# 136 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\clk_reg.h" 1
# 33 "../../../../Library/Device/Nuvoton/M3351/Include\\clk_reg.h"
typedef struct
{
# 1338 "../../../../Library/Device/Nuvoton/M3351/Include\\clk_reg.h"
    volatile uint32_t PWRCTL;
    volatile uint32_t AHBCLK0;
    volatile uint32_t APBCLK0;
    volatile uint32_t APBCLK1;
    volatile uint32_t CLKSEL0;
    volatile uint32_t CLKSEL1;
    volatile uint32_t CLKSEL2;
    volatile uint32_t CLKSEL3;
    volatile uint32_t CLKDIV0;
    volatile uint32_t CLKDIV1;
    volatile uint32_t CLKDIV2;
    volatile const uint32_t RESERVE0[2];
    volatile uint32_t PCLKDIV;
    volatile uint32_t APBCLK2;
    volatile const uint32_t RESERVE1[1];
    volatile uint32_t PLLCTL;
    volatile const uint32_t RESERVE2[3];
    volatile const uint32_t STATUS;
    volatile uint32_t I3CHDRSCLEXT;
    volatile const uint32_t RESERVE3[2];
    volatile uint32_t CLKOCTL;
    volatile const uint32_t RESERVE4[3];
    volatile uint32_t CLKDCTL;
    volatile uint32_t CLKDSTS;
    volatile uint32_t CDUPB;
    volatile uint32_t CDLOWB;
    volatile uint32_t STOPREQ;
    volatile const uint32_t STOPACK;
    volatile const uint32_t RESERVE5[2];
    volatile uint32_t PMUCTL;
    volatile uint32_t PMUSTS;
    volatile const uint32_t RESERVE6[1];
    volatile uint32_t SWKDBCTL;
    volatile uint32_t PASWKCTL;
    volatile uint32_t PBSWKCTL;
    volatile uint32_t PCSWKCTL;
    volatile uint32_t PDSWKCTL;
    volatile uint32_t IOPDCTL;
    volatile const uint32_t RESERVE7[3];
    volatile uint32_t PMUINTC;
    volatile uint32_t PMUINTS;

} CLK_T;
# 137 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\crc_reg.h" 1
# 19 "../../../../Library/Device/Nuvoton/M3351/Include\\crc_reg.h"
typedef struct
{
# 166 "../../../../Library/Device/Nuvoton/M3351/Include\\crc_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t DAT;
    volatile uint32_t SEED;
    volatile const uint32_t CHECKSUM;
    volatile uint32_t POLYNOMIAL;
    volatile const uint32_t RESERVE0[11];
    volatile uint32_t DMACTL;
    volatile uint32_t DMASTS;
    volatile uint32_t SADDR;
    volatile uint32_t DMACNT;
    volatile const uint32_t RESERVE1[1003];
    volatile const uint32_t VERSION;

} CRC_T;
# 138 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\crypto_reg.h" 1
# 26 "../../../../Library/Device/Nuvoton/M3351/Include\\crypto_reg.h"
typedef struct
{
# 538 "../../../../Library/Device/Nuvoton/M3351/Include\\crypto_reg.h"
    volatile uint32_t INTEN;
    volatile uint32_t INTSTS;
    volatile uint32_t PRNG_CTL;
    volatile uint32_t PRNG_SEED;
    volatile const uint32_t PRNG_KEY[8];
    volatile const uint32_t PRNG_STS;
    volatile const uint32_t RESERVE0[19];
    volatile uint32_t AES_GCM_IVCNT[2];
    volatile uint32_t AES_GCM_ACNT[2];
    volatile uint32_t AES_GCM_PCNT[2];
    volatile const uint32_t RESERVE1[2];
    volatile uint32_t AES_FBADDR;
    volatile const uint32_t RESERVE2[23];
    volatile uint32_t AES_CTL;
    volatile const uint32_t AES_STS;
    volatile uint32_t AES_DATIN;
    volatile const uint32_t AES_DATOUT;
    volatile uint32_t AES_KEY[8];
    volatile uint32_t AES_IV[4];
    volatile uint32_t AES_SADDR;
    volatile uint32_t AES_DADDR;
    volatile uint32_t AES_CNT;
    volatile const uint32_t RESERVE3[109];
    volatile uint32_t HMAC_CTL;
    volatile const uint32_t HMAC_STS;
    volatile const uint32_t HMAC_DGST[16];
    volatile uint32_t HMAC_KEYCNT;
    volatile uint32_t HMAC_SADDR;
    volatile uint32_t HMAC_DMACNT;
    volatile uint32_t HMAC_DATIN;
    volatile const uint32_t RESERVE4[105];
    volatile uint32_t HMAC_FBADDR;

} CRYPTO_T;
# 139 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\dac_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\dac_reg.h"
typedef struct
{
# 137 "../../../../Library/Device/Nuvoton/M3351/Include\\dac_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t SWTRG;
    volatile uint32_t DAT;
    volatile const uint32_t DATOUT;
    volatile uint32_t STATUS;
    volatile uint32_t TCTL;

} DAC_T;
# 140 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\dfmc_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\dfmc_reg.h"
typedef struct
{
# 278 "../../../../Library/Device/Nuvoton/M3351/Include\\dfmc_reg.h"
    volatile uint32_t ISPCTL;
    volatile uint32_t ISPADDR;
    volatile uint32_t ISPDAT;
    volatile uint32_t ISPCMD;
    volatile uint32_t ISPTRG;
    volatile const uint32_t RESERVE0[11];
    volatile uint32_t ISPSTS;
    volatile const uint32_t RESERVE1[2];
    volatile uint32_t CYCCTL;
    volatile const uint32_t RESERVE2[16];
    volatile uint32_t MPDATE;
    volatile const uint32_t RESERVE3[39];
    volatile uint32_t ECCCTL;
    volatile uint32_t ECCSTS;
    volatile const uint32_t ECCSEFAR;
    volatile const uint32_t ECCDEFAR;
    volatile const uint32_t EEP_STS;
    volatile const uint32_t RESERVE4[3];
    volatile uint32_t SMWR_CFG0;
    volatile uint32_t SMWR_CFG1;
    volatile uint32_t SMWR_CFG2;
    volatile uint32_t SMWR_CFG3;
    volatile uint32_t SMWR_CFG4;

} DFMC_T;
# 141 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\eadc_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\eadc_reg.h"
typedef struct
{
# 767 "../../../../Library/Device/Nuvoton/M3351/Include\\eadc_reg.h"
    volatile const uint32_t DAT[19];
    volatile const uint32_t CURDAT;
    volatile uint32_t CTL;
    volatile uint32_t SWTRG;
    volatile uint32_t PENDSTS;
    volatile uint32_t OVSTS;
    volatile uint32_t CTL1;
    volatile const uint32_t RESERVE0[7];
    volatile uint32_t SCTL[19];
    volatile const uint32_t RESERVE1[1];
    volatile uint32_t INTSRC[4];
    volatile uint32_t CMP[4];
    volatile const uint32_t STATUS0;
    volatile const uint32_t STATUS1;
    volatile uint32_t STATUS2;
    volatile const uint32_t STATUS3;
    volatile const uint32_t DDAT[4];
    volatile const uint32_t RESERVE2[1];
    volatile uint32_t CALCTL;
    volatile uint32_t CALSR;
    volatile const uint32_t RESERVE3[5];
    volatile uint32_t PDMACTL;
    volatile const uint32_t RESERVE4[3];
    volatile uint32_t MCTL1[19];
    volatile const uint32_t RESERVE5[29];
    volatile const uint32_t DAT19[8];
    volatile const uint32_t RESERVE6[4];
    volatile uint32_t SCTL19[8];
    volatile const uint32_t RESERVE7[4];
    volatile uint32_t M19CTL1[8];

} EADC_T;
# 142 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\ebi_reg.h" 1
# 19 "../../../../Library/Device/Nuvoton/M3351/Include\\ebi_reg.h"
typedef struct
{
# 240 "../../../../Library/Device/Nuvoton/M3351/Include\\ebi_reg.h"
    volatile uint32_t CTL0;
    volatile uint32_t TCTL0;
    volatile const uint32_t RESERVE0[2];
    volatile uint32_t CTL1;
    volatile uint32_t TCTL1;
    volatile const uint32_t RESERVE1[2];
    volatile uint32_t CTL2;
    volatile uint32_t TCTL2;
    volatile const uint32_t RESERVE2[1013];
    volatile const uint32_t VERSION;

} EBI_T;
# 143 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\ecap_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\ecap_reg.h"
typedef struct
{
# 243 "../../../../Library/Device/Nuvoton/M3351/Include\\ecap_reg.h"
    volatile uint32_t CNT;
    volatile uint32_t HLD0;
    volatile uint32_t HLD1;
    volatile uint32_t HLD2;
    volatile uint32_t CNTCMP;
    volatile uint32_t CTL0;
    volatile uint32_t CTL1;
    volatile uint32_t STATUS;
} ECAP_T;
# 144 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\ellsi_reg.h" 1
# 26 "../../../../Library/Device/Nuvoton/M3351/Include\\ellsi_reg.h"
typedef struct
{
# 50 "../../../../Library/Device/Nuvoton/M3351/Include\\ellsi_reg.h"
    volatile uint32_t FBPCNT;
    volatile uint32_t FBSID;
} ELLSI_FB_T;

typedef struct
{
# 414 "../../../../Library/Device/Nuvoton/M3351/Include\\ellsi_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t RSTPERIOD;
    volatile uint32_t PERIOD;
    volatile uint32_t DUTY;
    volatile uint32_t DATA;
    volatile uint32_t PCNT;
    volatile uint32_t CLKDIV;
    volatile uint32_t STATUS;
    volatile uint32_t OCTL;
    volatile uint32_t CMDCTL;
    volatile uint32_t CMDGPP;
    volatile uint32_t CMD;
    volatile uint32_t CMDSTS;
    volatile uint32_t FBCCTL;
    volatile uint32_t FBCTCTL;
    volatile uint32_t FBIDTCTL;

    ELLSI_FB_T FB[15];

    volatile uint32_t TCCTL;
    volatile uint32_t TCTCTL;
    volatile uint32_t WKTCTL;
} ELLSI_T;
# 145 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\pwm_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\pwm_reg.h"
typedef struct
{
# 45 "../../../../Library/Device/Nuvoton/M3351/Include\\pwm_reg.h"
    volatile uint32_t RCAPDAT;
    volatile uint32_t FCAPDAT;
} CAPDAT_T;

typedef struct
{
# 1767 "../../../../Library/Device/Nuvoton/M3351/Include\\pwm_reg.h"
    volatile uint32_t CTL0;
    volatile uint32_t CTL1;

    volatile const uint32_t RESERVE0[2];

    volatile uint32_t CLKSRC;
    volatile uint32_t CLKPSC[3];
    volatile uint32_t CNTEN;
    volatile uint32_t CNTCLR;

    volatile const uint32_t RESERVE1[2];

    volatile uint32_t PERIOD[6];

    volatile const uint32_t RESERVE2[2];

    volatile uint32_t CMPDAT[6];

    volatile const uint32_t RESERVE3[2];

    volatile uint32_t DTCTL[3];

    volatile const uint32_t RESERVE4[5];

    volatile const uint32_t CNT[6];

    volatile const uint32_t RESERVE5[2];

    volatile uint32_t WGCTL0;
    volatile uint32_t WGCTL1;
    volatile uint32_t MSKEN;
    volatile uint32_t MSK;
    volatile uint32_t BNF;
    volatile uint32_t FAILBRK;
    volatile uint32_t BRKCTL[3];
    volatile uint32_t POLCTL;
    volatile uint32_t POEN;
    volatile uint32_t SWBRK;
    volatile uint32_t INTEN0;
    volatile uint32_t INTEN1;
    volatile uint32_t INTSTS0;
    volatile uint32_t INTSTS1;

    volatile const uint32_t RESERVE6[1];

    volatile uint32_t DACTRGEN;
    volatile uint32_t EADCTS0;
    volatile uint32_t EADCTS1;

    volatile const uint32_t RESERVE7[4];

    volatile uint32_t SSCTL;
    volatile uint32_t SSTRG;

    volatile const uint32_t RESERVE8[2];

    volatile uint32_t STATUS;

    volatile const uint32_t RESERVE9[3];

    volatile uint32_t IFA[6];

    volatile const uint32_t RESERVE10[2];

    volatile uint32_t AINTSTS;
    volatile uint32_t AINTEN;
    volatile uint32_t APDMACTL;

    volatile const uint32_t RESERVE11[41];

    volatile uint32_t CAPINEN;
    volatile uint32_t CAPCTL;
    volatile const uint32_t CAPSTS;
    CAPDAT_T CAPDAT[6];
    volatile uint32_t PDMACTL;
    volatile const uint32_t PDMACAP[3];

    volatile const uint32_t RESERVE12[1];

    volatile uint32_t CAPIEN;
    volatile uint32_t CAPIF;
    volatile uint32_t CAPNF[6];
    volatile uint32_t EXTETCTL[6];
    volatile uint32_t SWEOFCTL;
    volatile uint32_t SWEOFTRG;

    volatile const uint32_t RESERVE13[29];

    volatile const uint32_t PBUF[6];
    volatile const uint32_t CMPBUF[6];
} PWM_T;
# 146 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\eqei_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\eqei_reg.h"
typedef struct
{
# 271 "../../../../Library/Device/Nuvoton/M3351/Include\\eqei_reg.h"
    volatile uint32_t CNT;
    volatile uint32_t CNTHOLD;
    volatile uint32_t CNTLATCH;
    volatile uint32_t CNTCMP;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t CNTMAX;
    volatile uint32_t CTL;
    volatile uint32_t CTL2;
    volatile uint32_t UTCNT;
    volatile uint32_t UTCMP;
    volatile const uint32_t RESERVE1[1];
    volatile uint32_t STATUS;

} EQEI_T;
# 147 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\fmc_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\fmc_reg.h"
typedef struct
{
# 597 "../../../../Library/Device/Nuvoton/M3351/Include\\fmc_reg.h"
    volatile uint32_t ISPCTL;
    volatile uint32_t ISPADDR;
    volatile uint32_t ISPDAT;
    volatile uint32_t ISPCMD;
    volatile uint32_t ISPTRG;
    volatile const uint32_t RESERVE0[11];
    volatile uint32_t ISPSTS;
    volatile const uint32_t RESERVE1[2];
    volatile uint32_t CYCCTL;
    volatile const uint32_t RESERVE2[12];
    volatile uint32_t MPDAT0;
    volatile uint32_t MPDAT1;
    volatile uint32_t MPDAT2;
    volatile uint32_t MPDAT3;
    volatile uint32_t MPDATE;
    volatile const uint32_t RESERVE3[15];
    volatile const uint32_t XOMR0STS;
    volatile const uint32_t XOMR1STS;
    volatile const uint32_t RESERVE4[2];
    volatile const uint32_t XOMSTS;
    volatile const uint32_t SOTPSTS;
    volatile const uint32_t RESERVE5[10];
    volatile uint32_t APWPROT0;
    volatile uint32_t APWPROT1;
    volatile uint32_t APWPKEEP;
    volatile uint32_t SCACT;
    volatile uint32_t LDWPROT;
    volatile uint32_t LDWPKEEP;
    volatile uint32_t DFWPROT;
    volatile uint32_t DFWPKEEP;
    volatile uint32_t ECCCTL;
    volatile uint32_t ECCSTS;
    volatile const uint32_t ECCSEFAR;
    volatile const uint32_t ECCDEFAR;

} FMC_T;
# 148 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\gpio_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\gpio_reg.h"
typedef struct
{
# 291 "../../../../Library/Device/Nuvoton/M3351/Include\\gpio_reg.h"
    volatile uint32_t MODE;
    volatile uint32_t DINOFF;
    volatile uint32_t DOUT;
    volatile uint32_t DATMSK;
    volatile const uint32_t PIN;
    volatile uint32_t DBEN;
    volatile uint32_t INTTYPE;
    volatile uint32_t INTEN;
    volatile uint32_t INTSRC;
    volatile uint32_t SMTEN;
    volatile uint32_t SLEWCTL;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t PUSEL;
    volatile uint32_t DBCTL;

} GPIO_T;

typedef struct
{
# 358 "../../../../Library/Device/Nuvoton/M3351/Include\\gpio_reg.h"
    volatile uint32_t INNF;
    volatile uint32_t EDETCTL;
    volatile uint32_t EDINTEN;
    volatile uint32_t EDSTS;

    volatile const uint32_t RESERVE0[4];

} EINT_T;

typedef struct
{
    EINT_T EINT[8];
} GPIO_INT_T;
# 149 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\i2c_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\i2c_reg.h"
typedef struct
{
# 523 "../../../../Library/Device/Nuvoton/M3351/Include\\i2c_reg.h"
    volatile uint32_t CTL0;
    volatile uint32_t ADDR0;
    volatile uint32_t DAT;
    volatile const uint32_t STATUS0;
    volatile uint32_t CLKDIV;
    volatile uint32_t TOCTL;
    volatile uint32_t ADDR1;
    volatile uint32_t ADDR2;
    volatile uint32_t ADDR3;
    volatile uint32_t ADDRMSK0;
    volatile uint32_t ADDRMSK1;
    volatile uint32_t ADDRMSK2;
    volatile uint32_t ADDRMSK3;

    volatile const uint32_t RESERVE0[2];

    volatile uint32_t WKCTL;
    volatile uint32_t WKSTS;
    volatile uint32_t CTL1;
    volatile uint32_t STATUS1;
    volatile uint32_t TMCTL;
    volatile uint32_t BUSCTL;
    volatile uint32_t BUSTCTL;
    volatile uint32_t BUSSTS;
    volatile uint32_t PKTSIZE;
    volatile const uint32_t PKTCRC;
    volatile uint32_t BUSTOUT;
    volatile uint32_t CLKTOUT;

} I2C_T;
# 150 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\i3c_reg.h" 1
# 29 "../../../../Library/Device/Nuvoton/M3351/Include\\i3c_reg.h"
typedef struct
{
    union
    {
        volatile uint32_t WORD1;
        volatile uint32_t CFG;
    };
    union
    {
        volatile uint32_t WORD2;
        volatile uint32_t DATA;
        volatile uint32_t BTBYTES;
    };
    union
    {
        volatile uint32_t WORD3;
        volatile uint32_t BTRDLEN;
    };
} EXTCMD_T;


typedef struct
{
    union
    {
        volatile const uint32_t CHAR1;
        volatile const uint32_t PIDMSB;
    };
    union
    {
        volatile const uint32_t CHAR2;
        volatile const uint32_t PIDLSB;
    };
    union
    {
        volatile const uint32_t CHAR3;
        volatile const uint32_t BCRDCR;
    };
    union
    {
        volatile const uint32_t CHAR4;
        volatile const uint32_t DADDR;
    };
} TGTCHAR_T;


typedef struct
{
    volatile uint32_t ADDR;
    volatile uint32_t MID;
    volatile uint32_t PID;
    volatile uint32_t CHAR;


    volatile const uint32_t RESERVE[4];

} VTGTCFG_T;


typedef struct
{
    volatile uint32_t DEVCTL;
    volatile uint32_t DEVADDR;

    volatile const uint32_t RESERVE0;

    volatile uint32_t CMDQUE;
    volatile const uint32_t RESPQUE;





    volatile uint32_t TXRXDAT;
    union
    {
        volatile const uint32_t IBISTS;
        volatile const uint32_t IBIQUE;
    };
    volatile uint32_t QUETHCTL;
    volatile uint32_t DBTHCTL;
    volatile uint32_t IBIQCTL;

    volatile const uint32_t RESERVE1[3];

    volatile uint32_t RSTCTL;
    volatile uint32_t SLVEVNTS;
    volatile uint32_t INTSTS;
    volatile uint32_t INTSTSEN;
    volatile uint32_t INTEN;

    volatile const uint32_t RESERVE2;

    volatile const uint32_t QUESTSLV;
    volatile const uint32_t DBSTSLV;
    volatile const uint32_t PRESENTS;
    volatile const uint32_t CCCDEVS;
    volatile const uint32_t ADDRTBP;
    volatile const uint32_t CHRTBP;

    volatile const uint32_t RESERVE3[3];

    volatile uint32_t SLVMID;
    volatile uint32_t SLVPID;
    volatile uint32_t SLVCHAR;
    volatile const uint32_t SLVMXLEN;

    volatile const uint32_t RESERVE4;

    volatile uint32_t MXDS;

    volatile const uint32_t RESERVE5;

    volatile uint32_t SIR;

    volatile const uint32_t RESERVE6;

    volatile uint32_t SIRDAT;
    volatile uint32_t SIRRESP;

    volatile const uint32_t RESERVE7[2];

    volatile const uint32_t INSTSTS;

    volatile const uint32_t RESERVE8[2];

    volatile uint32_t DEVCTLE;
    volatile uint32_t SCLOD;
    volatile uint32_t SCLPP;
    volatile uint32_t SCLFM;
    volatile uint32_t SCLFMP;

    volatile const uint32_t RESERVE9;

    volatile uint32_t SCLEXTLO;
    volatile uint32_t SCLEXTTB;
    volatile uint32_t SDAHOLD;
    volatile uint32_t BUSFAT;
    volatile uint32_t BUSIDLET;
    volatile uint32_t SCLLOWTO;

    volatile const uint32_t RESERVE10[3];

    volatile uint32_t RELSDA;

    volatile const uint32_t RESERVE11;

    volatile uint32_t BTDELY;

    volatile const uint32_t RESERVE12[14];

    volatile uint32_t EXTDAT[8];
    volatile const uint32_t EXTTXTHS;
    volatile const uint32_t EXTDBSL[4];
    EXTCMD_T EXTCMD[8];
    volatile uint32_t EXTDBRST;
    volatile const uint32_t EXTCMDFS;
    volatile uint32_t EXTTHLD;

    volatile const uint32_t RESERVE13[4];

    volatile uint32_t GRPASTS[4];

    volatile const uint32_t RESERVE14[4];

    TGTCHAR_T TGTCHAR[7];

    volatile const uint32_t RESERVE15[4];

    volatile uint32_t TGTCFG[7];

    volatile const uint32_t RESERVE16[153];

    VTGTCFG_T VTGTCFG[4];

} I3C_T;
# 151 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\llsi_reg.h" 1
# 26 "../../../../Library/Device/Nuvoton/M3351/Include\\llsi_reg.h"
typedef struct
{
# 161 "../../../../Library/Device/Nuvoton/M3351/Include\\llsi_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t RSTPERIOD;
    volatile uint32_t PERIOD;
    volatile uint32_t DUTY;
    volatile uint32_t DATA;
    volatile uint32_t PCNT;
    volatile uint32_t CLKDIV;
    volatile uint32_t STATUS;
    volatile uint32_t OCTL;
} LLSI_T;
# 152 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\pdma_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\pdma_reg.h"
typedef struct
{
# 115 "../../../../Library/Device/Nuvoton/M3351/Include\\pdma_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t SA;
    volatile uint32_t DA;
    volatile uint32_t NEXT;
} DSCT_T;

typedef struct
{
# 443 "../../../../Library/Device/Nuvoton/M3351/Include\\pdma_reg.h"
    DSCT_T DSCT[12];

    volatile const uint32_t RESERVE1[16];

    volatile const uint32_t CURSCAT[12];


    volatile const uint32_t RESERVE2[180];

    volatile uint32_t CHCTL;
    volatile uint32_t PAUSE;
    volatile uint32_t SWREQ;
    volatile const uint32_t TRGSTS;
    volatile uint32_t PRISET;
    volatile uint32_t PRICLR;
    volatile uint32_t INTEN;
    volatile uint32_t INTSTS;
    volatile uint32_t ABTSTS;
    volatile uint32_t TDSTS;
    volatile uint32_t ALIGN;
    volatile const uint32_t TACTSTS;

    volatile const uint32_t RESERVE3[12];

    volatile uint32_t CHRST;

    volatile const uint32_t RESERVE4[7];

    volatile uint32_t REQSEL0_3;
    volatile uint32_t REQSEL4_7;
    volatile uint32_t REQSEL8_11;
} PDMA_T;
# 153 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\qspi_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\qspi_reg.h"
typedef struct
{
# 384 "../../../../Library/Device/Nuvoton/M3351/Include\\qspi_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t CLKDIV;
    volatile uint32_t SSCTL;
    volatile uint32_t PDMACTL;
    volatile uint32_t FIFOCTL;
    volatile uint32_t STATUS;
    volatile const uint32_t STATUS2;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t TX;
    volatile const uint32_t RESERVE1[3];
    volatile const uint32_t RX;
} QSPI_T;
# 154 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\rtc_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\rtc_reg.h"
typedef struct
{
# 275 "../../../../Library/Device/Nuvoton/M3351/Include\\rtc_reg.h"
    volatile uint32_t INIT;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t FREQADJ;
    volatile uint32_t TIME;
    volatile uint32_t CAL;
    volatile uint32_t CLKFMT;
    volatile uint32_t WEEKDAY;
    volatile uint32_t TALM;
    volatile uint32_t CALM;
    volatile const uint32_t LEAPYEAR;
    volatile uint32_t INTEN;
    volatile uint32_t INTSTS;
    volatile uint32_t TICK;
    volatile uint32_t TAMSK;
    volatile uint32_t CAMSK;
    volatile const uint32_t RESERVE1[49];
    volatile uint32_t LXTCTL;
    volatile const uint32_t RESERVE2[3];
    volatile uint32_t DSTCTL;

} RTC_T;
# 155 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\scu_reg.h" 1
# 26 "../../../../Library/Device/Nuvoton/M3351/Include\\scu_reg.h"
typedef struct
{
# 1069 "../../../../Library/Device/Nuvoton/M3351/Include\\scu_reg.h"
    union
    {
        volatile uint32_t PNSSET[7];
        struct
        {
            volatile uint32_t PNSSET0;
            volatile uint32_t PNSSET1;
            volatile uint32_t PNSSET2;
            volatile uint32_t PNSSET3;
            volatile uint32_t PNSSET4;
            volatile uint32_t PNSSET5;
            volatile uint32_t PNSSET6;
        };
    };
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t SRAMNSSET;
    volatile const uint32_t RESERVE1[2];
    volatile const uint32_t FNSADDR;
    volatile uint32_t SVIEN;
    volatile uint32_t SVINTSTS;
    volatile const uint32_t RESERVE2[1];
    volatile const uint32_t DFNSADDR;
    volatile const uint32_t FLASHVSRC;
    volatile const uint32_t FLASHVA;
    volatile const uint32_t SRAM0VSRC;
    volatile const uint32_t SRAM0VA;
    volatile const uint32_t SRAM1VSRC;
    volatile const uint32_t SRAM1VA;
    volatile const uint32_t SRAM2VSRC;

    volatile const uint32_t SRAM2VA;

    volatile const uint32_t APB0VSRC;
    volatile const uint32_t APB0VA;
    volatile const uint32_t APB1VSRC;
    volatile const uint32_t APB1VA;
    volatile const uint32_t EBIVSRC;
    volatile const uint32_t EBIVA;
    volatile const uint32_t SYSVSRC;
    volatile const uint32_t SYSVA;
    volatile const uint32_t FMCVSRC;
    volatile const uint32_t FMCVA;
    volatile const uint32_t PDMA0VSRC;
    volatile const uint32_t PDMA0VA;
    volatile const uint32_t CRCVSRC;
    volatile const uint32_t CRCVA;
    volatile const uint32_t CANFD0VSRC;
    volatile const uint32_t CANFD0VA;
    volatile const uint32_t CANFD1VSRC;
    volatile const uint32_t CANFD1VA;
    volatile const uint32_t SCUVSRC;
    volatile const uint32_t SCUVA;
    volatile const uint32_t GPIOVSRC;
    volatile const uint32_t GPIOVA;
    volatile const uint32_t RESERVE3[1];
    volatile const uint32_t USBHVA;
    volatile const uint32_t USBHVSRC;
    volatile const uint32_t RESERVE4[3];
    volatile const uint32_t CACHEVSRC;
    volatile const uint32_t CACHEVA;
    volatile const uint32_t DFLASHVSRC;
    volatile const uint32_t DFLASHVA;
    volatile const uint32_t DFMCVSRC;
    volatile const uint32_t DFMCVA;
    volatile const uint32_t RESERVE5[2];
    volatile uint32_t SINFAEN;
    volatile const uint32_t RESERVE6[16];
    volatile uint32_t SCWP;
    volatile const uint32_t RESERVE7[1];
    volatile uint32_t EINTNS;
    union
    {
        volatile uint32_t IONSSET[8];
        struct
        {
            volatile uint32_t IONSSET0;
            volatile uint32_t IONSSET1;
            volatile uint32_t IONSSET2;
            volatile uint32_t IONSSET3;
            volatile uint32_t IONSSET4;
            volatile uint32_t IONSSET5;
            volatile uint32_t IONSSET6;
            volatile uint32_t IONSSET7;
        };
    };
    volatile const uint32_t RESERVE8[40];
    volatile uint32_t NSMCTL;
    volatile uint32_t NSMLOAD;
    volatile uint32_t NSMVAL;
    volatile uint32_t NSMSTS;

} SCU_T;
# 156 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\spi_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\spi_reg.h"
typedef struct
{
# 534 "../../../../Library/Device/Nuvoton/M3351/Include\\spi_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t CLKDIV;
    volatile uint32_t SSCTL;
    volatile uint32_t PDMACTL;
    volatile uint32_t FIFOCTL;
    volatile uint32_t STATUS;
    volatile const uint32_t STATUS2;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t TX;
    volatile const uint32_t RESERVE1[3];
    volatile const uint32_t RX;
    volatile const uint32_t RESERVE2[11];
    volatile uint32_t I2SCTL;
    volatile uint32_t I2SCLK;
    volatile uint32_t I2SSTS;
} SPI_T;
# 157 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\sys_reg.h" 1
# 33 "../../../../Library/Device/Nuvoton/M3351/Include\\sys_reg.h"
typedef struct
{
# 183 "../../../../Library/Device/Nuvoton/M3351/Include\\sys_reg.h"
    volatile uint32_t NMIEN;
    volatile const uint32_t NMISTS;
    volatile uint32_t NMIMSEL;

} NMI_T;
# 315 "../../../../Library/Device/Nuvoton/M3351/Include\\sys_reg.h"
typedef struct
{
# 2495 "../../../../Library/Device/Nuvoton/M3351/Include\\sys_reg.h"
    volatile const uint32_t PDID;
    volatile uint32_t RSTSTS;
    volatile uint32_t IPRST0;
    volatile uint32_t IPRST1;
    volatile uint32_t IPRST2;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t BODCTL;
    volatile uint32_t IVSCTL;
    volatile uint32_t IPRST3;
    volatile const uint32_t RESERVE1[1];
    volatile uint32_t VREFCTL;
    volatile uint32_t USBPHY;
    volatile const uint32_t RESERVE2[20];
    volatile uint32_t GPA_MFOS;
    volatile uint32_t GPB_MFOS;
    volatile uint32_t GPC_MFOS;
    volatile uint32_t GPD_MFOS;
    volatile uint32_t GPE_MFOS;
    volatile uint32_t GPF_MFOS;
    volatile uint32_t GPG_MFOS;
    volatile uint32_t GPH_MFOS;
    volatile const uint32_t RESERVE3[2];
    volatile uint32_t VTORSET;
    volatile const uint32_t RESERVE4[5];
    volatile uint32_t SRAM_INTCTL;
    volatile uint32_t SRAM_STATUS;
    volatile const uint32_t SRAM_ERRADDR;
    volatile uint32_t SRAM_LSCTL;
    volatile uint32_t SRAM_BISTCTL;
    volatile const uint32_t SRAM_BISTSTS;
    volatile const uint32_t RESERVE5[1];
    volatile uint32_t SRAM_ECCEN;
    volatile const uint32_t RESERVE6[1];
    volatile uint32_t HIRCTCTL;
    volatile uint32_t HIRCTIEN;
    volatile uint32_t HIRCTISTS;
    volatile uint32_t SRAM_NSINTCTL;
    volatile uint32_t SRAM_NSSTATUS;
    volatile const uint32_t SRAM_NSERRADDR;
    volatile const uint32_t RESERVE7[1];
    volatile uint32_t REGLCTL;
    volatile const uint32_t RESERVE8[58];
    volatile uint32_t PORDISAN;
    volatile const uint32_t RESERVE9[132];
    volatile uint32_t AHBMCTL;
    volatile const uint32_t RESERVE10[63];
    volatile uint32_t GPA_MFP0;
    volatile uint32_t GPA_MFP1;
    volatile uint32_t GPA_MFP2;
    volatile uint32_t GPA_MFP3;
    volatile uint32_t GPB_MFP0;
    volatile uint32_t GPB_MFP1;
    volatile uint32_t GPB_MFP2;
    volatile uint32_t GPB_MFP3;
    volatile uint32_t GPC_MFP0;
    volatile uint32_t GPC_MFP1;
    volatile uint32_t GPC_MFP2;
    volatile uint32_t GPC_MFP3;
    volatile uint32_t GPD_MFP0;
    volatile uint32_t GPD_MFP1;
    volatile uint32_t GPD_MFP2;
    volatile uint32_t GPD_MFP3;
    volatile uint32_t GPE_MFP0;
    volatile uint32_t GPE_MFP1;
    volatile uint32_t GPE_MFP2;
    volatile uint32_t GPE_MFP3;
    volatile uint32_t GPF_MFP0;
    volatile uint32_t GPF_MFP1;
    volatile uint32_t GPF_MFP2;
    volatile uint32_t GPF_MFP3;
    volatile uint32_t GPG_MFP0;
    volatile uint32_t GPG_MFP1;
    volatile uint32_t GPG_MFP2;
    volatile uint32_t GPG_MFP3;
    volatile uint32_t GPH_MFP0;
    volatile uint32_t GPH_MFP1;
    volatile uint32_t GPH_MFP2;
    volatile const uint32_t RESERVE11[33];
    volatile uint32_t I3C0PADCTL;

} SYS_T;
# 158 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\timer_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\timer_reg.h"
typedef struct
{
# 1039 "../../../../Library/Device/Nuvoton/M3351/Include\\timer_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t CMP;
    volatile uint32_t INTSTS;
    volatile uint32_t CNT;
    volatile const uint32_t CAP;
    volatile uint32_t EXTCTL;
    volatile uint32_t EINTSTS;
    volatile uint32_t TRGCTL;

    volatile const uint32_t RESERVE0[1];

    volatile uint32_t CAPNF;

    volatile const uint32_t RESERVE1[6];

    volatile uint32_t PWMCTL;
    volatile uint32_t PWMCLKPSC;
    volatile uint32_t PWMCNTCLR;
    volatile uint32_t PWMPERIOD;
    volatile uint32_t PWMCMPDAT;
    volatile const uint32_t PWMCNT;
    volatile uint32_t PWMPOLCTL;
    volatile uint32_t PWMPOCTL;
    volatile uint32_t PWMINTEN0;
    volatile uint32_t PWMINTSTS0;
    volatile uint32_t PWMTRGCTL;
    volatile uint32_t PWMSTATUS;
    volatile const uint32_t PWMPBUF;
    volatile const uint32_t PWMCMPBUF;

    volatile const uint32_t RESERVE2[12];

    volatile uint32_t PWMIFA;
    volatile uint32_t PWMAINTSTS;
    volatile uint32_t PWMAINTEN;
    volatile uint32_t PWMAPDMACTL;

} TIMER_T;
# 159 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\trng_reg.h" 1
# 26 "../../../../Library/Device/Nuvoton/M3351/Include\\trng_reg.h"
typedef struct
{
# 136 "../../../../Library/Device/Nuvoton/M3351/Include\\trng_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t CFG;
    volatile const uint32_t STS;
    volatile const uint32_t DATA_OUT[4];




} TRNG_T;
# 160 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\uart_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\uart_reg.h"
typedef struct
{
# 945 "../../../../Library/Device/Nuvoton/M3351/Include\\uart_reg.h"
    volatile uint32_t DAT;
    volatile uint32_t INTEN;
    volatile uint32_t FIFO;
    volatile uint32_t LINE;
    volatile uint32_t MODEM;
    volatile uint32_t MODEMSTS;
    volatile uint32_t FIFOSTS;
    volatile uint32_t INTSTS;
    volatile uint32_t TOUT;
    volatile uint32_t BAUD;
    volatile uint32_t IRDA;
    volatile uint32_t ALTCTL;
    volatile uint32_t FUNCSEL;
    volatile uint32_t LINCTL;
    volatile uint32_t LINSTS;
    volatile uint32_t BRCOMP;
    volatile uint32_t WKCTL;
    volatile uint32_t WKSTS;
    volatile uint32_t DWKCOMP;
    volatile uint32_t RS485DD;
    volatile uint32_t LINRTOUT;
    volatile uint32_t LINWKCTL;

} UART_T;
# 161 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\ui2c_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\ui2c_reg.h"
typedef struct
{
# 374 "../../../../Library/Device/Nuvoton/M3351/Include\\ui2c_reg.h"
    volatile uint32_t CTL;

    volatile const uint32_t RESERVE0[1];

    volatile uint32_t BRGEN;

    volatile const uint32_t RESERVE1[8];

    volatile uint32_t LINECTL;
    volatile uint32_t TXDAT;
    volatile const uint32_t RXDAT;

    volatile const uint32_t RESERVE2[3];

    volatile uint32_t DEVADDR0;
    volatile uint32_t DEVADDR1;
    volatile uint32_t ADDRMSK0;
    volatile uint32_t ADDRMSK1;
    volatile uint32_t WKCTL;
    volatile uint32_t WKSTS;
    volatile uint32_t PROTCTL;
    volatile uint32_t PROTIEN;
    volatile uint32_t PROTSTS;

    volatile const uint32_t RESERVE3[8];

    volatile uint32_t ADMAT;
    volatile uint32_t TMCTL;

} UI2C_T;
# 162 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\usbd_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\usbd_reg.h"
typedef struct
{
# 106 "../../../../Library/Device/Nuvoton/M3351/Include\\usbd_reg.h"
    volatile uint32_t BUFSEG;
    volatile uint32_t MXPLD;
    volatile uint32_t CFG;
    volatile uint32_t CFGP;

} USBD_EP_T;

typedef struct
{
# 594 "../../../../Library/Device/Nuvoton/M3351/Include\\usbd_reg.h"
    volatile uint32_t INTEN;
    volatile uint32_t INTSTS;
    volatile uint32_t FADDR;
    volatile const uint32_t EPSTS;
    volatile uint32_t ATTR;
    volatile const uint32_t VBUSDET;
    volatile uint32_t STBUFSEG;
    volatile const uint32_t RESERVE0[1];
    volatile const uint32_t EPSTS0;
    volatile const uint32_t EPSTS1;
    volatile const uint32_t EPSTS2;
    volatile const uint32_t RESERVE1[1];
    volatile uint32_t EPINTSTS;
    volatile const uint32_t RESERVE2[21];
    volatile const uint32_t LPMATTR;
    volatile const uint32_t FN;
    volatile uint32_t SE0;
    volatile const uint32_t RESERVE3[283];
    USBD_EP_T EP[23];

} USBD_T;
# 163 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\usbh_reg.h" 1
# 27 "../../../../Library/Device/Nuvoton/M3351/Include\\usbh_reg.h"
typedef struct
{
# 542 "../../../../Library/Device/Nuvoton/M3351/Include\\usbh_reg.h"
    volatile const uint32_t HcRevision;
    volatile uint32_t HcControl;
    volatile uint32_t HcCommandStatus;
    volatile uint32_t HcInterruptStatus;
    volatile uint32_t HcInterruptEnable;
    volatile uint32_t HcInterruptDisable;
    volatile uint32_t HcHCCA;
    volatile uint32_t HcPeriodCurrentED;
    volatile uint32_t HcControlHeadED;
    volatile uint32_t HcControlCurrentED;
    volatile uint32_t HcBulkHeadED;
    volatile uint32_t HcBulkCurrentED;
    volatile uint32_t HcDoneHead;
    volatile uint32_t HcFmInterval;
    volatile const uint32_t HcFmRemaining;
    volatile const uint32_t HcFmNumber;
    volatile uint32_t HcPeriodicStart;
    volatile uint32_t HcLSThreshold;
    volatile uint32_t HcRhDescriptorA;
    volatile uint32_t HcRhDescriptorB;
    volatile uint32_t HcRhStatus;
    volatile uint32_t HcRhPortStatus[6];
    volatile const uint32_t RESERVE0[101];
    volatile uint32_t HcPhyControl;
    volatile uint32_t HcMiscControl;

} USBH_T;
# 164 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\uspi_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\uspi_reg.h"
typedef struct
{
# 425 "../../../../Library/Device/Nuvoton/M3351/Include\\uspi_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t INTEN;
    volatile uint32_t BRGEN;

    volatile const uint32_t RESERVE0[1];

    volatile uint32_t DATIN0;

    volatile const uint32_t RESERVE1[3];

    volatile uint32_t CTLIN0;

    volatile const uint32_t RESERVE2[1];

    volatile uint32_t CLKIN;
    volatile uint32_t LINECTL;
    volatile uint32_t TXDAT;
    volatile const uint32_t RXDAT;
    volatile uint32_t BUFCTL;
    volatile uint32_t BUFSTS;
    volatile uint32_t PDMACTL;

    volatile const uint32_t RESERVE3[4];

    volatile uint32_t WKCTL;
    volatile uint32_t WKSTS;
    volatile uint32_t PROTCTL;
    volatile uint32_t PROTIEN;
    volatile uint32_t PROTSTS;

} USPI_T;
# 165 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\uuart_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\uuart_reg.h"
typedef struct
{
# 438 "../../../../Library/Device/Nuvoton/M3351/Include\\uuart_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t INTEN;
    volatile uint32_t BRGEN;
    volatile const uint32_t RESERVE0[1];
    volatile uint32_t DATIN0;
    volatile const uint32_t RESERVE1[3];
    volatile uint32_t CTLIN0;
    volatile const uint32_t RESERVE2[1];
    volatile uint32_t CLKIN;
    volatile uint32_t LINECTL;
    volatile uint32_t TXDAT;
    volatile const uint32_t RXDAT;
    volatile uint32_t BUFCTL;
    volatile uint32_t BUFSTS;
    volatile uint32_t PDMACTL;
    volatile const uint32_t RESERVE3[4];
    volatile uint32_t WKCTL;
    volatile uint32_t WKSTS;
    volatile uint32_t PROTCTL;
    volatile uint32_t PROTIEN;
    volatile uint32_t PROTSTS;

} UUART_T;
# 166 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\wdt_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\wdt_reg.h"
typedef struct
{
# 137 "../../../../Library/Device/Nuvoton/M3351/Include\\wdt_reg.h"
    volatile uint32_t CTL;
    volatile uint32_t ALTCTL;
    volatile uint32_t RSTCNT;
    volatile uint32_t STATUS;

} WDT_T;
# 167 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/Device/Nuvoton/M3351/Include\\wwdt_reg.h" 1
# 28 "../../../../Library/Device/Nuvoton/M3351/Include\\wwdt_reg.h"
typedef struct
{
# 101 "../../../../Library/Device/Nuvoton/M3351/Include\\wwdt_reg.h"
    volatile uint32_t RLDCNT;
    volatile uint32_t CTL;
    volatile uint32_t STATUS;
    volatile const uint32_t CNT;

} WWDT_T;
# 168 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 877 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
#pragma clang diagnostic pop
# 898 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
typedef volatile uint8_t vu8;
typedef volatile uint16_t vu16;
typedef volatile uint32_t vu32;
typedef volatile uint64_t vu64;
# 1099 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h"
# 1 "../../../../Library/StdDriver/inc\\acmp.h" 1
# 79 "../../../../Library/StdDriver/inc\\acmp.h"
extern int32_t g_ACMP_i32ErrCode;
# 429 "../../../../Library/StdDriver/inc\\acmp.h"
void ACMP_Open(ACMP_T *acmp, uint32_t u32ChNum, uint32_t u32NegSrc, uint32_t u32HysSel);
void ACMP_Close(ACMP_T *acmp, uint32_t u32ChNum);
void ACMP_Calibration(ACMP_T *acmp);
# 1100 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\bpwm.h" 1
# 330 "../../../../Library/StdDriver/inc\\bpwm.h"
uint32_t BPWM_ConfigCaptureChannel(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32UnitTimeNsec, uint32_t u32CaptureEdge);
uint32_t BPWM_ConfigOutputChannel(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Frequency, uint32_t u32DutyCycle);
void BPWM_Start(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_Stop(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_ForceStop(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_EnableADCTrigger(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Condition);
void BPWM_DisableADCTrigger(BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_ClearADCTriggerFlag(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Condition);
uint32_t BPWM_GetADCTriggerFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_EnableCapture(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_DisableCapture(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_EnableOutput(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_DisableOutput(BPWM_T *bpwm, uint32_t u32ChannelMask);
void BPWM_EnableCaptureInt(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Edge);
void BPWM_DisableCaptureInt(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Edge);
void BPWM_ClearCaptureIntFlag(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32Edge);
uint32_t BPWM_GetCaptureIntFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_EnableDutyInt(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32IntDutyType);
void BPWM_DisableDutyInt(BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_ClearDutyIntFlag(BPWM_T *bpwm, uint32_t u32ChannelNum);
uint32_t BPWM_GetDutyIntFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_EnablePeriodInt(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32IntPeriodType);
void BPWM_DisablePeriodInt(BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_ClearPeriodIntFlag(BPWM_T *bpwm, uint32_t u32ChannelNum);
uint32_t BPWM_GetPeriodIntFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_EnableZeroInt(BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_DisableZeroInt(BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_ClearZeroIntFlag(BPWM_T *bpwm, uint32_t u32ChannelNum);
uint32_t BPWM_GetZeroIntFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_EnableLoadMode(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32LoadMode);
void BPWM_DisableLoadMode(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32LoadMode);
void BPWM_SetClockSource(BPWM_T *bpwm, uint32_t u32ChannelNum, uint32_t u32ClkSrcSel);
uint32_t BPWM_GetWrapAroundFlag(const BPWM_T *bpwm, uint32_t u32ChannelNum);
void BPWM_ClearWrapAroundFlag(BPWM_T *bpwm, uint32_t u32ChannelNum);
# 1101 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\cache.h" 1
# 49 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_Enable(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (0));
    __builtin_arm_isb(0xF);
}
# 63 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_Disable(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL &= ~(0x1UL << (0));
    __builtin_arm_isb(0xF);
}
# 77 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint8_t CACHE_IsBusy(void)
{
    return (((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->STS & (0x1UL << (0))) ? 1 : 0;
}
# 89 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_EnableHitMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (8));
    __builtin_arm_isb(0xF);
}
# 103 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_DisableHitMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL &= ~(0x1UL << (8));
    __builtin_arm_isb(0xF);
}
# 117 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_EnableMissMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (9));
    __builtin_arm_isb(0xF);
}
# 131 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_DisableMissMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL &= ~(0x1UL << (9));
    __builtin_arm_isb(0xF);
}
# 145 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_ResetHitMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (10));
    __builtin_arm_isb(0xF);
}
# 159 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_ResetMissMonitor(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (11));
    __builtin_arm_isb(0xF);
}
# 173 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint32_t CACHE_GetHitCount(void)
{
    return ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->HIT;
}
# 185 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint32_t CACHE_GetMissCount(void)
{
    return ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->MISS;
}
# 198 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_Flush(void)
{

    if ((((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL & (0x1UL << (0))) == 0U)
    {

        return;
    }


    CACHE_Disable();


    while (CACHE_IsBusy())
    {

    }


    CACHE_Enable();
}
# 227 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_EnableParityCheck(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (24));
    __builtin_arm_isb(0xF);
}
# 241 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_DisableParityCheck(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL &= ~(0x1UL << (24));
    __builtin_arm_isb(0xF);
}
# 255 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_EnableParityCheckInt(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL |= (0x1UL << (16));
    __builtin_arm_isb(0xF);
}
# 269 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_DisableParityCheckInt(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL &= ~(0x1UL << (16));
    __builtin_arm_isb(0xF);
}
# 285 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_SetParityErrorAction(uint32_t u32ParityErrorAction)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL = ((((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL & ~(0x1UL << (25))) | u32ParityErrorAction);
    __builtin_arm_isb(0xF);
}
# 300 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint32_t CACHE_GetParityErrorAction(void)
{
    return (((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->CTL & (0x1UL << (25)));
}
# 312 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint32_t CACHE_GetParityErrorStatus(void)
{
    return ((((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->STS & (0x1UL << (16))) >> (16));
}
# 324 "../../../../Library/StdDriver/inc\\cache.h"
static inline void CACHE_ClrParityErrorStatus(void)
{
    __builtin_arm_dsb(0xF);
    ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->STS = (0x1UL << (16));
    __builtin_arm_isb(0xF);
}
# 338 "../../../../Library/StdDriver/inc\\cache.h"
static inline uint32_t CACHE_GetParityErrorAddr(void)
{
    return ((CACHE_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x36000UL))->ERRADDR;
}
# 1102 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\canfd.h" 1
# 105 "../../../../Library/StdDriver/inc\\canfd.h"
typedef enum
{
    eCANFD_BYTE8 = 0,
    eCANFD_BYTE12 = 1,
    eCANFD_BYTE16 = 2,
    eCANFD_BYTE20 = 3,
    eCANFD_BYTE24 = 4,
    eCANFD_BYTE32 = 5,
    eCANFD_BYTE48 = 6,
    eCANFD_BYTE64 = 7
} E_CANFD_DATA_FIELD_SIZE;


typedef enum
{
    eCANFD_QUEUE_MODE = 0,
    eCANFD_FIFO_MODE = 1
} E_CANFD_TX_MODE;


typedef struct
{
    E_CANFD_DATA_FIELD_SIZE eDataFieldSize;
    E_CANFD_TX_MODE eModeSel;
    uint32_t u32ElemCnt;
    uint32_t u32DBufNumber;
} CANFD_TX_BUF_CONFIG_T;



typedef struct
{
    uint32_t u32BitRate;
    uint16_t u16TDCOffset;
    uint16_t u16TDCFltrWin;
    uint8_t u8TDC;
} CANFD_NBT_CONFIG_T;



typedef struct
{
    uint32_t u32BitRate;
    uint16_t u16TDCOffset;
    uint16_t u16TDCFltrWin;
    uint8_t u8TDC;
} CANFD_DBT_CONFIG_T;


typedef struct
{
    uint8_t u8PreDivider;
    uint16_t u16NominalPrescaler;
    uint8_t u8NominalRJumpwidth;
    uint8_t u8NominalPhaseSeg1;
    uint8_t u8NominalPhaseSeg2;
    uint8_t u8NominalPropSeg;
    uint8_t u8DataPrescaler;
    uint8_t u8DataRJumpwidth;
    uint8_t u8DataPhaseSeg1;
    uint8_t u8DataPhaseSeg2;
    uint8_t u8DataPropSeg;

} CANFD_TIMEING_CONFIG_T;


typedef struct
{
    CANFD_NBT_CONFIG_T sNormBitRate;
    CANFD_DBT_CONFIG_T sDataBitRate;
    CANFD_TIMEING_CONFIG_T sConfigBitTing;
    uint8_t bFDEn;
    uint8_t bBitRateSwitch;
    uint8_t bEnableLoopBack;
} CANFD_FD_BT_CONFIG_T;


typedef struct
{
    uint32_t u32SIDFC_FLSSA;
    uint32_t u32XIDFC_FLESA;
    uint32_t u32RXF0C_F0SA;
    uint32_t u32RXF1C_F1SA;
    uint32_t u32RXBC_RBSA;
    uint32_t u32TXEFC_EFSA;
    uint32_t u32TXBC_TBSA;
} CANFD_RAM_PART_T;


typedef struct
{
    uint32_t u32SIDFC;
    uint32_t u32XIDFC;
    uint32_t u32RxFifo0;
    uint32_t u32RxFifo1;
    uint32_t u32RxBuf;
    uint32_t u32TxBuf;
    uint32_t u32TxFifoQueue;
    uint32_t u32TxEventFifo;
    uint32_t u32UserDef;
} CANFD_ELEM_SIZE_T;


typedef struct
{
    CANFD_FD_BT_CONFIG_T sBtConfig;
    CANFD_RAM_PART_T sMRamStartAddr;
    CANFD_ELEM_SIZE_T sElemSize;
    CANFD_TX_BUF_CONFIG_T sTxConfig;
    uint32_t u32MRamSize;
} CANFD_FD_T;


typedef enum
{
    eCANFD_SID = 0,
    eCANFD_XID = 1
} E_CANFD_ID_TYPE;


typedef enum
{
    eCANFD_RX_FIFO_0 = 0,
    eCANFD_RX_FIFO_1 = 1,
    eCANFD_RX_DBUF = 2
} E_CANFD_RX_BUF_TYPE;


typedef enum
{
    eCANFD_SYNC = 0,
    eCANFD_IDLE = 1,
    eCANFD_RECEIVER = 2,
    eCANFD_TRANSMITTER = 3
} E_CANFD_COMMUNICATION_STATE;



typedef enum
{
    eCANFD_TRANSMIT_FAIL = 0,
    eCANFD_TRANSMIT_SUCCESS = 1,
    eCANFD_TRANSMIT_TIMEOUT = 2
} E_CANFD_TRANSMIT_STATE;


typedef enum
{
    eCANFD_RECEIVE_EMPTY = 0,
    eCANFD_RECEIVE_SUCCESS = 1,
    eCANFD_RECEIVE_SUCCESS_AND_BUFFER_FULL = 2

} E_CANFD_RECEIVE_STATE;



typedef struct
{
    E_CANFD_RX_BUF_TYPE eRxBuf;
    uint32_t u32BufIdx;
} CANFD_RX_INFO_T;


typedef enum
{
    eCANFD_DATA_FRM = 0,
    eCANFD_REMOTE_FRM = 1
} E_CANFD_FRM_TYPE;


typedef struct
{
    E_CANFD_ID_TYPE eIdType;
    CANFD_RX_INFO_T sRxInfo;
    E_CANFD_FRM_TYPE eFrmType;
    uint32_t u32Id;
    uint32_t u32DLC;
    union
    {
        uint32_t au32Data[(64 / 4)];
        uint8_t au8Data[64];
    };
    uint8_t u8MsgMarker;
    uint16_t u16RxTimestamp;
    uint8_t u8RxTimestampPointer;
    uint8_t bTimestampCaptured;
    uint8_t u8FilterIndex;
    uint8_t bNonMatchingFrame;
    uint8_t bFDFormat;
    uint8_t bBitRateSwitch;
    uint8_t bErrStaInd;
    uint8_t bEvntFifoCon;
} CANFD_FD_MSG_T;


typedef struct
{
    uint32_t u32Id;
    uint32_t u32Config;
    union
    {
        uint32_t au32Data[(64 / 4)];
        uint8_t au8Data[64];
    };
} CANFD_BUF_T;


typedef struct
{
    union
    {
        struct
        {
            uint32_t SFID2 : 11;
            uint32_t reserved1 : 5;
            uint32_t SFID1 : 11;
            uint32_t SFEC : 3;
            uint32_t SFT : 2;
        };
        struct
        {
            uint32_t VALUE;
        };
    };
} CANFD_STD_FILTER_T;


typedef struct
{
    union
    {
        struct
        {
            uint32_t EFID1 : 29;
            uint32_t EFEC : 3;
            uint32_t EFID2 : 29;
            uint32_t reserved1 : 1;
            uint32_t EFT : 2;
        };
        struct
        {
            uint32_t LOWVALUE;
            uint32_t HIGHVALUE;
        };
    };
} CANFD_EXT_FILTER_T;


typedef enum
{
    eCANFD_ACC_NON_MATCH_FRM_RX_FIFO0 = 0x0,
    eCANFD_ACC_NON_MATCH_FRM_RX_FIFO1 = 0x1,
    eCANFD_REJ_NON_MATCH_FRM = 0x3
} E_CANFD_ACC_NON_MATCH_FRM;



typedef enum
{
    eCANFD_SID_FLTR_TYPE_RANGE = 0x0,
    eCANFD_SID_FLTR_TYPE_DUAL = 0x1,
    eCANFD_SID_FLTR_TYPE_CLASSIC = 0x2,
    eCANFD_SID_FLTR_TYPE_DIS = 0x3
} E_CANFD_SID_FLTR_ELEM_TYPE;


typedef enum
{
    eCANFD_XID_FLTR_TYPE_RANGE = 0x0,
    eCANFD_XID_FLTR_TYPE_DUAL = 0x1,
    eCANFD_XID_FLTR_TYPE_CLASSIC = 0x2,
    eCANFD_XID_FLTR_TYPE_RANGE_XIDAM_NOT_APP = 0x3
} E_CANFD_XID_FLTR_ELEM_TYPE;


typedef enum
{
    eCANFD_FLTR_ELEM_DIS = 0x0,
    eCANFD_FLTR_ELEM_STO_FIFO0 = 0x1,
    eCANFD_FLTR_ELEM_STO_FIFO1 = 0x2,
    eCANFD_FLTR_ELEM_REJ_ID = 0x3,
    eCANFD_FLTR_ELEM_SET_PRI = 0x4,
    eCANFD_FLTR_ELEM_SET_PRI_STO_FIFO0 = 0x5,
    eCANFD_FLTR_ELEM_SET_PRI_STO_FIFO1 = 0x6,
    eCANFD_FLTR_ELEM_STO_RX_BUF_OR_DBG_MSG = 0x7
} E_CANFD_FLTR_CONFIG;


typedef struct
{
    E_CANFD_ID_TYPE eIdType;
    uint32_t u32Id;
    uint32_t u32DLC;
    uint32_t u32TxTs;
    uint32_t u32MsgMarker;
    uint8_t bErrStaInd;
    uint8_t bRemote;
    uint8_t bFDFormat;
    uint8_t bBitRateSwitch;
} CANFD_TX_EVNT_ELEM_T;


void CANFD_Open(CANFD_T *psCanfd, CANFD_FD_T *psCanfdStr);
void CANFD_Close(const CANFD_T *psCanfd);
void CANFD_EnableInt(CANFD_T *psCanfd, uint32_t u32IntLine0, uint32_t u32IntLine1, uint32_t u32TXBTIE, uint32_t u32TXBCIE);
void CANFD_DisableInt(CANFD_T *psCanfd, uint32_t u32IntLine0, uint32_t u32IntLine1, uint32_t u32TXBTIE, uint32_t u32TXBCIE);
uint32_t CANFD_TransmitTxMsg(CANFD_T *psCanfd, uint32_t u32TxBufIdx, CANFD_FD_MSG_T *psTxMsg);
uint32_t CANFD_TransmitDMsg(CANFD_T *psCanfd, uint32_t u32TxBufIdx, CANFD_FD_MSG_T *psTxMsg);
void CANFD_SetGFC(CANFD_T *psCanfd, E_CANFD_ACC_NON_MATCH_FRM eNMStdFrm, E_CANFD_ACC_NON_MATCH_FRM eEMExtFrm, uint32_t u32RejRmtStdFrm, uint32_t u32RejRmtExtFrm);
void CANFD_SetSIDFltr(const CANFD_T *psCanfd, uint32_t u32FltrIdx, uint32_t u32Filter);
void CANFD_SetXIDFltr(const CANFD_T *psCanfd, uint32_t u32FltrIdx, uint32_t u32FilterLow, uint32_t u32FilterHigh);
uint32_t CANFD_ReadRxBufMsg(CANFD_T *psCanfd, uint8_t u8MbIdx, CANFD_FD_MSG_T *psMsgBuf);
uint32_t CANFD_ReadRxFifoMsg(CANFD_T *psCanfd, uint8_t u8FifoIdx, CANFD_FD_MSG_T *psMsgBuf);
void CANFD_CopyDBufToMsgBuf(const CANFD_T *psCanfd, CANFD_BUF_T *psRxBuf, CANFD_FD_MSG_T *psMsgBuf);
void CANFD_CopyRxFifoToMsgBuf(const CANFD_T *psCanfd, CANFD_BUF_T *psRxBuf, CANFD_FD_MSG_T *psMsgBuf);
uint32_t CANFD_GetRxFifoWaterLvl(const CANFD_T *psCanfd, uint32_t u32RxFifoNum);
uint32_t CANFD_ReadTxFifoEventMsg(CANFD_T *psCanfd, uint8_t u8MbIdx, CANFD_TX_EVNT_ELEM_T *psEventFifoMsgBuf);
void CANFD_TxBufCancelReq(CANFD_T *psCanfd, uint32_t u32TxBufIdx);
uint32_t CANFD_IsTxBufCancelFin(const CANFD_T *psCanfd, uint32_t u32TxBufIdx);
uint32_t CANFD_IsTxBufTransmitOccur(const CANFD_T *psCanfd, uint32_t u32TxBufIdx);
uint32_t CANFD_GetTxEvntFifoWaterLvl(const CANFD_T *psCanfd);
void CANFD_CopyTxEvntFifoToUsrBuf(const CANFD_T *psCanfd, uint32_t u32TxEvntNum, CANFD_TX_EVNT_ELEM_T *psTxEvntElem);
void CANFD_GetBusErrCount(const CANFD_T *psCanfd, uint8_t *pu8TxErrBuf, uint8_t *pu8RxErrBuf);
void CANFD_RunToNormal(CANFD_T *psCanfd, uint8_t u8Enable);
void CANFD_GetDefaultConfig(CANFD_FD_T *psConfig, uint8_t u8OpMode);
void CANFD_ClearStatusFlag(CANFD_T *psCanfd, uint32_t u32InterruptFlag);
uint32_t CANFD_GetStatusFlag(const CANFD_T *psCanfd, uint32_t u32IntTypeFlag);
void CANFD_InitRxFifo(CANFD_T *psCanfd, uint32_t u32RxFifoNum, CANFD_RAM_PART_T *psRamConfig, const CANFD_ELEM_SIZE_T *psElemSize, uint32_t u32FifoWM, E_CANFD_DATA_FIELD_SIZE eFifoSize);
void CANFD_InitRxDBuf(CANFD_T *psCanfd, const CANFD_RAM_PART_T *psRamConfig, const CANFD_ELEM_SIZE_T *psElemSize, E_CANFD_DATA_FIELD_SIZE eRxBufSize);
void CANFD_InitTxDBuf(CANFD_T *psCanfd, const CANFD_RAM_PART_T *psRamConfig, CANFD_ELEM_SIZE_T *psElemSize, E_CANFD_DATA_FIELD_SIZE eTxBufSize);
void CANFD_InitTxEvntFifo(CANFD_T *psCanfd, const CANFD_RAM_PART_T *psRamConfig, const CANFD_ELEM_SIZE_T *psElemSize, uint32_t u32FifoWaterLvl);
void CANFD_ConfigSIDFC(CANFD_T *psCanfd, CANFD_RAM_PART_T *psRamConfig, const CANFD_ELEM_SIZE_T *psElemSize);
void CANFD_ConfigXIDFC(CANFD_T *psCanfd, CANFD_RAM_PART_T *psRamConfig, const CANFD_ELEM_SIZE_T *psElemSize);
uint32_t CANFD_GetNominalBitRate(const CANFD_T *psCanfd);
uint32_t CANFD_GetDataBitRate(const CANFD_T *psCanfd);
# 1103 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\clk.h" 1
# 856 "../../../../Library/StdDriver/inc\\clk.h"
void CLK_DisableCKO(void);
void CLK_EnableCKO(uint32_t u32ClkSrc, uint32_t u32ClkDiv, uint32_t u32ClkDivBy1En);
void CLK_PowerDown(void);
void CLK_Idle(void);
                       uint32_t CLK_GetHXTFreq(void);
                       uint32_t CLK_GetLXTFreq(void);
                       uint32_t CLK_GetHCLKFreq(void);
                       uint32_t CLK_GetPCLK0Freq(void);
                       uint32_t CLK_GetPCLK1Freq(void);
                       uint32_t CLK_GetCPUFreq(void);
uint32_t CLK_SetCoreClock(uint32_t u32Hclk);
void CLK_SetHCLK(uint32_t u32ClkSrc, uint32_t u32ClkDiv);
void CLK_SetModuleClock(uint32_t u32ModuleIdx, uint32_t u32ClkSrc, uint32_t u32ClkDiv);
void CLK_SetSysTickClockSrc(uint32_t u32ClkSrc);
void CLK_EnableXtalRC(uint32_t u32ClkMask);
void CLK_DisableXtalRC(uint32_t u32ClkMask);
void CLK_EnableModuleClock(uint32_t u32ModuleIdx);
void CLK_DisableModuleClock(uint32_t u32ModuleIdx);
uint32_t CLK_EnablePLL(uint32_t u32PllClkSrc, uint32_t u32PllFreq);
void CLK_DisablePLL(void);
uint32_t CLK_WaitClockReady(uint32_t u32ClkMask);
void CLK_EnableSysTick(uint32_t u32ClkSrc, uint32_t u32Count);
void CLK_DisableSysTick(void);
void CLK_SetPowerDownMode(uint32_t u32PDMode);
uint32_t CLK_GetPMUWKSrc(void);
void CLK_EnableSPDWKPin(uint32_t u32Port, uint32_t u32Pin, uint32_t u32TriggerType, uint32_t u32DebounceEn);
void CLK_SysTickDelay(uint32_t us);
void CLK_SysTickLongDelay(uint32_t us);
                       uint32_t CLK_GetPLLClockFreq(void);
                       uint32_t CLK_GetModuleClockSource(uint32_t u32ModuleIdx);
                       uint32_t CLK_GetModuleClockDivider(uint32_t u32ModuleIdx);
# 1104 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\crc.h" 1
# 236 "../../../../Library/StdDriver/inc\\crc.h"
void CRC_Open(uint32_t u32Mode, uint32_t u32Attribute, uint32_t u32Seed, uint32_t u32DataLen);
uint32_t CRC_GetChecksum(void);
# 1105 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\crypto.h" 1
# 214 "../../../../Library/StdDriver/inc\\crypto.h"
void PRNG_Open(CRYPTO_T *crypto, uint32_t u32KeySize, uint32_t u32SeedReload, uint32_t u32Seed);
void PRNG_Start(CRYPTO_T *crypto);
void PRNG_Read(CRYPTO_T *crypto, uint32_t u32RandKey[]);

void AES_Open(CRYPTO_T *crypto, uint32_t u32Channel, uint32_t u32EncDec, uint32_t u32OpMode, uint32_t u32KeySize, uint32_t u32SwapType);
void AES_Start(CRYPTO_T *crypto, uint32_t u32Channel, uint32_t u32DMAMode);
void AES_SetKey(CRYPTO_T *crypto, uint32_t u32Channel, const uint32_t au32Keys[], uint32_t u32KeySize);
void AES_SetInitVect(CRYPTO_T *crypto, uint32_t u32Channel, const uint32_t au32IV[]);
void AES_SetDMATransfer(CRYPTO_T *crypto, uint32_t u32Channel, uint32_t u32SrcAddr, uint32_t u32DstAddr, uint32_t u32TransCnt);

void SHA_Open(CRYPTO_T *crypto, uint32_t u32OpMode, uint32_t u32SwapType, uint32_t hmac_key_len);
void SHA_Start(CRYPTO_T *crypto, uint32_t u32DMAMode);
void SHA_SetDMATransfer(CRYPTO_T *crypto, uint32_t u32SrcAddr, uint32_t u32TransCnt);
void SHA_Read(CRYPTO_T *crypto, uint32_t u32Digest[]);


void Hex2Reg(char input[], uint32_t volatile reg[]);
void Reg2Hex(int32_t count, uint32_t volatile reg[], char output[]);
void Hex2RegEx(char input[], uint32_t volatile reg[], int shift);
# 1106 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\dac.h" 1
# 236 "../../../../Library/StdDriver/inc\\dac.h"
void DAC_Open(DAC_T *dac, uint32_t u32Ch, uint32_t u32TrgSrc);
void DAC_Close(DAC_T *dac, uint32_t u32Ch);
uint32_t DAC_SetDelayTime(DAC_T *dac, uint32_t u32Delay);
# 1107 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\dfmc.h" 1
# 281 "../../../../Library/StdDriver/inc\\dfmc.h"
extern int32_t g_DFMC_i32ErrCode;
# 296 "../../../../Library/StdDriver/inc\\dfmc.h"
static inline uint32_t DFMC_ReadCID(void)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_DFMC_i32ErrCode = ( 0L);
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPCMD = 0x0BUL;
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPADDR = 0x0U;
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPTRG = (0x1UL << (0));





    while (i32TimeOutCnt-- > 0)
    {
        if ((((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPTRG & (0x1UL << (0))) == 0U)
            return ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPDAT;
    }

    g_DFMC_i32ErrCode = (-2L);
    return 0xFFFFFFFFU;
}
# 328 "../../../../Library/StdDriver/inc\\dfmc.h"
static inline uint32_t DFMC_ReadPID(void)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_DFMC_i32ErrCode = ( 0L);
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPCMD = 0x0CUL;
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPADDR = 0x04U;
    ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPTRG = (0x1UL << (0));





    while (i32TimeOutCnt-- > 0)
    {
        if ((((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPTRG & (0x1UL << (0))) == 0U)
            return ((DFMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0F000UL))->ISPDAT;
    }

    g_DFMC_i32ErrCode = (-2L);
    return 0xFFFFFFFFU;
}




void DFMC_Open(void);
void DFMC_Close(void);
int32_t DFMC_Erase(uint32_t u32PageAddr);
void DFMC_Erase_NonBlocking(uint32_t u32PageAddr);

int32_t DFMC_Mass_Erase(void);
void DFMC_Mass_Erase_NonBlocking(void);
uint32_t DFMC_Read(uint32_t u32Addr);
uint32_t DFMC_Read_ECC(uint32_t u32Addr, int32_t *pi32ErrBit);

int32_t DFMC_Write(uint32_t u32Addr, uint32_t u32Data);
void DFMC_Write_NonBlocking(uint32_t u32Addr, uint32_t u32Data);

uint32_t DFMC_GetChkSum(uint32_t u32Addr, uint32_t u32Count);
uint32_t DFMC_CheckAllOne(uint32_t u32Addr, uint32_t u32Count);

int32_t DFMC_EEPROM_Init(void);
uint32_t DFMC_EEPROM_Read(uint32_t u32Addr);
int32_t DFMC_EEPROM_Write(uint32_t u32Addr, uint32_t u32Data);
int32_t DFMC_EEPROM_WriteByte(uint32_t u32Addr, uint8_t u8Data);
# 1108 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\eadc.h" 1
# 295 "../../../../Library/StdDriver/inc\\eadc.h"
static inline uint32_t EADC_GET_CONV_DATA(EADC_T *eadc, uint32_t u32ModuleNum)
{
    uint32_t adc_result_mask;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_result_mask = (0xfffful << (0));
    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_result_mask = (0x3fffful << (0));
    }
    else
    {
        adc_result_mask = 0xfffUL;
    }

    return (((u32ModuleNum) < 19UL) ? ((eadc)->DAT[(u32ModuleNum)] & adc_result_mask) : ((eadc)->DAT19[(u32ModuleNum) - 19UL] & adc_result_mask));
}
# 324 "../../../../Library/StdDriver/inc\\eadc.h"
static inline uint32_t EADC_GET_DATA_VALID_FLAG(const EADC_T *eadc, uint32_t u32ModuleMask)
{
    uint32_t u32VALID = 0;

    u32VALID = (eadc->STATUS0 & (0xfffful << (0)));
    u32VALID |= ((eadc->STATUS1 & (0x7fful << (0))) << 16UL);

    return (u32VALID & u32ModuleMask);
}
# 343 "../../../../Library/StdDriver/inc\\eadc.h"
static inline uint32_t EADC_GET_DATA_OVERRUN_FLAG(const EADC_T *eadc, uint32_t u32ModuleMask)
{
    uint32_t u32OVFlag = 0;

    u32OVFlag = ((eadc->STATUS0 & (0xfffful << (16))) >> (16));
    u32OVFlag |= (eadc->STATUS1 & (0x7fful << (16)));

    return (u32OVFlag & u32ModuleMask);
}
# 361 "../../../../Library/StdDriver/inc\\eadc.h"
static inline uint32_t EADC_GET_DOUBLE_DATA(EADC_T *eadc, uint32_t u32ModuleNum)
{
    uint32_t adc_result_mask;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_result_mask = (0xfffful << (0));
    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_result_mask = (0x3fffful << (0));
    }
    else
    {
        adc_result_mask = 0xfffUL;
    }

    return ((eadc)->DDAT[(u32ModuleNum)] & adc_result_mask);
}
# 491 "../../../../Library/StdDriver/inc\\eadc.h"
static inline void EADC_ENABLE_CMP0(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32Condition, uint32_t u16CMPData, uint32_t u32MatchCount)
{
    uint32_t adc_cmpdat_msk;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_cmpdat_msk = (0xfffful << (12));

    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_cmpdat_msk = (0x3fffful << (12));
    }
    else
    {
        adc_cmpdat_msk = 0xfffUL;
    }

    ((eadc)->CMP[0] = (((eadc)->CMP[0] & ~((0x1ful << (3)) | (0x1ul << (2)) | adc_cmpdat_msk | (0xful << (8)))) | (((u32ModuleNum) << (3)) | (u32Condition) | ((u16CMPData) << (12)) | (((u32MatchCount) - 1UL) << (8)) | (0x1ul << (0)))));





}
# 533 "../../../../Library/StdDriver/inc\\eadc.h"
static inline void EADC_ENABLE_CMP1(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32Condition, uint32_t u16CMPData, uint32_t u32MatchCount)
{
    uint32_t adc_cmpdat_msk;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_cmpdat_msk = (0xfffful << (12));
    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_cmpdat_msk = (0x3fffful << (12));
    }
    else
    {
        adc_cmpdat_msk = 0xfffUL;
    }

    ((eadc)->CMP[1] = (((eadc)->CMP[1] & ~((0x1ful << (3)) | (0x1ul << (2)) | adc_cmpdat_msk | (0xful << (8)))) | (((u32ModuleNum) << (3)) | (u32Condition) | ((u16CMPData) << (12)) | (((u32MatchCount) - 1UL) << (8)) | (0x1ul << (0)))));





}
# 573 "../../../../Library/StdDriver/inc\\eadc.h"
static inline void EADC_ENABLE_CMP2(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32Condition, uint32_t u16CMPData, uint32_t u32MatchCount)
{
    uint32_t adc_cmpdat_msk;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_cmpdat_msk = (0xfffful << (12));
    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_cmpdat_msk = (0x3fffful << (12));
    }
    else
    {
        adc_cmpdat_msk = 0xfffUL;
    }

    ((eadc)->CMP[2] = (((eadc)->CMP[2] & ~((0x1ful << (3)) | (0x1ul << (2)) | adc_cmpdat_msk | (0xful << (8)))) | (((u32ModuleNum) << (3)) | (u32Condition) | ((u16CMPData) << (12)) | (((u32MatchCount) - 1UL) << (8)) | (0x1ul << (0)))));





}
# 613 "../../../../Library/StdDriver/inc\\eadc.h"
static inline void EADC_ENABLE_CMP3(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32Condition, uint32_t u16CMPData, uint32_t u32MatchCount)
{
    uint32_t adc_cmpdat_msk;

    if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x03000UL)))
    {
        adc_cmpdat_msk = (0xfffful << (12));
    }
    else if (eadc == ((EADC_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x0B000UL)))
    {
        adc_cmpdat_msk = (0x3fffful << (12));
    }
    else
    {
        adc_cmpdat_msk = 0xfffUL;
    }

    ((eadc)->CMP[3] = (((eadc)->CMP[3] & ~((0x1ful << (3)) | (0x1ul << (2)) | adc_cmpdat_msk | (0xful << (8)))) | (((u32ModuleNum) << (3)) | (u32Condition) | ((u16CMPData) << (12)) | (((u32MatchCount) - 1UL) << (8)) | (0x1ul << (0)))));





}
# 798 "../../../../Library/StdDriver/inc\\eadc.h"
void EADC_Open(EADC_T *eadc, uint32_t u32InputMode);
int32_t EADC_Calibration(EADC_T *eadc);
void EADC_Close(EADC_T *eadc);
void EADC_ConfigSampleModule(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32TriggerSrc, uint32_t u32Channel);
void EADC_SetTriggerDelayTime(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32TriggerDelayTime, uint32_t u32DelayClockDivider);
void EADC_SetExtendSampleTime(EADC_T *eadc, uint32_t u32ModuleNum, uint32_t u32ExtendSampleTime);
void EADC_SetVRef(EADC_T *eadc, uint32_t u32VRefCTL);
# 1109 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\ebi.h" 1
# 337 "../../../../Library/StdDriver/inc\\ebi.h"
void EBI_Open(uint32_t u32Bank, uint32_t u32DataWidth, uint32_t u32TimingClass, uint32_t u32BusMode, uint32_t u32CSActiveLevel);
void EBI_Close(uint32_t u32Bank);
void EBI_SetBusTiming(uint32_t u32Bank, uint32_t u32TimingConfig, uint32_t u32MclkDiv);
# 1110 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\ecap.h" 1
# 517 "../../../../Library/StdDriver/inc\\ecap.h"
void ECAP_Open(ECAP_T *ecap, uint32_t u32FuncMask);
void ECAP_Close(ECAP_T *ecap);
void ECAP_EnableINT(ECAP_T *ecap, uint32_t u32Mask);
void ECAP_DisableINT(ECAP_T *ecap, uint32_t u32Mask);
# 1111 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\ellsi.h" 1
# 28 "../../../../Library/StdDriver/inc\\ellsi.h"
typedef struct
{
    uint32_t u32BusClock;
    uint32_t u32TransferTimeNsec;
    uint32_t u32T0HTimeNsec;
    uint32_t u32T1HTimeNsec;
    uint32_t u32ResetTimeNsec;
    uint32_t u32EnterHTimeNsec;
    uint32_t u32EnterLTimeNsec;
    uint32_t u32GetHTimeNsec;
    uint32_t u32GetHTolTimeNsec;
    uint32_t u32CmdTimeoutTimeNsec;
    uint32_t u32FBH0TimeNsec;
    uint32_t u32FBL0TimeNsec;
    uint32_t u32FBH1TimeNsec;
    uint32_t u32FBL1TimeNsec;
    uint32_t u32FBCNT0TimeNsec;
    uint32_t u32FBCNT0TolTimeNsec;
    uint32_t u32FBCNT1TimeNsec;
    uint32_t u32FBCNT1TolTimeNsec;
    uint32_t u32FBID0TimeNsec;
    uint32_t u32FBID0TolTimeNsec;
    uint32_t u32FBID1TimeNsec;
    uint32_t u32FBID1TolTimeNsec;
    uint32_t u32TH20TimeNsec;
    uint32_t u32WKPULSETimeNsec;
    uint32_t u32WKWPERTimeNsec;
} S_ELLSI_TIME_INFO_T;

typedef struct
{
    uint32_t u32ELLSIMode;
    uint32_t u32OutputFormat;
    S_ELLSI_TIME_INFO_T sTimeInfo;
    uint32_t u32PCNT;
    uint32_t u32IDOS;
} S_ELLSI_CONFIG_T;

typedef struct
{
    uint8_t BledDimming : 5;
    uint8_t reserved0 : 1;
    uint8_t SS0 : 1;
    uint8_t SS1 : 1;
    uint8_t RledDimming : 5;
    uint8_t SEL_CUR : 1;
    uint8_t SS2 : 1;
    uint8_t SS3 : 1;
    uint8_t GledDimming : 5;
    uint8_t reserved1 : 1;
    uint8_t SS4 : 1;
    uint8_t SS5 : 1;
} S_ELLSI_TH20SET_DATA_T;
# 491 "../../../../Library/StdDriver/inc\\ellsi.h"
static inline int32_t ELLSI_GET_FB_COUNT(ELLSI_T *ellsi, uint32_t u32ID)
{
    uint32_t u32Idx;
    uint32_t u32Reg;

    if ((u32ID == 0U) || (u32ID > 15U))
    {
        return -1;
    }

    u32Idx = u32ID - 1U;
    u32Reg = ellsi->FB[u32Idx].FBPCNT & (0x3fful << (0));

    return (int32_t)u32Reg;
}
# 516 "../../../../Library/StdDriver/inc\\ellsi.h"
static inline int32_t ELLSI_SET_FB_COUNT(ELLSI_T *ellsi, uint32_t u32ID, uint32_t u32IDCnt)
{
    uint32_t u32Idx;
    uint32_t u32Reg;

    if ((u32ID == 0U) || (u32ID > 15U))
    {
        return -1;
    }

    u32Idx = u32ID - 1U;

    ellsi->FB[u32Idx].FBPCNT = (u32IDCnt & (0x3fful << (0)));

    u32Reg = ellsi->FB[u32Idx].FBPCNT & (0x3fful << (0));
    return (int32_t)u32Reg;
}
# 543 "../../../../Library/StdDriver/inc\\ellsi.h"
static inline int32_t ELLSI_GET_FB_CURRENT(ELLSI_T *ellsi, uint32_t u32ID)
{
    uint32_t u32Idx;

    if ((u32ID == 0U) || (u32ID > 15U))
    {
        return -1;
    }

    u32Idx = u32ID - 1U;

    return (int32_t)((ellsi->FB[u32Idx].FBPCNT & (0x1ul << (24))) >> (24));
}
# 565 "../../../../Library/StdDriver/inc\\ellsi.h"
static inline int32_t ELLSI_GET_FB_ID(ELLSI_T *ellsi, uint32_t u32ID)
{
    if ((u32ID == 0U) || (u32ID > 15U) || ((u32ID - 1U) >= (uint32_t)(15U)))
    {
        return -1;
    }

    return (int32_t)(ellsi->FB[u32ID - 1U].FBSID);
}
# 623 "../../../../Library/StdDriver/inc\\ellsi.h"
void ELLSI_Open(ELLSI_T *ellsi, uint32_t u32ELLSIMode, uint32_t u32OutputFormat, uint32_t u32BusClock, uint32_t u32TransferTimeNsec, uint32_t u32T0HTimeNsec, uint32_t u32T1HTimeNsec,
                uint32_t u32ResetTimeNsec, uint32_t u32PCNT, uint32_t u32IDOS);
void ELLSI_OpenbyConfig(ELLSI_T *ellsi, const S_ELLSI_CONFIG_T *sELLSIConfig);
void ELLSI_Config_Y_Cable(ELLSI_T *ellsi, const S_ELLSI_TIME_INFO_T *sPt);
void ELLSI_SetTH20Data(ELLSI_T *ellsi, const S_ELLSI_TH20SET_DATA_T *sPt);
int32_t ELLSI_WaitCmdStsDone(ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_Close(ELLSI_T *ellsi);
void ELLSI_GetTimeInfo(const ELLSI_T *ellsi, S_ELLSI_TIME_INFO_T *sPt);
void ELLSI_SetFIFO(ELLSI_T *ellsi, uint32_t u32TxThreshold);
void ELLSI_EnableInt(ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_DisableInt(ELLSI_T *ellsi, uint32_t u32Mask);
uint32_t ELLSI_GetIntFlag(const ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_ClearIntFlag(ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_EnableCmdInt(ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_DisableCmdInt(ELLSI_T *ellsi, uint32_t u32Mask);
uint32_t ELLSI_GetCmdIntFlag(const ELLSI_T *ellsi, uint32_t u32Mask);
void ELLSI_ClearCmdIntFlag(ELLSI_T *ellsi, uint32_t u32Mask);
int32_t ELLSI_GetOverflowFlag(ELLSI_T *ellsi, uint32_t u32ID);
void ELLSI_ClearOverflowFlag(ELLSI_T *ellsi, uint32_t u32ID);
# 1112 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\eqei.h" 1
# 426 "../../../../Library/StdDriver/inc\\eqei.h"
static inline void EQEI_StartUintTimer(EQEI_T *eqei);
static inline void EQEI_StopUintTimer(EQEI_T *eqei);
static inline void EQEI_EnableUintTimerINT(EQEI_T *eqei);
static inline void EQEI_DisableUintTimerINT(EQEI_T *eqei);
# 440 "../../../../Library/StdDriver/inc\\eqei.h"
static inline void EQEI_StartUintTimer(EQEI_T *eqei)
{
    eqei->CTL2 |= (0x1ul << (8));
}
# 454 "../../../../Library/StdDriver/inc\\eqei.h"
static inline void EQEI_StopUintTimer(EQEI_T *eqei)
{
    eqei->CTL2 &= ~(0x1ul << (8));
}
# 468 "../../../../Library/StdDriver/inc\\eqei.h"
static inline void EQEI_EnableUintTimerINT(EQEI_T *eqei)
{
    eqei->CTL2 |= (0x1ul << (17));
}
# 482 "../../../../Library/StdDriver/inc\\eqei.h"
static inline void EQEI_DisableUintTimerINT(EQEI_T *eqei)
{
    eqei->CTL2 &= ~(0x1ul << (17));
}

void EQEI_Close(EQEI_T *eqei);
void EQEI_DisableInt(EQEI_T *eqei, uint32_t u32IntSel);
void EQEI_EnableInt(EQEI_T *eqei, uint32_t u32IntSel);
void EQEI_Open(EQEI_T *eqei, uint32_t u32Mode, uint32_t u32Value);
void EQEI_Start(EQEI_T *eqei);
void EQEI_Stop(EQEI_T *eqei);
# 1113 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\fmc.h" 1
# 511 "../../../../Library/StdDriver/inc\\fmc.h"
extern int32_t g_FMC_i32ErrCode;
# 523 "../../../../Library/StdDriver/inc\\fmc.h"
static inline void FMC_EnableINT(void)
{
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCTL |= (0x1UL << (24));
}




static inline void FMC_DisableINT(void)
{
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCTL &= ~(0x1UL << (24));
}
# 545 "../../../../Library/StdDriver/inc\\fmc.h"
static inline uint32_t FMC_ReadCID(void)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x0BUL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = 0x0U;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return 0xFFFFFFFFU;
        }
    }

    return ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT;
}
# 576 "../../../../Library/StdDriver/inc\\fmc.h"
static inline uint32_t FMC_ReadPID(void)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x0CUL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = 0x04U;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return 0xFFFFFFFFU;
        }
    }

    return ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT;
}
# 607 "../../../../Library/StdDriver/inc\\fmc.h"
static inline uint32_t FMC_ReadUID(uint8_t u8Index)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x04UL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = ((uint32_t)u8Index << 2U);
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT = 0U;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return 0xFFFFFFFFU;
        }
    }

    return ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT;
}
# 639 "../../../../Library/StdDriver/inc\\fmc.h"
static inline uint32_t FMC_ReadUCID(uint32_t u32Index)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x04UL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = (0x04U * u32Index) + 0x10U;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return 0xFFFFFFFFU;
        }
    }

    return ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT;
}
# 670 "../../../../Library/StdDriver/inc\\fmc.h"
static inline uint32_t FMC_ReadDID(void)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x0CUL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = 0x00U;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return 0xFFFFFFFFU;
        }
    }

    return ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPDAT;
}
# 702 "../../../../Library/StdDriver/inc\\fmc.h"
static inline int32_t FMC_SetVectorPageAddr(uint32_t u32PageAddr)
{
    int32_t i32TimeOutCnt = (SystemCoreClock >> 3);

    g_FMC_i32ErrCode = ( 0L);

    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCMD = 0x2EUL;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPADDR = u32PageAddr;
    ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG = (0x1UL << (0));

    while (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPTRG & (0x1UL << (0)))
    {
        if (i32TimeOutCnt-- <= 0)
        {
            g_FMC_i32ErrCode = (-2L);
            return (-2L);
        }
    }

    return ( 0L);
}







static inline uint32_t FMC_GetVECMAP(void)
{
    return (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPSTS & (0x3ffffUL << (10)));
}






static inline uint32_t FMC_GetBankIdx(void)
{
    return ((((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPSTS & (0x1UL << (30))) >> (30));
}







static inline uint32_t FMC_IsBankRemapEnabled(void)
{
    return ((((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPSTS & (0x1UL << (29))) >> (29));
}




extern void FMC_Open(void);
extern void FMC_Close(void);
extern int32_t FMC_GetBootSource(void);
extern int32_t FMC_ConfigXOM(uint32_t u32XomNum, uint32_t u32XomBase, uint8_t u8XomPage);
extern int32_t FMC_Erase(uint32_t u32PageAddr);
extern int32_t FMC_EraseXOM(uint32_t u32XomNum);
extern int32_t FMC_GetXOMState(uint32_t u32XomNum);
extern uint32_t FMC_Read(uint32_t u32Addr);
extern int32_t FMC_Read_64(uint32_t u32Addr, uint32_t *pu32Data0, uint32_t *pu32Data1);
extern int32_t FMC_Read8Bytes(uint32_t u32Addr, uint32_t *pu32Data0, uint32_t *pu32Data1);
extern int32_t FMC_Read_64_ECC(uint32_t u32Addr, uint32_t au32Data[]);
extern int32_t FMC_Read8Bytes_ECC(uint32_t u32Addr, uint32_t au32Data[]);
extern int32_t FMC_Write(uint32_t u32Addr, uint32_t u32Data);
extern int32_t FMC_Write8Bytes(uint32_t u32Addr, uint32_t u32Data0, uint32_t u32Data1);
extern int32_t FMC_ReadConfig(uint32_t au32Config[], uint32_t u32Count);
extern int32_t FMC_WriteConfig(uint32_t u32ConfigAddr, uint32_t u32ConfigVal);
extern int32_t FMC_EraseConfig(uint32_t u32ConfigAddr);
extern uint32_t FMC_GetChkSum(uint32_t u32Addr, uint32_t u32Count);
extern uint32_t FMC_CheckAllOne(uint32_t u32Addr, uint32_t u32Count);
extern int32_t FMC_RemapBank(uint32_t u32Bank);
extern int32_t FMC_EraseBank(uint32_t u32BankAddr);
# 1114 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\gpio.h" 1
# 1181 "../../../../Library/StdDriver/inc\\gpio.h"
void GPIO_SetMode(GPIO_T *port, uint32_t u32PinMask, uint32_t u32Mode);
void GPIO_EnableInt(GPIO_T *port, uint32_t u32Pin, uint32_t u32IntAttribs);
void GPIO_DisableInt(GPIO_T *port, uint32_t u32Pin);
void GPIO_SetSlewCtl(GPIO_T *port, uint32_t u32PinMask, uint32_t u32Mode);
void GPIO_SetPullCtl(GPIO_T *port, uint32_t u32PinMask, uint32_t u32Mode);
void GPIO_EnableEINT(uint32_t u32EINTn, uint32_t u32IntAttribs);
void GPIO_DisableEINT(uint32_t u32EINTn);
# 1115 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\i2c.h" 1
# 74 "../../../../Library/StdDriver/inc\\i2c.h"
extern int32_t g_I2C_i32ErrCode;
# 433 "../../../../Library/StdDriver/inc\\i2c.h"
static inline void I2C_STOP(I2C_T *i2c);
# 443 "../../../../Library/StdDriver/inc\\i2c.h"
static inline void I2C_STOP(I2C_T *i2c)
{
    uint32_t u32TimeOutCount = SystemCoreClock;

    (i2c)->CTL0 |= ((0x1ul << (3)) | (0x1ul << (4)));

    while (i2c->CTL0 & (0x1ul << (4)))
    {
        if (--u32TimeOutCount == 0) break;
    }
}

void I2C_ClearTimeoutFlag(I2C_T *i2c);
void I2C_Close(I2C_T *i2c);
void I2C_Trigger(I2C_T *i2c, uint8_t u8Start, uint8_t u8Stop, uint8_t u8Si, uint8_t u8Ack);
void I2C_DisableInt(I2C_T *i2c);
void I2C_EnableInt(I2C_T *i2c);
uint32_t I2C_GetBusClockFreq(const I2C_T *i2c);
uint32_t I2C_GetIntFlag(const I2C_T *i2c);
uint32_t I2C_GetStatus(const I2C_T *i2c);
uint32_t I2C_Open(I2C_T *i2c, uint32_t u32BusClock);
uint8_t I2C_GetData(const I2C_T *i2c);
void I2C_SetSlaveAddr(I2C_T *i2c, uint8_t u8SlaveNo, uint16_t u16SlaveAddr, uint8_t u8GCMode);
void I2C_SetSlaveAddrMask(I2C_T *i2c, uint8_t u8SlaveNo, uint16_t u16SlaveAddrMask);
uint32_t I2C_SetBusClockFreq(I2C_T *i2c, uint32_t u32BusClock);
void I2C_EnableTimeout(I2C_T *i2c, uint8_t u8LongTimeout);
void I2C_DisableTimeout(I2C_T *i2c);
void I2C_EnableWakeup(I2C_T *i2c);
void I2C_DisableWakeup(I2C_T *i2c);
void I2C_SetData(I2C_T *i2c, uint8_t u8Data);
void I2C_EnableTwoBufferMode(I2C_T *i2c, uint32_t u32BitCount);
void I2C_DisableTwoBufferMode(I2C_T *i2c);
uint8_t I2C_WriteByte(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t data);
uint32_t I2C_WriteMultiBytes(I2C_T *i2c, uint8_t u8SlaveAddr, const uint8_t data[], uint32_t u32wLen);
uint8_t I2C_WriteByteOneReg(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, uint8_t data);
uint32_t I2C_WriteMultiBytesOneReg(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, const uint8_t data[], uint32_t u32wLen);
uint8_t I2C_WriteByteTwoRegs(I2C_T *i2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, uint8_t data);
uint32_t I2C_WriteMultiBytesTwoRegs(I2C_T *i2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, const uint8_t data[], uint32_t u32wLen);
uint8_t I2C_ReadByte(I2C_T *i2c, uint8_t u8SlaveAddr);
uint32_t I2C_ReadMultiBytes(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t rdata[], uint32_t u32rLen);
uint8_t I2C_ReadByteOneReg(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr);
uint32_t I2C_ReadMultiBytesOneReg(I2C_T *i2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, uint8_t rdata[], uint32_t u32rLen);
uint8_t I2C_ReadByteTwoRegs(I2C_T *i2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr);
uint32_t I2C_ReadMultiBytesTwoRegs(I2C_T *i2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, uint8_t rdata[], uint32_t u32rLen);
uint32_t I2C_SMBusGetStatus(const I2C_T *i2c);
void I2C_SMBusClearInterruptFlag(I2C_T *i2c, uint8_t u8SMBusIntFlag);
void I2C_SMBusSetPacketByteCount(I2C_T *i2c, uint32_t u32PktSize);
void I2C_SMBusOpen(I2C_T *i2c, uint8_t u8HostDevice);
void I2C_SMBusClose(I2C_T *i2c);
void I2C_SMBusPECTxEnable(I2C_T *i2c, uint8_t u8PECTxEn);
uint8_t I2C_SMBusGetPECValue(const I2C_T *i2c);
void I2C_SMBusIdleTimeout(I2C_T *i2c, uint32_t us, uint32_t u32Hclk);
void I2C_SMBusTimeout(I2C_T *i2c, uint32_t ms, uint32_t u32Pclk);
void I2C_SMBusClockLoTimeout(I2C_T *i2c, uint32_t ms, uint32_t u32Pclk);
# 1116 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\i3c.h" 1
# 399 "../../../../Library/StdDriver/inc\\i3c.h"
typedef struct
{
    uint32_t RxBufAddr;
    uint32_t RxBufLen;
    uint8_t TargetID;
    uint8_t ErrSts;
    uint8_t IsCCCWrite;
    uint8_t IsDEFTGTS;
    uint8_t CmdSize;
    uint32_t CmdWord;
    uint8_t CmdCCC;
} TGTRESP_T;

typedef struct
{
    I3C_T *port;
    uint32_t engclk;

    uint32_t device_role;

    uint8_t main_controller_da;
    uint8_t main_target_sa;

    uint8_t target_daa_mode;
    uint8_t target_sa[7];
    uint8_t target_da[9];
    uint8_t target_index;
    uint8_t target_count;
    uint8_t target_extcmd;

    uint32_t speed_mode;
    uint32_t i2c_fm_freq;
    uint32_t i2c_fm_plus_freq;
    uint32_t i3c_sdr_freq;

    volatile uint32_t cmd_response;

    uint32_t ibi_status;
    uint8_t is_last_cmd;

    uint8_t ccc_code;
    uint8_t is_HDR_cmd;
    uint8_t HDR_cmd;
    uint8_t is_HDRBT_cmd;
    uint32_t HDRBT_cmd;

    uint8_t is_DB;
    uint8_t DB;

    uint8_t tx_id;
    uint8_t *rx_buf;
    uint32_t rx_len;
    uint8_t *tx_buf;
    uint32_t tx_len;

    uint8_t irq_enable;
    volatile uint32_t intsts;

    uint8_t ibi_type;
    uint8_t ibi_id;
    uint8_t ibi_MDB;
    uint8_t ibi_len;
    uint8_t ibi_TS;
    uint32_t ibi_payload;
    uint8_t *ibi_buf;

    TGTRESP_T tgtRespQ[(4UL)];
    uint32_t extcmdsts;

    PDMA_T *DMAPort;
    uint8_t is_DMA;
    uint8_t RxDMACh;
    uint8_t TxDMACh;

} I3C_DEVICE_T;




extern I3C_DEVICE_T g_I3CDev;
# 1039 "../../../../Library/StdDriver/inc\\i3c.h"
static inline int32_t I3C_Enable(I3C_T *i3c);
static inline int32_t I3C_Disable(I3C_T *i3c);
static inline void I3C_EnableDMA(I3C_T *i3c);
static inline void I3C_DisableDMA(I3C_T *i3c);
static inline void I3C_DelayLoop(uint32_t counts);
# 1055 "../../../../Library/StdDriver/inc\\i3c.h"
static inline int32_t I3C_Enable(I3C_T *i3c)
{
    volatile uint32_t u32Timeout;
    i3c->DEVCTL |= (0x1UL << (31U));
    u32Timeout = (SystemCoreClock / 1000UL);

    while (((i3c->DEVCTL & (0x1UL << (31U))) != (0x1UL << (31U))) && (--u32Timeout)) {}

    if (u32Timeout == 0UL)
    {
        return (-1L);
    }

    return (0L);
}
# 1081 "../../../../Library/StdDriver/inc\\i3c.h"
static inline int32_t I3C_Disable(I3C_T *i3c)
{
    volatile uint32_t u32Timeout;
    i3c->DEVCTL &= ~(0x1UL << (31U));
    u32Timeout = (SystemCoreClock / 1000UL);

    while (((i3c->DEVCTL & (0x1UL << (31U))) == (0x1UL << (31U))) && (--u32Timeout)) {}

    if (u32Timeout == 0UL)
    {
        return (-1L);
    }

    return (0L);
}
# 1104 "../../../../Library/StdDriver/inc\\i3c.h"
static inline void I3C_EnableDMA(I3C_T *i3c)
{
    i3c->DEVCTL &= ~(0x1UL << (28U));
    i3c->DEVCTL |= (0x1UL << (28U));
}
# 1117 "../../../../Library/StdDriver/inc\\i3c.h"
static inline void I3C_DisableDMA(I3C_T *i3c)
{
    i3c->DEVCTL &= ~(0x1UL << (28U));
}

static inline void I3C_DelayLoop(uint32_t counts)
{
    volatile uint32_t i = counts;

    if (i != 0UL)
    {
        while (i--) {}
    }
}



int32_t I3C_DeviceInit(I3C_DEVICE_T *dev);
int32_t I3C_SetDeviceAddr(I3C_T *i3c, uint8_t u8DevIndex, uint8_t u8DevType, uint8_t u8DAddr, uint8_t u8SAddr);
void I3C_BusClkConfig(I3C_DEVICE_T *dev);
void I3C_PresentStateInfo(I3C_DEVICE_T *dev);
int32_t I3C_ConfigRxDMA(I3C_DEVICE_T *dev, uint32_t u32Src, uint32_t u32Dest, uint32_t u32ByteCnts);
int32_t I3C_ConfigTxDMA(I3C_DEVICE_T *dev, uint32_t u32Src, uint32_t u32Dest, uint32_t u32ByteCnts);


int32_t I3C_CtrDAA(I3C_DEVICE_T *dev);
int32_t I3C_CtrCCCSet(I3C_DEVICE_T *dev);
int32_t I3C_CtrCCCGet(I3C_DEVICE_T *dev);
int32_t I3C_CtrWrite(I3C_DEVICE_T *dev);
int32_t I3C_CtrRead(I3C_DEVICE_T *dev);
int32_t I3C_CtrBTWrite(I3C_DEVICE_T *dev);
int32_t I3C_CtrBTRead(I3C_DEVICE_T *dev);
int32_t I3C_CtrDEFTGTS(I3C_DEVICE_T *dev);
int32_t I3C_CtrGETACCCR(I3C_DEVICE_T *dev);
int32_t I3C_CtrGetIBI(I3C_DEVICE_T *dev);
void I3C_CtrHandleTransErr(I3C_DEVICE_T *dev);


int32_t I3C_TgtRecv(I3C_DEVICE_T *dev);
int32_t I3C_TgtSend(I3C_DEVICE_T *dev);
int32_t I3C_TgtGetSendResult(I3C_DEVICE_T *dev);
int32_t I3C_TgtIssueIBI(I3C_DEVICE_T *dev);
void I3C_TgtHandleIntSts(I3C_DEVICE_T *dev);
void I3C_TgtHandleTransErr(I3C_DEVICE_T *dev);
# 1117 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\llsi.h" 1
# 28 "../../../../Library/StdDriver/inc\\llsi.h"
typedef struct
{
    uint32_t u32BusClock;
    uint32_t u32TransferTimeNsec;
    uint32_t u32T0HTimeNsec;
    uint32_t u32T1HTimeNsec;
    uint32_t u32ResetTimeNsec;
} S_LLSI_TIME_INFO_T;

typedef struct
{
    uint32_t u32LLSIMode;
    uint32_t u32OutputFormat;
    S_LLSI_TIME_INFO_T sTimeInfo;
    uint32_t u32PCNT;
    uint32_t u32IDOS;
} S_LLSI_CONFIG_T;
# 195 "../../../../Library/StdDriver/inc\\llsi.h"
void LLSI_Open(LLSI_T *llsi, uint32_t u32LLSIMode, uint32_t u32OutputFormat, uint32_t u32BusClock, uint32_t u32TransferTimeNsec, uint32_t u32T0HTimeNsec, uint32_t u32T1HTimeNsec,
               uint32_t u32ResetTimeNsec, uint32_t u32PCNT, uint32_t u32IDOS);
void LLSI_OpenbyConfig(LLSI_T *llsi, const S_LLSI_CONFIG_T *sLLSIConfig);
void LLSI_Close(LLSI_T *llsi);
void LLSI_GetTimeInfo(const LLSI_T *llsi, S_LLSI_TIME_INFO_T *sPt);
void LLSI_SetFIFO(LLSI_T *llsi, uint32_t u32TxThreshold);
void LLSI_EnableInt(LLSI_T *llsi, uint32_t u32Mask);
void LLSI_DisableInt(LLSI_T *llsi, uint32_t u32Mask);
uint32_t LLSI_GetIntFlag(const LLSI_T *llsi, uint32_t u32Mask);
void LLSI_ClearIntFlag(LLSI_T *llsi, uint32_t u32Mask);
# 1118 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\pdma.h" 1
# 344 "../../../../Library/StdDriver/inc\\pdma.h"
void PDMA_Open(PDMA_T *pdma, uint32_t u32Mask);
void PDMA_Close(PDMA_T *pdma);
void PDMA_SetTransferCnt(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32Width, uint32_t u32TransCount);
void PDMA_SetTransferAddr(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32SrcAddr, uint32_t u32SrcCtrl, uint32_t u32DstAddr, uint32_t u32DstCtrl);
void PDMA_SetTransferMode(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32Peripheral, uint32_t u32ScatterEn, uint32_t u32DescAddr);
void PDMA_SetBurstType(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32BurstType, uint32_t u32BurstSize);
void PDMA_Trigger(PDMA_T *pdma, uint32_t u32Ch);
void PDMA_EnableInt(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32Mask);
void PDMA_DisableInt(PDMA_T *pdma, uint32_t u32Ch, uint32_t u32Mask);
# 1119 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\pwm.h" 1
# 506 "../../../../Library/StdDriver/inc\\pwm.h"
uint32_t PWM_ConfigCaptureChannel(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32UnitTimeNsec, uint32_t u32CaptureEdge);
uint32_t PWM_ConfigOutputChannel(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Frequency, uint32_t u32DutyCycle);
void PWM_Start(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_Stop(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_ForceStop(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_EnableADCTrigger(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Condition);
void PWM_DisableADCTrigger(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearADCTriggerFlag(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Condition);
uint32_t PWM_GetADCTriggerFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableDACTrigger(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Condition);
void PWM_DisableDACTrigger(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearDACTriggerFlag(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Condition);
uint32_t PWM_GetDACTriggerFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableFaultBrake(PWM_T *pwm, uint32_t u32ChannelMask, uint32_t u32LevelMask, uint32_t u32BrakeSource);
void PWM_EnableCapture(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_DisableCapture(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_EnableOutput(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_DisableOutput(PWM_T *pwm, uint32_t u32ChannelMask);
void PWM_EnablePDMA(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32RisingFirst, uint32_t u32Mode);
void PWM_DisablePDMA(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableDeadZone(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Duration);
void PWM_DisableDeadZone(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableCaptureInt(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Edge);
void PWM_DisableCaptureInt(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Edge);
void PWM_ClearCaptureIntFlag(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32Edge);
uint32_t PWM_GetCaptureIntFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableDutyInt(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32IntDutyType);
void PWM_DisableDutyInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearDutyIntFlag(PWM_T *pwm, uint32_t u32ChannelNum);
uint32_t PWM_GetDutyIntFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableFaultBrakeInt(PWM_T *pwm, uint32_t u32BrakeSource);
void PWM_DisableFaultBrakeInt(PWM_T *pwm, uint32_t u32BrakeSource);
void PWM_ClearFaultBrakeIntFlag(PWM_T *pwm, uint32_t u32BrakeSource);
uint32_t PWM_GetFaultBrakeIntFlag(const PWM_T *pwm, uint32_t u32BrakeSource);
void PWM_EnablePeriodInt(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32IntPeriodType);
void PWM_DisablePeriodInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearPeriodIntFlag(PWM_T *pwm, uint32_t u32ChannelNum);
uint32_t PWM_GetPeriodIntFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableZeroInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_DisableZeroInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearZeroIntFlag(PWM_T *pwm, uint32_t u32ChannelNum);
uint32_t PWM_GetZeroIntFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableLoadMode(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32LoadMode);
void PWM_DisableLoadMode(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32LoadMode);
void PWM_SetClockSource(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32ClkSrcSel);
void PWM_EnableBrakeNoiseFilter(PWM_T *pwm, uint32_t u32BrakePinNum, uint32_t u32ClkCnt, uint32_t u32ClkDivSel);
void PWM_DisableBrakeNoiseFilter(PWM_T *pwm, uint32_t u32BrakePinNum);
void PWM_EnableBrakePinInverse(PWM_T *pwm, uint32_t u32BrakePinNum);
void PWM_DisableBrakePinInverse(PWM_T *pwm, uint32_t u32BrakePinNum);
void PWM_SetBrakePinSource(PWM_T *pwm, uint32_t u32BrakePinNum, uint32_t u32SelAnotherModule);
uint32_t PWM_GetWrapAroundFlag(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearWrapAroundFlag(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableAcc(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32IntFlagCnt, uint32_t u32IntAccSrc);
void PWM_DisableAcc(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableAccInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_DisableAccInt(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_ClearAccInt(PWM_T *pwm, uint32_t u32ChannelNum);
uint32_t PWM_GetAccInt(const PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableAccPDMA(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_DisableAccPDMA(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableAccStopMode(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_DisableAccStopMode(PWM_T *pwm, uint32_t u32ChannelNum);
void PWM_EnableExtEventTrigger(PWM_T *pwm, uint32_t u32ChannelNum, uint32_t u32ExtEventSrc, uint32_t u32CounterAction);
void PWM_DisableExtEventTrigger(PWM_T *pwm, uint32_t u32ChannelNum);
# 1120 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\qspi.h" 1
# 231 "../../../../Library/StdDriver/inc\\qspi.h"
static inline void QSPI_SET_SS_HIGH(QSPI_T *qspi)
{
    uint32_t u32SSCtl = qspi->SSCTL & ~(0x1ul << (3));
    uint32_t u32ActivePol = u32SSCtl & (0x1ul << (2));

    if (u32ActivePol != 0UL)
    {
        qspi->SSCTL = u32SSCtl | (0x1ul << (0));
    }
    else
    {
        qspi->SSCTL = u32SSCtl & ~(0x1ul << (0));
    }
}
# 253 "../../../../Library/StdDriver/inc\\qspi.h"
static inline void QSPI_SET_SS_LOW(QSPI_T *qspi)
{
    uint32_t u32SSCtl = qspi->SSCTL & ~(0x1ul << (3));
    uint32_t u32ActivePol = u32SSCtl & (0x1ul << (2));

    if (u32ActivePol != 0UL)
    {
        qspi->SSCTL = u32SSCtl & ~(0x1ul << (0));
    }
    else
    {
        qspi->SSCTL = u32SSCtl | (0x1ul << (0));
    }
}
# 295 "../../../../Library/StdDriver/inc\\qspi.h"
static inline void QSPI_SET_SUSPEND_CYCLE(QSPI_T *qspi, uint32_t u32SuspCycle)
{
    qspi->CTL = (qspi->CTL & ~(0xful << (4))) |
                ((u32SuspCycle & 0xFUL) << (4));
}
# 327 "../../../../Library/StdDriver/inc\\qspi.h"
static inline void QSPI_SET_DATA_WIDTH(QSPI_T *qspi, uint32_t u32Width)
{
    uint32_t u32WidthTmp = u32Width;

    if ((u32WidthTmp > 0U) && (u32WidthTmp < 8U))
    {
        u32WidthTmp = 8U;
    }
    else if (u32WidthTmp >= 32U)
    {
        u32WidthTmp = 0U;
    }
    else
    {
        u32WidthTmp &= 0x1FUL;
    }

    qspi->CTL = (qspi->CTL & ~(0x1ful << (8))) |
                (u32WidthTmp << (8));
}
# 455 "../../../../Library/StdDriver/inc\\qspi.h"
uint32_t QSPI_Open(QSPI_T *qspi, uint32_t u32MasterSlave, uint32_t u32QSPIMode, uint32_t u32DataWidth, uint32_t u32BusClock);
void QSPI_Close(const QSPI_T *qspi);
void QSPI_ClearRxFIFO(QSPI_T *qspi);
void QSPI_ClearTxFIFO(QSPI_T *qspi);
void QSPI_DisableAutoSS(QSPI_T *qspi);
void QSPI_EnableAutoSS(QSPI_T *qspi, uint32_t u32SSPinMask, uint32_t u32ActiveLevel);
uint32_t QSPI_SetBusClock(QSPI_T *qspi, uint32_t u32BusClock);
void QSPI_SetFIFO(QSPI_T *qspi, uint32_t u32TxThreshold, uint32_t u32RxThreshold);
uint32_t QSPI_GetBusClock(const QSPI_T *qspi);
void QSPI_EnableInt(QSPI_T *qspi, uint32_t u32Mask);
void QSPI_DisableInt(QSPI_T *qspi, uint32_t u32Mask);
uint32_t QSPI_GetIntFlag(const QSPI_T *qspi, uint32_t u32Mask);
void QSPI_ClearIntFlag(QSPI_T *qspi, uint32_t u32Mask);
uint32_t QSPI_GetStatus(const QSPI_T *qspi, uint32_t u32Mask);
# 1121 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\rng.h" 1
# 37 "../../../../Library/StdDriver/inc\\rng.h"
int32_t RNG_Open(void);
int32_t RNG_Random(uint32_t *pu32Buf, int32_t nWords);
int32_t RNG_EntropyPoll(uint32_t *pu32Out, int32_t i32Len);
# 1122 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\rtc.h" 1
# 95 "../../../../Library/StdDriver/inc\\rtc.h"
typedef struct
{
    uint32_t u32Year;
    uint32_t u32Month;
    uint32_t u32Day;
    uint32_t u32DayOfWeek;
    uint32_t u32Hour;
    uint32_t u32Minute;
    uint32_t u32Second;
    uint32_t u32TimeScale;
    uint32_t u32AmPm;
} S_RTC_TIME_DATA_T;
# 199 "../../../../Library/StdDriver/inc\\rtc.h"
int32_t RTC_Open(S_RTC_TIME_DATA_T *sPt);
void RTC_Close(void);
int32_t RTC_32KCalibration(int32_t i32FrequencyX10000);
void RTC_GetDateAndTime(S_RTC_TIME_DATA_T *sPt);
void RTC_GetAlarmDateAndTime(S_RTC_TIME_DATA_T *sPt);
void RTC_SetDateAndTime(S_RTC_TIME_DATA_T *sPt);
void RTC_SetAlarmDateAndTime(S_RTC_TIME_DATA_T *sPt);
void RTC_SetDate(uint32_t u32Year, uint32_t u32Month, uint32_t u32Day, uint32_t u32DayOfWeek);
void RTC_SetTime(uint32_t u32Hour, uint32_t u32Minute, uint32_t u32Second, uint32_t u32TimeMode, uint32_t u32AmPm);
void RTC_SetAlarmDate(uint32_t u32Year, uint32_t u32Month, uint32_t u32Day);
void RTC_SetAlarmTime(uint32_t u32Hour, uint32_t u32Minute, uint32_t u32Second, uint32_t u32TimeMode, uint32_t u32AmPm);
void RTC_SetAlarmDateMask(uint8_t u8IsTenYMsk, uint8_t u8IsYMsk, uint8_t u8IsTenMMsk, uint8_t u8IsMMsk, uint8_t u8IsTenDMsk, uint8_t u8IsDMsk);
void RTC_SetAlarmTimeMask(uint8_t u8IsTenHMsk, uint8_t u8IsHMsk, uint8_t u8IsTenMMsk, uint8_t u8IsMMsk, uint8_t u8IsTenSMsk, uint8_t u8IsSMsk);
uint32_t RTC_GetDayOfWeek(void);
void RTC_SetTickPeriod(uint32_t u32TickSelection);
void RTC_EnableInt(uint32_t u32IntFlagMask);
void RTC_DisableInt(uint32_t u32IntFlagMask);
uint32_t RTC_SetClockSource(uint32_t u32ClkSrc);
# 1123 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\scu.h" 1
# 54 "../../../../Library/StdDriver/inc\\scu.h"
typedef enum NSATTR
{

    PDMA0_Attr = 8,
    USBH_Attr = 9,
    EBI_Attr = 16,



    CANFD0_Attr = 32,
    CANFD1_Attr = 32 + 4,
    CRC_Attr = 32 + 17,
    CACHE_Attr = 32 + 22,


    RTC_Attr = 64 + 1,
    WDT1_Attr = 64 + 2,
    EADC0_Attr = 64 + 3,
    ACMP01_Attr = 64 + 5,
    DAC_Attr = 64 + 7,
    EADC1_Attr = 64 + 11,
    TMR01_Attr = 64 + 16,
    TMR23_Attr = 64 + 17,
    BPWM0_Attr = 64 + 26,
    BPWM1_Attr = 64 + 27,
    PWM0_Attr = 64 + 28,
    PWM1_Attr = 64 + 29,


    QSPI0_Attr = 96,
    SPI0_Attr = 96 + 1,
    SPI1_Attr = 96 + 2,
    UART0_Attr = 96 + 16,
    UART1_Attr = 96 + 17,
    UART2_Attr = 96 + 18,
    UART3_Attr = 96 + 19,
    UART4_Attr = 96 + 20,
    UART5_Attr = 96 + 21,
    UART6_Attr = 96 + 22,
    UART7_Attr = 96 + 23,
    UART8_Attr = 96 + 24,
    UART9_Attr = 96 + 25,


    I2C0_Attr = 128,
    I2C1_Attr = 128 + 1,
    I2C2_Attr = 128 + 2,
    I3C0_Attr = 128 + 6,
    LLSI0_Attr = 128 + 8,
    LLSI1_Attr = 128 + 9,
    ELLSI0_Attr = 128 + 10,
    ELLSI1_Attr = 128 + 11,
    WWDT1_Attr = 128 + 24,


    EQEI0_Attr = 160 + 16,
    EQEI1_Attr = 160 + 17,
    ECAP0_Attr = 160 + 20,
    TRNG_Attr = 160 + 25,


    USBD_Attr = 192,
    USCI0_Attr = 192 + 16,
    USCI1_Attr = 192 + 17
} NSATTR_T;
# 341 "../../../../Library/StdDriver/inc\\scu.h"
static inline void SCU_NSMConfig(uint32_t u32Ticks, uint32_t u32Prescale);
static inline void SCU_TimerConfig(uint32_t u32Ticks, uint32_t u32Prescale);
# 361 "../../../../Library/StdDriver/inc\\scu.h"
static inline void SCU_NSMConfig(uint32_t u32Ticks, uint32_t u32Prescale)
{

    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMLOAD = u32Ticks;
    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMVAL = 0ul;
    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMCTL = (0x1UL << (9)) | (0x1UL << (8)) | (u32Prescale & 0xffUL);
}
# 383 "../../../../Library/StdDriver/inc\\scu.h"
static inline void SCU_TimerConfig(uint32_t u32Ticks, uint32_t u32Prescale)
{

    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMLOAD = u32Ticks;
    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMVAL = 0ul;
    ((SCU_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x2F000UL))->NSMCTL = (0x1UL << (9)) | (0x1UL << (8)) | (0x1UL << (10)) | (u32Prescale & 0xffUL);
}
# 1124 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\spi.h" 1
# 288 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPI_SET_SS_HIGH(SPI_T *spi)
{
    uint32_t u32SSCtl = spi->SSCTL & ~(0x1ul << (3));
    uint32_t u32ActivePol = u32SSCtl & (0x1ul << (2));

    if (u32ActivePol != 0UL)
    {
        spi->SSCTL = u32SSCtl | (0x1ul << (0));
    }
    else
    {
        spi->SSCTL = u32SSCtl & ~(0x1ul << (0));
    }
}
# 310 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPI_SET_SS_LOW(SPI_T *spi)
{
    uint32_t u32SSCtl = spi->SSCTL & ~(0x1ul << (3));
    uint32_t u32ActivePol = u32SSCtl & (0x1ul << (2));

    if (u32ActivePol != 0UL)
    {
        spi->SSCTL = u32SSCtl & ~(0x1ul << (0));
    }
    else
    {
        spi->SSCTL = u32SSCtl | (0x1ul << (0));
    }
}
# 352 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPI_SET_SUSPEND_CYCLE(SPI_T *spi, uint32_t u32SuspCycle)
{
    spi->CTL = (spi->CTL & ~(0xful << (4))) |
               ((u32SuspCycle & 0xFUL) << (4));
}
# 384 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPI_SET_DATA_WIDTH(SPI_T *spi, uint32_t u32Width)
{
    uint32_t u32WidthTmp = u32Width;

    if ((u32WidthTmp > 0UL) && (u32WidthTmp < 4UL))
    {
        u32WidthTmp = 4UL;
    }
    else if (u32WidthTmp >= 32UL)
    {
        u32WidthTmp = 0UL;
    }
    else
    {
        u32WidthTmp &= 0x1FUL;
    }

    spi->CTL = (spi->CTL & ~(0x1ful << (8))) |
               (u32WidthTmp << (8));
}
# 434 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPII2S_ENABLE_TX_ZCD(SPI_T *i2s, uint32_t u32ChMask);
static inline void SPII2S_DISABLE_TX_ZCD(SPI_T *i2s, uint32_t u32ChMask);
static inline void SPII2S_SET_MONO_RX_CHANNEL(SPI_T *i2s, uint32_t u32Ch);
# 446 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPII2S_ENABLE_TX_ZCD(SPI_T *i2s, uint32_t u32ChMask)
{
    if (u32ChMask == (0U))
    {
        (i2s)->I2SCTL |= (0x1ul << (16));
    }
    else
    {
        (i2s)->I2SCTL |= (0x1ul << (17));
    }
}
# 466 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPII2S_DISABLE_TX_ZCD(SPI_T *i2s, uint32_t u32ChMask)
{
    if (u32ChMask == (0U))
    {
        (i2s)->I2SCTL &= ~(0x1ul << (16));
    }
    else
    {
        (i2s)->I2SCTL &= ~(0x1ul << (17));
    }
}
# 581 "../../../../Library/StdDriver/inc\\spi.h"
static inline void SPII2S_SET_MONO_RX_CHANNEL(SPI_T *i2s, uint32_t u32Ch)
{
    if (u32Ch == (1U))
    {
        i2s->I2SCTL |= (0x1ul << (23));
    }
    else
    {
        i2s->I2SCTL &= ~(0x1ul << (23));
    }
}
# 653 "../../../../Library/StdDriver/inc\\spi.h"
uint32_t SPI_Open(SPI_T *spi, uint32_t u32MasterSlave, uint32_t u32SPIMode, uint32_t u32DataWidth, uint32_t u32BusClock);
void SPI_Close(const SPI_T *spi);
void SPI_ClearRxFIFO(SPI_T *spi);
void SPI_ClearTxFIFO(SPI_T *spi);
void SPI_DisableAutoSS(SPI_T *spi);
void SPI_EnableAutoSS(SPI_T *spi, uint32_t u32SSPinMask, uint32_t u32ActiveLevel);
uint32_t SPI_SetBusClock(SPI_T *spi, uint32_t u32BusClock);
void SPI_SetFIFO(SPI_T *spi, uint32_t u32TxThreshold, uint32_t u32RxThreshold);
uint32_t SPI_GetBusClock(const SPI_T *spi);
void SPI_EnableInt(SPI_T *spi, uint32_t u32Mask);
void SPI_DisableInt(SPI_T *spi, uint32_t u32Mask);
uint32_t SPI_GetIntFlag(const SPI_T *spi, uint32_t u32Mask);
void SPI_ClearIntFlag(SPI_T *spi, uint32_t u32Mask);
uint32_t SPI_GetStatus(const SPI_T *spi, uint32_t u32Mask);
uint32_t SPI_GetStatus2(const SPI_T *spi, uint32_t u32Mask);


uint32_t SPII2S_Open(SPI_T *i2s, uint32_t u32MasterSlave, uint32_t u32SampleRate, uint32_t u32WordWidth, uint32_t u32Channels, uint32_t u32DataFormat);
void SPII2S_Close(SPI_T *i2s);
void SPII2S_EnableInt(SPI_T *i2s, uint32_t u32Mask);
void SPII2S_DisableInt(SPI_T *i2s, uint32_t u32Mask);
uint32_t SPII2S_EnableMCLK(SPI_T *i2s, uint32_t u32BusClock);
void SPII2S_DisableMCLK(SPI_T *i2s);
void SPII2S_SetFIFO(SPI_T *i2s, uint32_t u32TxThreshold, uint32_t u32RxThreshold);
# 1125 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\sys.h" 1
# 2364 "../../../../Library/StdDriver/inc\\sys.h"
static inline void SYS_UnlockReg(void);
static inline void SYS_LockReg(void);
# 2374 "../../../../Library/StdDriver/inc\\sys.h"
static inline void SYS_UnlockReg(void)
{
    uint32_t u32TimeOutCount = (48000000UL);

    do
    {
        ((SYS_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x00000UL))->REGLCTL = 0x59UL;
        ((SYS_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x00000UL))->REGLCTL = 0x16UL;
        ((SYS_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x00000UL))->REGLCTL = 0x88UL;

        if (--u32TimeOutCount == 0) break;
    } while (((SYS_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x00000UL))->REGLCTL == 0UL);
}
# 2395 "../../../../Library/StdDriver/inc\\sys.h"
static inline void SYS_LockReg(void)
{
    ((SYS_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x00000UL))->REGLCTL = 0UL;
}


void SYS_ClearResetSrc(uint32_t u32Src);
uint32_t SYS_GetBODStatus(void);
uint32_t SYS_GetResetSrc(void);
uint32_t SYS_IsRegLocked(void);
uint32_t SYS_ReadPDID(void);
void SYS_ResetChip(void);
void SYS_ResetCPU(void);
void SYS_ResetModule(uint32_t u32ModuleIndex);
void SYS_EnableBOD(int32_t i32Mode, uint32_t u32BODLevel);
void SYS_DisableBOD(void);
void SYS_SetVRef(uint32_t u32VRefCTL);
# 1126 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\timer.h" 1
# 172 "../../../../Library/StdDriver/inc\\timer.h"
static inline void TIMER_Start(TIMER_T *timer);
static inline void TIMER_Stop(TIMER_T *timer);
static inline void TIMER_EnableWakeup(TIMER_T *timer);
static inline void TIMER_DisableWakeup(TIMER_T *timer);
static inline void TIMER_StartCapture(TIMER_T *timer);
static inline void TIMER_StopCapture(TIMER_T *timer);
static inline void TIMER_EnableCaptureDebounce(TIMER_T *timer);
static inline void TIMER_DisableCaptureDebounce(TIMER_T *timer);
static inline void TIMER_EnableEventCounterDebounce(TIMER_T *timer);
static inline void TIMER_DisableEventCounterDebounce(TIMER_T *timer);
static inline void TIMER_EnableInt(TIMER_T *timer);
static inline void TIMER_DisableInt(TIMER_T *timer);
static inline void TIMER_EnableCaptureInt(TIMER_T *timer);
static inline void TIMER_DisableCaptureInt(TIMER_T *timer);
static inline uint32_t TIMER_GetIntFlag(const TIMER_T *timer);
static inline void TIMER_ClearIntFlag(TIMER_T *timer);
static inline uint32_t TIMER_GetCaptureIntFlag(const TIMER_T *timer);
static inline uint32_t TIMER_GetCaptureIntFlagOV(const TIMER_T *timer);
static inline void TIMER_ClearCaptureIntFlag(TIMER_T *timer);
static inline uint32_t TIMER_GetWakeupFlag(const TIMER_T *timer);
static inline void TIMER_ClearWakeupFlag(TIMER_T *timer);
static inline uint32_t TIMER_GetCaptureData(const TIMER_T *timer);
static inline uint32_t TIMER_GetCounter(const TIMER_T *timer);
static inline void TIMER_EventCounterSelect(TIMER_T *timer, uint32_t u32Src);







static inline void TIMER_Start(TIMER_T *timer)
{
    timer->CTL |= (0x1ul << (30));
}







static inline void TIMER_Stop(TIMER_T *timer)
{
    timer->CTL &= ~(0x1ul << (30));
}
# 227 "../../../../Library/StdDriver/inc\\timer.h"
static inline void TIMER_EnableWakeup(TIMER_T *timer)
{
    timer->CTL |= (0x1ul << (23));
}







static inline void TIMER_DisableWakeup(TIMER_T *timer)
{
    timer->CTL &= ~(0x1ul << (23));
}







static inline void TIMER_StartCapture(TIMER_T *timer)
{
    timer->EXTCTL |= (0x1ul << (3));
}







static inline void TIMER_StopCapture(TIMER_T *timer)
{
    timer->EXTCTL &= ~(0x1ul << (3));
}







static inline void TIMER_EnableCaptureDebounce(TIMER_T *timer)
{
    timer->EXTCTL |= (0x1ul << (6));
}







static inline void TIMER_DisableCaptureDebounce(TIMER_T *timer)
{
    timer->EXTCTL &= ~(0x1ul << (6));
}







static inline void TIMER_EnableEventCounterDebounce(TIMER_T *timer)
{
    timer->EXTCTL |= (0x1ul << (7));
}







static inline void TIMER_DisableEventCounterDebounce(TIMER_T *timer)
{
    timer->EXTCTL &= ~(0x1ul << (7));
}







static inline void TIMER_EnableInt(TIMER_T *timer)
{
    timer->CTL |= (0x1ul << (29));
}







static inline void TIMER_DisableInt(TIMER_T *timer)
{
    timer->CTL &= ~(0x1ul << (29));
}







static inline void TIMER_EnableCaptureInt(TIMER_T *timer)
{
    timer->EXTCTL |= (0x1ul << (5));
}







static inline void TIMER_DisableCaptureInt(TIMER_T *timer)
{
    timer->EXTCTL &= ~(0x1ul << (5));
}
# 360 "../../../../Library/StdDriver/inc\\timer.h"
static inline uint32_t TIMER_GetIntFlag(const TIMER_T *timer)
{
    return ((timer->INTSTS & (0x1ul << (0))) ? 1UL : 0UL);
}







static inline void TIMER_ClearIntFlag(TIMER_T *timer)
{
    timer->INTSTS = (0x1ul << (0));
}
# 383 "../../../../Library/StdDriver/inc\\timer.h"
static inline uint32_t TIMER_GetCaptureIntFlag(const TIMER_T *timer)
{
    return timer->EINTSTS;
}
# 395 "../../../../Library/StdDriver/inc\\timer.h"
static inline uint32_t TIMER_GetCaptureIntFlagOV(const TIMER_T *timer)
{
    return ((timer->EINTSTS & (0x1ul << (1))) ? 1UL : 0UL);
}







static inline void TIMER_ClearCaptureIntFlag(TIMER_T *timer)
{
    timer->EINTSTS = (0x1ul << (0));
}
# 418 "../../../../Library/StdDriver/inc\\timer.h"
static inline uint32_t TIMER_GetWakeupFlag(const TIMER_T *timer)
{
    return ((timer->INTSTS & (0x1ul << (1))) ? 1UL : 0UL);
}







static inline void TIMER_ClearWakeupFlag(TIMER_T *timer)
{
    timer->INTSTS = (0x1ul << (1));
}







static inline uint32_t TIMER_GetCaptureData(const TIMER_T *timer)
{
    return timer->CAP;
}







static inline uint32_t TIMER_GetCounter(const TIMER_T *timer)
{
    return timer->CNT;
}
# 468 "../../../../Library/StdDriver/inc\\timer.h"
static inline void TIMER_EventCounterSelect(TIMER_T *timer, uint32_t u32Src)
{
    timer->EXTCTL = (timer->EXTCTL & ~(0x7ul << (16))) | (u32Src & (0x7ul << (16)));
}

uint32_t TIMER_Open(TIMER_T *timer, uint32_t u32Mode, uint32_t u32Freq);
void TIMER_Close(TIMER_T *timer);
int32_t TIMER_Delay(TIMER_T *timer, uint32_t u32Usec);
void TIMER_EnableCapture(TIMER_T *timer, uint32_t u32CapMode, uint32_t u32Edge);
void TIMER_CaptureSelect(TIMER_T *timer, uint32_t u32Src);
void TIMER_DisableCapture(TIMER_T *timer);
void TIMER_EnableEventCounter(TIMER_T *timer, uint32_t u32Edge);
void TIMER_DisableEventCounter(TIMER_T *timer);
uint32_t TIMER_GetModuleClock(const TIMER_T *timer);
void TIMER_EnableFreqCounter(TIMER_T *timer,
                             uint32_t u32DropCount,
                             uint32_t u32Timeout,
                             uint32_t u32EnableInt);
void TIMER_DisableFreqCounter(TIMER_T *timer);
void TIMER_SetTriggerSource(TIMER_T *timer, uint32_t u32Src);
void TIMER_SetTriggerTarget(TIMER_T *timer, uint32_t u32Mask);
int32_t TIMER_ResetCounter(TIMER_T *timer);
void TIMER_EnableCaptureInputNoiseFilter(TIMER_T *timer, uint32_t u32FilterCount, uint32_t u32ClkSrcSel);
void TIMER_DisableCaptureInputNoiseFilter(TIMER_T *timer);
# 1127 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\timer_pwm.h" 1
# 441 "../../../../Library/StdDriver/inc\\timer_pwm.h"
static inline void TPWM_EnableWakeup(TIMER_T *timer);
static inline void TPWM_DisableWakeup(TIMER_T *timer);
static inline uint32_t TPWM_GetWakeupFlag(const TIMER_T *timer);
static inline void TPWM_ClearWakeupFlag(TIMER_T *timer);
# 455 "../../../../Library/StdDriver/inc\\timer_pwm.h"
static inline void TPWM_EnableWakeup(TIMER_T *timer)
{
    timer->PWMCTL |= (0x1ul << (12));
}
# 467 "../../../../Library/StdDriver/inc\\timer_pwm.h"
static inline void TPWM_DisableWakeup(TIMER_T *timer)
{
    timer->PWMCTL &= ~(0x1ul << (12));
}
# 482 "../../../../Library/StdDriver/inc\\timer_pwm.h"
static inline uint32_t TPWM_GetWakeupFlag(const TIMER_T *timer)
{
    return ((timer->PWMSTATUS & (0x1ul << (8))) ? 1 : 0);
}
# 494 "../../../../Library/StdDriver/inc\\timer_pwm.h"
static inline void TPWM_ClearWakeupFlag(TIMER_T *timer)
{
    timer->PWMSTATUS = (0x1ul << (8));
}

uint32_t TPWM_ConfigOutputFreqAndDuty(TIMER_T *timer, uint32_t u32Frequency, uint32_t u32DutyCycle);
void TPWM_EnableCounter(TIMER_T *timer);
void TPWM_DisableCounter(TIMER_T *timer);
void TPWM_EnableTrigger(TIMER_T *timer, uint32_t u32TargetMask, uint32_t u32Condition);
void TPWM_DisableTrigger(TIMER_T *timer, uint32_t u32TargetMask);
void TPWM_EnableAcc(TIMER_T *timer, uint32_t u32IntFlagCnt, uint32_t u32IntAccSrc);
void TPWM_DisableAcc(TIMER_T *timer);
void TPWM_EnableAccInt(TIMER_T *timer);
void TPWM_DisableAccInt(TIMER_T *timer);
void TPWM_ClearAccInt(TIMER_T *timer);
uint32_t TPWM_GetAccInt(const TIMER_T *timer);
void TPWM_EnableAccPDMA(TIMER_T *timer);
void TPWM_DisableAccPDMA(TIMER_T *timer);
void TPWM_EnableAccStopMode(TIMER_T *timer);
void TPWM_DisableAccStopMode(TIMER_T *timer);
# 1128 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\trng.h" 1
# 81 "../../../../Library/StdDriver/inc\\trng.h"
int32_t TRNG_Open(void);
int32_t TRNG_GenWord(uint32_t *u32RndNum);
int32_t TRNG_GenBignum(uint8_t u8BigNum[], int32_t i32Len);
int32_t TRNG_GenBignumHex(char cBigNumHex[], int32_t i32Len);
# 1129 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\uart.h" 1
# 415 "../../../../Library/StdDriver/inc\\uart.h"
static inline void UART_CLEAR_RTS(UART_T *uart);
static inline void UART_SET_RTS(UART_T *uart);
static inline void UART_RESET_RXFIFO(UART_T *uart);
static inline void UART_RESET_TXFIFO(UART_T *uart);
# 430 "../../../../Library/StdDriver/inc\\uart.h"
static inline void UART_CLEAR_RTS(UART_T *uart)
{
    uart->MODEM |= (0x1ul << (9));
    uart->MODEM &= ~(0x1ul << (1));
}
# 447 "../../../../Library/StdDriver/inc\\uart.h"
static inline void UART_SET_RTS(UART_T *uart)
{
    uart->MODEM |= (0x1ul << (9)) | (0x1ul << (1));
}
# 462 "../../../../Library/StdDriver/inc\\uart.h"
static inline void UART_RESET_RXFIFO(UART_T *uart)
{
    volatile int32_t i32Timeout = SystemCoreClock;

    while (!(((uart)->FIFOSTS & (0x1ul << (29)) )>> (29)))
    {
        if (--i32Timeout <= 0)
        {
            break;
        }
    }

    (uart)->FIFO |= (0x1ul << (1));

    i32Timeout = SystemCoreClock;

    while (((uart)->FIFO & (0x1ul << (1))) == (0x1ul << (1)))
    {
        if (--i32Timeout <= 0)
        {
            break;
        }
    }
}
# 497 "../../../../Library/StdDriver/inc\\uart.h"
static inline void UART_RESET_TXFIFO(UART_T *uart)
{
    volatile int32_t i32Timeout = SystemCoreClock;

    while (!(((uart)->FIFOSTS & (0x1ul << (28))) >> (28)))
    {
        if (--i32Timeout <= 0)
        {
            break;
        }
    }

    (uart)->FIFO |= (0x1ul << (2));

    i32Timeout = SystemCoreClock;

    while (((uart)->FIFO & (0x1ul << (2))) == (0x1ul << (2)))
    {
        if (--i32Timeout <= 0)
        {
            break;
        }
    }
}
# 649 "../../../../Library/StdDriver/inc\\uart.h"
void UART_ClearIntFlag(UART_T *uart, uint32_t u32InterruptFlag);
void UART_Close(UART_T *uart);
void UART_DisableFlowCtrl(UART_T *uart);
void UART_DisableInt(UART_T *uart, uint32_t u32InterruptFlag);
void UART_EnableFlowCtrl(UART_T *uart);
void UART_EnableInt(UART_T *uart, uint32_t u32InterruptFlag);
void UART_Open(UART_T *uart, uint32_t u32baudrate);
uint32_t UART_Read(const UART_T *uart, uint8_t pu8RxBuf[], uint32_t u32ReadBytes);
void UART_SetLineConfig(UART_T *uart, uint32_t u32baudrate, uint32_t u32data_width, uint32_t u32parity, uint32_t u32stop_bits);
void UART_SetTimeoutCnt(UART_T *uart, uint32_t u32TOC);
void UART_SelectIrDAMode(UART_T *uart, uint32_t u32Buadrate, uint32_t u32Direction);
void UART_SelectRS485Mode(UART_T *uart, uint32_t u32Mode, uint32_t u32Addr);
void UART_SelectLINMode(UART_T *uart, uint32_t u32Mode, uint32_t u32BreakLength);
uint32_t UART_Write(UART_T *uart, const uint8_t pu8TxBuf[], uint32_t u32WriteBytes);
void UART_SelectSingleWireMode(UART_T *uart);
void UART_SetBaudRateFractionalDivider(UART_T *uart, uint32_t u32BRFD);
void UART_DisableBaudRateFractionalDivider(UART_T *uart);
# 1130 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\usbd.h" 1
# 1131 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\usci_i2c.h" 1
# 33 "../../../../Library/StdDriver/inc\\usci_i2c.h"
enum UI2C_MASTER_EVENT
{
    MASTER_SEND_ADDRESS = 10,
    MASTER_SEND_H_WR_ADDRESS,
    MASTER_SEND_H_RD_ADDRESS,
    MASTER_SEND_L_ADDRESS,
    MASTER_SEND_DATA,
    MASTER_SEND_REPEAT_START,
    MASTER_READ_DATA,
    MASTER_STOP,
    MASTER_SEND_START
};




enum UI2C_SLAVE_EVENT
{
    SLAVE_ADDRESS_ACK = 100,
    SLAVE_H_WR_ADDRESS_ACK,
    SLAVE_L_WR_ADDRESS_ACK,
    SLAVE_GET_DATA,
    SLAVE_SEND_DATA,
    SLAVE_H_RD_ADDRESS_ACK,
    SLAVE_L_RD_ADDRESS_ACK
};
# 101 "../../../../Library/StdDriver/inc\\usci_i2c.h"
extern int32_t g_UI2C_i32ErrCode;
# 283 "../../../../Library/StdDriver/inc\\usci_i2c.h"
uint32_t UI2C_Open(UI2C_T *ui2c, uint32_t u32BusClock);
void UI2C_Close(UI2C_T *ui2c);
void UI2C_ClearTimeoutFlag(UI2C_T *ui2c);
void UI2C_Trigger(UI2C_T *ui2c, uint8_t u8Start, uint8_t u8Stop, uint8_t u8Ptrg, uint8_t u8Ack);
void UI2C_DisableInt(UI2C_T *ui2c, uint32_t u32Mask);
void UI2C_EnableInt(UI2C_T *ui2c, uint32_t u32Mask);
uint32_t UI2C_GetBusClockFreq(const UI2C_T *ui2c);
uint32_t UI2C_SetBusClockFreq(UI2C_T *ui2c, uint32_t u32BusClock);
uint32_t UI2C_GetIntFlag(const UI2C_T *ui2c, uint32_t u32Mask);
void UI2C_ClearIntFlag(UI2C_T *ui2c, uint32_t u32Mask);
uint32_t UI2C_GetData(const UI2C_T *ui2c);
void UI2C_SetData(UI2C_T *ui2c, uint8_t u8Data);
void UI2C_SetSlaveAddr(UI2C_T *ui2c, uint8_t u8SlaveNo, uint16_t u16SlaveAddr, uint8_t u8GCMode);
void UI2C_SetSlaveAddrMask(UI2C_T *ui2c, uint8_t u8SlaveNo, uint16_t u16SlaveAddrMask);
void UI2C_EnableTimeout(UI2C_T *ui2c, uint32_t u32TimeoutCnt);
void UI2C_DisableTimeout(UI2C_T *ui2c);
void UI2C_EnableWakeup(UI2C_T *ui2c, uint8_t u8WakeupMode);
void UI2C_DisableWakeup(UI2C_T *ui2c);
uint8_t UI2C_WriteByte(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t data);
uint32_t UI2C_WriteMultiBytes(UI2C_T *ui2c, uint8_t u8SlaveAddr, const uint8_t *data, uint32_t u32wLen);
uint8_t UI2C_WriteByteOneReg(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, uint8_t data);
uint32_t UI2C_WriteMultiBytesOneReg(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, const uint8_t *data, uint32_t u32wLen);
uint8_t UI2C_WriteByteTwoRegs(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, uint8_t data);
uint32_t UI2C_WriteMultiBytesTwoRegs(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, const uint8_t *data, uint32_t u32wLen);
uint8_t UI2C_ReadByte(UI2C_T *ui2c, uint8_t u8SlaveAddr);
uint32_t UI2C_ReadMultiBytes(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t *rdata, uint32_t u32rLen);
uint8_t UI2C_ReadByteOneReg(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr);
uint32_t UI2C_ReadMultiBytesOneReg(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint8_t u8DataAddr, uint8_t *rdata, uint32_t u32rLen);
uint8_t UI2C_ReadByteTwoRegs(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr);
uint32_t UI2C_ReadMultiBytesTwoRegs(UI2C_T *ui2c, uint8_t u8SlaveAddr, uint16_t u16DataAddr, uint8_t *rdata, uint32_t u32rLen);
# 1132 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\usci_spi.h" 1
# 132 "../../../../Library/StdDriver/inc\\usci_spi.h"
static inline void USPI_SET_SS_HIGH(USPI_T *uspi)
{
    uint32_t u32LineCtl = uspi->LINECTL;
    uint32_t u32ProtCtl = uspi->PROTCTL & ~(0x1ul << (3));
    uint32_t u32CtlInvSet = u32LineCtl & (0x1ul << (7));

    if (u32CtlInvSet != 0UL)
    {
        uspi->PROTCTL = u32ProtCtl & ~(0x1ul << (2));
    }
    else
    {
        uspi->PROTCTL = u32ProtCtl | (0x1ul << (2));
    }
}
# 155 "../../../../Library/StdDriver/inc\\usci_spi.h"
static inline void USPI_SET_SS_LOW(USPI_T *uspi)
{
    uint32_t u32LineCtl = uspi->LINECTL;
    uint32_t u32ProtCtl = uspi->PROTCTL & ~(0x1ul << (3));
    uint32_t u32CtlInvSet = u32LineCtl & (0x1ul << (7));

    if (u32CtlInvSet != 0UL)
    {
        uspi->PROTCTL = u32ProtCtl | (0x1ul << (2));
    }
    else
    {
        uspi->PROTCTL = u32ProtCtl & ~(0x1ul << (2));
    }
}







static inline void USPI_SET_SUSPEND_CYCLE(USPI_T *uspi, uint32_t u32SuspCycle)
{
    uspi->PROTCTL = (uspi->PROTCTL & ~(0xful << (8))) |
                    ((u32SuspCycle & 0xFUL) << (8));
}
# 203 "../../../../Library/StdDriver/inc\\usci_spi.h"
static inline void USPI_SET_DATA_WIDTH(USPI_T *uspi, uint32_t u32Width)
{
    uint32_t u32WidthTmp = u32Width;

    if ((u32WidthTmp > 0UL) && (u32WidthTmp < 4UL))
    {
        u32WidthTmp = 4UL;
    }
    else if (u32WidthTmp >= 16UL)
    {
        u32WidthTmp = 0UL;
    }
    else
    {
        u32WidthTmp &= 0xFUL;
    }

    uspi->LINECTL = (uspi->LINECTL & ~(0xful << (8))) |
                    (u32WidthTmp << (8));
}
# 427 "../../../../Library/StdDriver/inc\\usci_spi.h"
uint32_t USPI_Open(USPI_T *uspi, uint32_t u32MasterSlave, uint32_t u32SPIMode, uint32_t u32DataWidth, uint32_t u32BusClock);
void USPI_Close(USPI_T *uspi);
void USPI_ClearRxBuf(USPI_T *uspi);
void USPI_ClearTxBuf(USPI_T *uspi);
void USPI_DisableAutoSS(USPI_T *uspi);
void USPI_EnableAutoSS(USPI_T *uspi, uint32_t u32SSPinMask, uint32_t u32ActiveLevel);
uint32_t USPI_SetBusClock(USPI_T *uspi, uint32_t u32BusClock);
uint32_t USPI_GetBusClock(const USPI_T *uspi);
void USPI_EnableInt(USPI_T *uspi, uint32_t u32Mask);
void USPI_DisableInt(USPI_T *uspi, uint32_t u32Mask);
uint32_t USPI_GetIntFlag(const USPI_T *uspi, uint32_t u32Mask);
void USPI_ClearIntFlag(USPI_T *uspi, uint32_t u32Mask);
uint32_t USPI_GetStatus(const USPI_T *uspi, uint32_t u32Mask);
void USPI_EnableWakeup(USPI_T *uspi);
void USPI_DisableWakeup(USPI_T *uspi);
# 1133 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\usci_uart.h" 1
# 513 "../../../../Library/StdDriver/inc\\usci_uart.h"
void UUART_ClearIntFlag(UUART_T *uuart, uint32_t u32Mask);
uint32_t UUART_GetIntFlag(const UUART_T *uuart, uint32_t u32Mask);
void UUART_Close(UUART_T *uuart);
void UUART_DisableInt(UUART_T *uuart, uint32_t u32Mask);
void UUART_EnableInt(UUART_T *uuart, uint32_t u32Mask);
uint32_t UUART_Open(UUART_T *uuart, uint32_t u32baudrate);
uint32_t UUART_Read(const UUART_T *uuart, uint8_t pu8RxBuf[], uint32_t u32ReadBytes);
uint32_t UUART_SetLine_Config(UUART_T *uuart, uint32_t u32baudrate, uint32_t u32data_width, uint32_t u32parity, uint32_t u32stop_bits);
uint32_t UUART_Write(UUART_T *uuart, const uint8_t pu8TxBuf[], uint32_t u32WriteBytes);
void UUART_EnableWakeup(UUART_T *uuart, uint32_t u32WakeupMode);
void UUART_DisableWakeup(UUART_T *uuart);
void UUART_EnableFlowCtrl(UUART_T *uuart);
void UUART_DisableFlowCtrl(UUART_T *uuart);
# 1134 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\wdt.h" 1
# 157 "../../../../Library/StdDriver/inc\\wdt.h"
static inline void WDT_Close(WDT_T *wdt);
static inline void WDT_EnableInt(WDT_T *wdt);
static inline void WDT_DisableInt(WDT_T *wdt);
# 169 "../../../../Library/StdDriver/inc\\wdt.h"
static inline void WDT_Close(WDT_T *wdt)
{
    uint32_t u32TimeOutCnt = SystemCoreClock;

    wdt->CTL = 0UL;

    while (wdt->CTL & (0x1ul << (30)))
    {
        if (--u32TimeOutCnt == 0) break;
    }

}
# 190 "../../../../Library/StdDriver/inc\\wdt.h"
static inline void WDT_EnableInt(WDT_T *wdt)
{
    wdt->CTL |= (0x1ul << (6));
}
# 203 "../../../../Library/StdDriver/inc\\wdt.h"
static inline void WDT_DisableInt(WDT_T *wdt)
{

    wdt->CTL &= ~((0x1ul << (6)));
}

int32_t WDT_Open(WDT_T *wdt, uint32_t u32TimeoutInterval, uint32_t u32ResetDelay, uint32_t u32EnableReset, uint32_t u32EnableWakeup);
# 1135 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 1 "../../../../Library/StdDriver/inc\\wwdt.h" 1
# 136 "../../../../Library/StdDriver/inc\\wwdt.h"
void WWDT_Open(WWDT_T *wwdt, uint32_t u32PreScale, uint32_t u32CmpValue, uint32_t u32EnableInt);
# 1136 "../../../../Library/Device/Nuvoton/M3351/Include\\M3351.h" 2
# 15 "../../../../Library/Device/Nuvoton/M3351/Include\\NuMicro.h" 2
# 14 "../Platform\\Platform_HAL_NUC1262.h" 2
# 1 "../LED\\LED_Control.h" 1
# 12 "../LED\\LED_Control.h"
# 1 "..\\device.h" 1
# 13 "../LED\\LED_Control.h" 2
# 1 "../LED\\Dynamic_Lighting.h" 1
# 13 "../LED\\Dynamic_Lighting.h"
struct LED_Setting_Tag;
# 35 "../LED\\Dynamic_Lighting.h"
enum {
    Index_BoundingBoxWidth = 0,
    Index_BoundingBoxHeight = 1,
    Index_BoundingBoxDepth = 2,
    Index_LampArrayKind = 3,
    Index_MinUpdateInterval = 4,
};



enum {
    PositionXInMicrometers = 0,
    PositionYInMicrometers = 1,
    PositionZInMicrometers = 2,
    Index_UpdateLatency = 3,
    Index_LampPurposes = 4,
};
# 74 "../LED\\Dynamic_Lighting.h"
typedef struct Lamp_RGBI_Tag
{
    uint8_t RedUpdate;
    uint8_t GreenUpdate;
    uint8_t BlueUpdate;
    uint8_t IntensityUpdate;
} Lamp_RGBI_T;
# 14 "../LED\\LED_Control.h" 2








extern uint32_t TimeCounterFrameUpdate;
extern uint8_t LED_Frame_Update_flag;


extern void * const Mode_Function[11];
extern const char Mode_String[11][10];

extern const char Music_String[3][10];


struct LED_Setting_Tag;
typedef void (*LED_FUNC)(volatile struct LED_Setting_Tag* LED_Setting);
typedef struct LED_Setting_Tag
{
    uint32_t TimeCounter;
    uint8_t AP_Sync;
    uint16_t LEDNum;
    uint8_t LightingMode;
    uint8_t Color_R;
    uint8_t Color_G;
    uint8_t Color_B;
    uint8_t Brightness;
    uint8_t Speed;
    uint8_t Direction;
    uint8_t LED_Type;
    uint8_t fPDMA_Done;
    uint8_t RandomFlag;
    uint32_t Random;
    LED_FUNC Mode_FUNC;
    uint8_t* LED_Data;
    uint8_t Main_Volume;
    uint8_t Left_Volume;
    uint8_t Right_Volume;
    uint8_t Music_Action;
    uint32_t Array_Size;
    uint16_t LED_Offset;
    uint8_t ColorIndex;
    uint8_t Sequence;

    uint8_t Dynamic_Update_Flag;
    uint16_t Target_LampID;
    uint8_t Autonomous_Flag;
    Lamp_RGBI_T* DynamicData;
} LED_Setting_T;






extern __attribute__((aligned (4))) uint8_t LEDData_Strip_A[(10*3)];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_A[10];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_A;


extern __attribute__((aligned (4))) uint8_t LEDData_Strip_B[(10*3)];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_B[10];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_B;


extern __attribute__((aligned (4))) uint8_t LEDData_Strip_C[(10*3)];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_C[10];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_C;


extern __attribute__((aligned (4))) uint8_t LEDDataStrip_D[(10*3)];
extern __attribute__((aligned (4))) Lamp_RGBI_T DynamicData_Strip_D[10];
extern __attribute__((aligned (4))) volatile LED_Setting_T LEDSetting_Strip_D;

extern uint8_t *LED_Data_Array_Mapping[4];
extern const uint32_t LED_Data_Array_Size[4];
extern const uint16_t LED_Number_Limit[4];
extern volatile LED_Setting_T *LED_Mapping[4];


enum eLightingMode
{
    eMode_Off = 0x00,
    eMode_Static = 0x01,
    eMode_Breathing = 0x02,
    eMode_Strobe = 0x03,
    eMode_Cycling = 0x04,
    eMode_Random = 0x05,
    eMode_Music = 0x06,
    eMode_Wave = 0x07,
    eMode_Spring = 0x08,
    eMode_Water = 0x09,
    eMode_Rainbow = 0x0A,
};

enum eDirection
{
    eDir_Forward = 0x00,
    eDir_Backward = 0x01,
};

enum eMusicAction
{
    eMusic_POP = 0x01,
    eMusic_JAZZ = 0x02,
    eMusic_Mixed = 0x03,
};

enum eLEDType
{
    eType_GRB = 0x00,
    eType_RGB = 0x01,
};

enum eColorTable
{
    eColorRed = 0,
    eColorOrange = 1,
    eColorYellow = 2,
    eColorGreen = 3,
    eColorCyan = 4,
    eColorBlue = 5,
    eColorIndigo = 6,
    eColorPurple = 7,
};
# 156 "../LED\\LED_Control.h"
void ARGB_Port_Initial(uint8_t port);
void PDMA_Initial(uint8_t port);
void Set_Single(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t Data_R, uint8_t Data_G, uint8_t Data_B);
void Set_Array(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright);
void Set_InverseArray(uint8_t *LED_DATA, uint32_t TotalLED, uint32_t Offset, uint8_t *DisplayData, uint8_t MaxBright);
void Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);
void Clear_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);


void FUNC_Off(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Static(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Breathing(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Cycling(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Random(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Strobe(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Music(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Wave(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Spring(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Water(volatile struct LED_Setting_Tag* LED_Setting);
void FUNC_Rainbow(volatile struct LED_Setting_Tag* LED_Setting);
# 15 "../Platform\\Platform_HAL_NUC1262.h" 2
# 71 "../Platform\\Platform_HAL_NUC1262.h"
typedef struct
{
    volatile uint32_t *MFP_Reg;
    uint32_t MFP_Msk;
    uint32_t MFP_Val;
} LED_IO_SETTING;
extern const LED_IO_SETTING LED_IO_Setting[4];
typedef struct
{
    uint32_t CLK_Module;
    uint8_t Module_Num;
    uint8_t PDMA_Num;
} LED_MODULE_SETTING;
extern const LED_MODULE_SETTING LED_Module_Setting[4];


void HAL_ARGB_Port_Initial(uint8_t port);
void HAL_PDMA_Initial(uint8_t port);
void HAL_Set_LED_Data(volatile struct LED_Setting_Tag* LED_Setting);
void HAL_Change_LED_Type(volatile struct LED_Setting_Tag* LED_Setting);
# 140 "../Platform\\Platform_HAL_NUC1262.h"
void HAL_Button1_Action(void);
void HAL_Button2_Action(void);
void HAL_Button3_Action(void);
void HAL_Button4_Action(void);
# 12 "../Platform\\Platform_HAL.h" 2
# 14 "../USB/hid_transfer.c" 2


# 1 "../Flash\\Flash.h" 1
# 24 "../Flash\\Flash.h"
typedef struct
{
    uint8_t AP_Sync;
    uint8_t LightingMode;
    uint16_t LED_Nums;
} FLASH1_T;







typedef struct
{
    uint8_t Color_R;
    uint8_t Color_G;
    uint8_t Color_B;
    uint8_t Brightness;
} FLASH2_T;
# 53 "../Flash\\Flash.h"
typedef struct
{
    uint8_t Speed;
    uint8_t Direction;
    uint8_t Reserve;
    uint8_t LED_Type;
} FLASH3_T;







typedef struct
{
    uint8_t Reserve1;
    uint8_t Reserve2;
    uint8_t Reserve3;
    uint8_t Reserve4;
} FLASH4_T;

extern volatile uint8_t WriteSetting_Flag;

void ReadStoredSetting(void);
void WriteNewSetting(void);
void WriteDefaultSetting(void);
# 17 "../USB/hid_transfer.c" 2
# 1 "../Platform\\Platform_usbd.h" 1
# 26 "../Platform\\Platform_usbd.h"
typedef struct s_usbd_info
{
    const uint8_t *gu8DevDesc;
    const uint8_t *gu8ConfigDesc;
    const uint8_t **gu8StringDesc;
    const uint8_t **gu8HidReportDesc;
    const uint32_t *gu32HidReportSize;
    const uint32_t *gu32ConfigHidDescIdx;
    const uint8_t *gu8BosDesc;
} S_USBD_INFO_T;

extern const S_USBD_INFO_T gsInfo;





extern volatile uint32_t g_u32DefaultTrim;
# 543 "../Platform\\Platform_usbd.h"
static inline void USBD_MemCopy(uint8_t *dest, uint8_t *src, int32_t size)
{
    while(size--) *dest++ = *src++;
}
# 559 "../Platform\\Platform_usbd.h"
static inline void USBD_SetStall(uint8_t epnum)
{
    uint32_t u32CfgAddr;
    uint32_t u32Cfg;
    int i;

    for(i = 0; i < 23ul; i++)
    {
        u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG;
        u32Cfg = *((volatile uint32_t *)(u32CfgAddr));

        if((u32Cfg & 0xf) == epnum)
        {
            u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFGP;
            u32Cfg = *((volatile uint32_t *)(u32CfgAddr));

            *((volatile uint32_t *)(u32CfgAddr)) = (u32Cfg | (0x1ul << (1)));
            break;
        }
    }
}
# 590 "../Platform\\Platform_usbd.h"
static inline void USBD_ClearStall(uint8_t epnum)
{
    uint32_t u32CfgAddr;
    uint32_t u32Cfg;
    int i;

    for(i = 0; i < 23ul; i++)
    {
        u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG;
        u32Cfg = *((volatile uint32_t *)(u32CfgAddr));

        if((u32Cfg & 0xf) == epnum)
        {
            u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFGP;
            u32Cfg = *((volatile uint32_t *)(u32CfgAddr));

            *((volatile uint32_t *)(u32CfgAddr)) = (u32Cfg & ~(0x1ul << (1)));
            break;
        }
    }
}
# 623 "../Platform\\Platform_usbd.h"
static inline uint32_t USBD_GetStall(uint8_t epnum)
{
    uint32_t u32CfgAddr;
    uint32_t u32Cfg;
    int i;

    for(i = 0; i < 23ul; i++)
    {
        u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG;
        u32Cfg = *((volatile uint32_t *)(u32CfgAddr));

        if((u32Cfg & 0xf) == epnum)
        {
            u32CfgAddr = (uint32_t)(i << 4) + (uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFGP;
            break;
        }
    }

    return ((*((volatile uint32_t *)(u32CfgAddr))) & (0x1ul << (1)));
}


extern volatile uint8_t g_usbd_RemoteWakeupEn;


typedef void (*VENDOR_REQ)(void);
typedef void (*CLASS_REQ)(void);
typedef void (*SET_INTERFACE_REQ)(void);
typedef void (*SET_CONFIG_CB)(void);



void USBD_Open(const S_USBD_INFO_T *param, CLASS_REQ pfnClassReq, SET_INTERFACE_REQ pfnSetInterface);
void USBD_Start(void);
void USBD_GetSetupPacket(uint8_t *buf);
void USBD_ProcessSetupPacket(void);
void USBD_StandardRequest(void);
void USBD_PrepareCtrlIn(uint8_t *pu8Buf, uint32_t u32Size);
void USBD_CtrlIn(void);
void USBD_PrepareCtrlOut(uint8_t *pu8Buf, uint32_t u32Size);
void USBD_CtrlOut(void);
void USBD_SwReset(void);
void USBD_SetVendorRequest(VENDOR_REQ pfnVendorReq);
void USBD_SetConfigCallback(SET_CONFIG_CB pfnSetConfigCallback);
void USBD_LockEpStall(uint32_t u32EpBitmap);
void USB_trim(void);
# 18 "../USB/hid_transfer.c" 2
# 1 "../USB\\hid_transfer.h" 1
# 13 "../USB\\hid_transfer.h"
# 1 "..\\device.h" 1
# 14 "../USB\\hid_transfer.h" 2
# 92 "../USB\\hid_transfer.h"
extern uint8_t RcvBuffer[512];
extern volatile uint8_t set_report_flag;
# 132 "../USB\\hid_transfer.h"
extern const uint32_t LampArrayAttributes[4][5];

extern const uint32_t LampAttributesReponse[4][5];
# 171 "../USB\\hid_transfer.h"
void HID_Init(void);
void HID_ClassRequest(void);

void EP2_Handler(void);
void EP3_Handler(void);
void HID_SetInReport(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Get_General_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Get_LEDSetStrip_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
void HID_Set_LEDMode_CMD(uint8_t *pu8EpBuf, uint32_t u32Size);
int Check_Repeat(uint16_t *src, uint8_t size);
# 19 "../USB/hid_transfer.c" 2
# 1 "../OLED\\OLED_Control.h" 1
# 14 "../OLED\\OLED_Control.h"
# 1 "../OLED\\ssd1306.h" 1
# 11 "../OLED\\ssd1306.h"
# 1 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stddef.h" 1 3
# 38 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stddef.h" 3
  typedef signed int ptrdiff_t;
# 71 "C:\\Users\\scli2\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stddef.h" 3
      typedef unsigned short wchar_t;
# 12 "../OLED\\ssd1306.h" 2
# 1 "../OLED\\ssd1306_conf.h" 1
# 13 "../OLED\\ssd1306.h" 2
# 1 "../OLED\\ssd1306_fonts.h" 1







typedef struct __attribute__((packed,aligned(4))) {
 const uint8_t FontWidth;
 const uint8_t FontHeight;
 const uint16_t *data;
} FontDef;


extern FontDef Font_6x8;


extern FontDef Font_7x10;


extern FontDef Font_11x18;


extern FontDef Font_16x26;
# 14 "../OLED\\ssd1306.h" 2
# 60 "../OLED\\ssd1306.h"
typedef enum {
    Black = 0x00,
    White = 0x01
} SSD1306_COLOR;

typedef enum {
    SSD1306_OK = 0x00,
    SSD1306_ERR = 0x01
} SSD1306_Error_t;


typedef struct {
    uint16_t CurrentX;
    uint16_t CurrentY;
    uint8_t Inverted;
    uint8_t Initialized;
    uint8_t DisplayOn;
} SSD1306_t;
typedef struct {
    uint8_t x;
    uint8_t y;
} SSD1306_VERTEX;


void ssd1306_Init(void);
void ssd1306_Fill(SSD1306_COLOR color);
void ssd1306_UpdateScreen(void);
void ssd1306_DrawPixel(uint8_t x, uint8_t y, SSD1306_COLOR color);
char ssd1306_WriteChar(char ch, FontDef Font, SSD1306_COLOR color);
char ssd1306_WriteString(char* str, FontDef Font, SSD1306_COLOR color);
void ssd1306_SetCursor(uint8_t x, uint8_t y);
void ssd1306_Line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, SSD1306_COLOR color);
void ssd1306_DrawArc(uint8_t x, uint8_t y, uint8_t radius, uint16_t start_angle, uint16_t sweep, SSD1306_COLOR color);
void ssd1306_DrawCircle(uint8_t par_x, uint8_t par_y, uint8_t par_r, SSD1306_COLOR color);
void ssd1306_Polyline(const SSD1306_VERTEX *par_vertex, uint16_t par_size, SSD1306_COLOR color);
void ssd1306_DrawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, SSD1306_COLOR color);






void ssd1306_SetContrast(const uint8_t value);




void ssd1306_SetDisplayOn(const uint8_t on);





uint8_t ssd1306_GetDisplayOn(void);


void ssd1306_Reset(void);
void ssd1306_WriteCommand(uint8_t byte);
void ssd1306_WriteData(uint8_t* buffer, size_t buff_size);
SSD1306_Error_t ssd1306_FillBuffer(uint8_t* buf, uint32_t len);
# 15 "../OLED\\OLED_Control.h" 2
# 1 "../OLED\\ssd1306_fonts.h" 1
# 16 "../OLED\\OLED_Control.h" 2
# 1 "../OLED\\hal_tick_control.h" 1
extern uint32_t HAL_GetTick(void);
extern void HAL_Delay( uint32_t Delay);
extern void HAL_InitTick(uint32_t TickPriority);
# 17 "../OLED\\OLED_Control.h" 2



extern uint32_t TimeCounterOLEDUpdate;
extern uint8_t OLED_Panel_Update_flag;
# 34 "../OLED\\OLED_Control.h"
extern const uint8_t START_POSITION_Y[4];

void OLED_Initial(void);
void OLED_Show_LightingMode(void);
# 20 "../USB/hid_transfer.c" 2

uint8_t SendBuffer[512];
uint8_t RcvBuffer[512];

volatile uint8_t set_report_flag = 0;
extern volatile uint32_t g_usbd_CtrlOutSize;
extern volatile uint32_t g_usbd_CtrlOutSizeLimit;

uint8_t g_u8Idle = 0, g_u8Protocol = 0;


const uint32_t LampArrayAttributes[4][5]
    = {
       {137500,
        63000,
        0,
        0x05,
        (25*1000)},
       {137500,
        63000,
        0,
        0x05,
        (25*1000)},
       {137500,
        63000,
        0,
        0x05,
        (25*1000)},
       {137500,
        63000,
        0,
        0x05,
        (25*1000)},
      };


const uint32_t LampAttributesReponse[4][5]
    = {
       {101250,
        8500,
        0,
        1000,
        0x02},
       {101250,
        20500,
        0,
        1000,
        0x02},
       {101250,
        32500,
        0,
        1000,
        0x02},
       {101250,
        44500,
        0,
        1000,
        0x02},
      };
const uint32_t LampAttributesPosition[4][3]
    = {
       {(-10000),
        0,
        0},
       {(-10000),
        0,
        0},
       {(-10000),
        0,
        0},
       {(-10000),
        0,
        0},
      };

void USBD_IRQHandler(void)
{
    uint32_t u32IntSts = ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS));
    uint32_t u32State = ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR & 0xf));


    if (u32IntSts & (0x1ul << (2)))
    {

        (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (2))));

        if (((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->VBUSDET & (0x1ul << (0)))))
        {

            ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR |= ((0x1ul << (7))|(0x1ul << (4)))));
        }
        else
        {

            ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR &= ~(0x1ul << (7))));

            for(uint8_t i = 0; i < 4; i++)
            {

                LED_Mapping[i]->Autonomous_Flag = (1UL);
            }
        }
    }


    if (u32IntSts & (0x1ul << (0)))
    {

        (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (0))));

        if (u32State & (0x1ul << (0)))
        {

            ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR |= ((0x1ul << (7))|(0x1ul << (4)))));
            USBD_SwReset();
        }

        if (u32State & (0x1ul << (1)))
        {

            ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR &= ~(0x1ul << (4))));
        }

        if (u32State & (0x1ul << (2)))
        {

            ((uint32_t)(((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->ATTR |= ((0x1ul << (7))|(0x1ul << (4)))));
        }
    }


    if (u32IntSts & (0x1ul << (1)))
    {

        if (u32IntSts & (0x1ul << (31)))
        {


            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (31))));


            (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFGP + (uint32_t)((0) << 4))) |= (0x1ul << (0)));
            (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFGP + (uint32_t)((1) << 4))) |= (0x1ul << (0)));

            USBD_ProcessSetupPacket();
        }


        if (u32IntSts & (0x1ul << (16)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (16))));

            USBD_CtrlIn();
        }

        if (u32IntSts & (0x1ul << (17)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (17))));


            USBD_CtrlOut();

            uint8_t target_port;
            if((set_report_flag == 1) && (g_usbd_CtrlOutSize >= g_usbd_CtrlOutSizeLimit))
            {

                for(target_port = 0; target_port < 4; target_port++)
                {

                    if(RcvBuffer[0] == 0x04)
                    {

                        uint16_t u16Temp = (uint16_t)(RcvBuffer[1] | (RcvBuffer[2] << 8));


                        if(u16Temp & ((0x00000001UL) << target_port))
                        {
                            if(LED_Mapping[target_port]->AP_Sync == (1UL))
                            {
                                USBD_MemCopy(LED_Mapping[target_port]->LED_Data, &RcvBuffer[3], LED_Mapping[target_port]->LEDNum * 3);
                            }
                        }

                    }

                    else if(RcvBuffer[0] == (0x11 + (0x10*target_port)))
                    {

                        uint16_t lampid;
                        lampid = (RcvBuffer[2] << 8) | RcvBuffer[1];

                        if(lampid < LED_Number_Limit[target_port])
                            LED_Mapping[target_port]->Target_LampID = lampid;

                        break;
                    }

                    else if(RcvBuffer[0] == (0x13 + (0x10*target_port)))
                    {

                        uint8_t lampcout = RcvBuffer[1];

                        uint16_t lampid[lampcout];
                        uint8_t i;
                        for(i = 0; i < lampcout; i++)
                        {
                            lampid[i] = (RcvBuffer[4 + 2*i] << 8) | RcvBuffer[3 + 2*i];

                            if(lampid[i] >= LED_Number_Limit[target_port])
                                break;
                        }

                        if(i == lampcout)
                        {

                            if(Check_Repeat(lampid, lampcout) == 0)
                            {

                                for(i = 0; i < lampcout; i++)
                                {
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].RedUpdate = RcvBuffer[19 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].GreenUpdate = RcvBuffer[20 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].BlueUpdate = RcvBuffer[21 + 4*i];
                                    LED_Mapping[target_port]->DynamicData[lampid[i]].IntensityUpdate = RcvBuffer[22 + 4*i];
                                }


                                LED_Mapping[target_port]->Dynamic_Update_Flag = RcvBuffer[2];
                            }
                        }

                        break;
                    }

                    else if(RcvBuffer[0] == (0x14 + (0x10*target_port)))
                    {

                        uint16_t start = (RcvBuffer[3] << 8) | RcvBuffer[2];

                        uint16_t end = (RcvBuffer[5] << 8) | RcvBuffer[4];

                        if(start <= end)
                        {

                            if((start < LED_Number_Limit[target_port]) && (end < LED_Number_Limit[target_port]))
                            {
                                for(uint16_t i = start; i < (end+1); i++)
                                {
                                    LED_Mapping[target_port]->DynamicData[i].RedUpdate = RcvBuffer[6];
                                    LED_Mapping[target_port]->DynamicData[i].GreenUpdate = RcvBuffer[7];
                                    LED_Mapping[target_port]->DynamicData[i].BlueUpdate = RcvBuffer[8];
                                    LED_Mapping[target_port]->DynamicData[i].IntensityUpdate = RcvBuffer[9];
                                }


                                LED_Mapping[target_port]->Dynamic_Update_Flag = RcvBuffer[1];
                            }
                        }

                        break;
                    }

                    else if(RcvBuffer[0] == (0x15 + (0x10*target_port)))
                    {

                        LED_Mapping[target_port]->Autonomous_Flag = RcvBuffer[1];

                        break;
                    }
                }

                set_report_flag = 0;
            }
        }

        if (u32IntSts & (0x1ul << (18)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (18))));

            EP2_Handler();
        }

        if (u32IntSts & (0x1ul << (19)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (19))));

            EP3_Handler();
        }

        if (u32IntSts & (0x1ul << (20)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (20))));
        }

        if (u32IntSts & (0x1ul << (21)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (21))));
        }

        if (u32IntSts & (0x1ul << (22)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (22))));
        }

        if (u32IntSts & (0x1ul << (23)))
        {

            (((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTSTS = ((0x1ul << (23))));
        }
    }
}

void EP2_Handler(void)
{

}

void EP3_Handler(void)
{
    uint8_t *ptr;

    ptr = (uint8_t *)((((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL)+0x800ul) + ((uint32_t)*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((3) << 4)))));


    if(*ptr == 0x01)
    {
        HID_Get_General_CMD(ptr, ((uint32_t)*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((3) << 4)))));
    }
    else if(*ptr == 0x02)
    {
        HID_Get_LEDSetStrip_CMD(ptr, ((uint32_t)*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((3) << 4)))));
    }
    else if(*ptr == 0x03)
    {
        HID_Set_LEDMode_CMD(ptr, ((uint32_t)*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((3) << 4)))));
    }

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((3) << 4))) = (64));
}
# 374 "../USB/hid_transfer.c"
void HID_Init(void)
{


    ((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->STBUFSEG = 0;



    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((0) << 4))) = ((0x1ul << (9)) | (2ul << (5)) | 0));

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((0) << 4))) = ((0 + 8)));


    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((1) << 4))) = ((0x1ul << (9)) | (1ul << (5)) | 0));

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((1) << 4))) = ((0 + 8)));



    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((2) << 4))) = ((2ul << (5)) | 0x01));

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((2) << 4))) = (((0 + 8) + 8)));


    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((3) << 4))) = ((1ul << (5)) | 0x02));

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((3) << 4))) = ((((0 + 8) + 8) + 64)));

    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((3) << 4))) = (64));

}

uint8_t g_SendLen;
int32_t HID_CtrlSetupGetReport(void)
{
    uint8_t buf[8];
    uint16_t len;
    uint8_t i;
    uint8_t target_port;

    USBD_MemCopy(buf, (uint8_t *)(((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL)+0x800ul), 8);


    for(target_port = 0; target_port < 4; target_port++)
    {

        if(buf[2] == (0x10 + (0x10*target_port)))
        {

            SendBuffer[0] = 0x10 + (0x10*target_port);

            SendBuffer[1] = (uint8_t)((LED_Number_Limit[target_port] & 0x00FF) );
            SendBuffer[2] = (uint8_t)((LED_Number_Limit[target_port] & 0xFF00) >> 8);

            SendBuffer[3] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x000000FF) );
            SendBuffer[4] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x0000FF00) >> 8);
            SendBuffer[5] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0x00FF0000) >> 16);
            SendBuffer[6] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxWidth] & 0xFF000000) >> 24);

            SendBuffer[7] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x000000FF) );
            SendBuffer[8] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x0000FF00) >> 8);
            SendBuffer[9] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0x00FF0000) >> 16);
            SendBuffer[10] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxHeight] & 0xFF000000) >> 24);

            SendBuffer[11] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x000000FF) );
            SendBuffer[12] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x0000FF00) >> 8);
            SendBuffer[13] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0x00FF0000) >> 16);
            SendBuffer[14] = (uint8_t)((LampArrayAttributes[target_port][Index_BoundingBoxDepth] & 0xFF000000) >> 24);

            SendBuffer[15] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x000000FF) );
            SendBuffer[16] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x0000FF00) >> 8);
            SendBuffer[17] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0x00FF0000) >> 16);
            SendBuffer[18] = (uint8_t)((LampArrayAttributes[target_port][Index_LampArrayKind] & 0xFF000000) >> 24);

            SendBuffer[19] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x000000FF) );
            SendBuffer[20] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x0000FF00) >> 8);
            SendBuffer[21] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0x00FF0000) >> 16);
            SendBuffer[22] = (uint8_t)((LampArrayAttributes[target_port][Index_MinUpdateInterval] & 0xFF000000) >> 24);

            g_SendLen = 23;

            break;
        }

        else if(buf[2] == (0x12 + (0x10*target_port)))
        {

            SendBuffer[0] = 0x12 + (0x10*target_port);

            SendBuffer[1] = (uint8_t)((LED_Mapping[target_port]->Target_LampID & 0x00FF) );
            SendBuffer[2] = (uint8_t)((LED_Mapping[target_port]->Target_LampID & 0xFF00) >> 8);

            uint32_t position;
            position = LampAttributesReponse[target_port][PositionXInMicrometers] + LampAttributesPosition[target_port][PositionXInMicrometers]*LED_Mapping[target_port]->Target_LampID;

            SendBuffer[3] = (uint8_t)((position & 0x000000FF) );
            SendBuffer[4] = (uint8_t)((position & 0x0000FF00) >> 8);
            SendBuffer[5] = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[6] = (uint8_t)((position & 0xFF000000) >> 24);

            position = LampAttributesReponse[target_port][PositionYInMicrometers] + LampAttributesPosition[target_port][PositionYInMicrometers]*LED_Mapping[target_port]->Target_LampID;

            SendBuffer[7] = (uint8_t)((position & 0x000000FF) );
            SendBuffer[8] = (uint8_t)((position & 0x0000FF00) >> 8);
            SendBuffer[9] = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[10] = (uint8_t)((position & 0xFF000000) >> 24);

            position = LampAttributesReponse[target_port][PositionZInMicrometers] + LampAttributesPosition[target_port][PositionZInMicrometers]*LED_Mapping[target_port]->Target_LampID;

            SendBuffer[11] = (uint8_t)((position & 0x000000FF) );
            SendBuffer[12] = (uint8_t)((position & 0x0000FF00) >> 8);
            SendBuffer[13] = (uint8_t)((position & 0x00FF0000) >> 16);
            SendBuffer[14] = (uint8_t)((position & 0xFF000000) >> 24);

            SendBuffer[15] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x000000FF) );
            SendBuffer[16] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x0000FF00) >> 8);
            SendBuffer[17] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0x00FF0000) >> 16);
            SendBuffer[18] = (uint8_t)((LampAttributesReponse[target_port][Index_UpdateLatency] & 0xFF000000) >> 24);

            SendBuffer[19] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x000000FF) );
            SendBuffer[20] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x0000FF00) >> 8);
            SendBuffer[21] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0x00FF0000) >> 16);
            SendBuffer[22] = (uint8_t)((LampAttributesReponse[target_port][Index_LampPurposes] & 0xFF000000) >> 24);

            SendBuffer[23] = 255;

            SendBuffer[24] = 255;

            SendBuffer[25] = 255;

            SendBuffer[26] = 255;

            SendBuffer[27] = 0x01;

            SendBuffer[28] = 0x00;


            LED_Mapping[target_port]->Target_LampID += 1;
            if(LED_Mapping[target_port]->Target_LampID == LED_Number_Limit[target_port])
                LED_Mapping[target_port]->Target_LampID = 0;

            g_SendLen = 29;

            break;
        }
    }


    if(target_port == 4)
    {
        USBD_SetStall(0);
        USBD_SetStall(1);
        return (0UL);
    }

    len = (buf[7] << 8) | buf[6];
    if(len >= g_SendLen)
        len = g_SendLen;

    USBD_PrepareCtrlIn((uint8_t *)&SendBuffer[0], len);
    USBD_PrepareCtrlOut(0,0);

    return (1UL);
}

int32_t HID_CtrlSetupSetReport(void)
{
    uint8_t buf[8];
    uint8_t report_type;
    uint32_t u32Len;

    USBD_MemCopy(buf, (uint8_t *)(((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL)+0x800ul), 8);
    report_type= buf[3];
    u32Len = (buf[7] << 8) | buf[6];

    if (report_type == 1)
    {


        (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((1) << 4))) |= (0x1ul << (7)));
        (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((1) << 4))) = (0));


    }
    else if (report_type == 2)
    {

        USBD_PrepareCtrlOut((uint8_t *)&RcvBuffer, u32Len);
        USBD_PrepareCtrlIn(0,0);


    }
    else if (report_type == 3)
    {



        USBD_PrepareCtrlOut((uint8_t *)&RcvBuffer, u32Len);
        USBD_PrepareCtrlIn(0,0);

        set_report_flag = 1;

    }
    else
    {

        USBD_SetStall(0);
        USBD_SetStall(1);


    }

    return (1UL);
}

void HID_ClassRequest(void)
{
    uint8_t u8Buf[8];

    USBD_GetSetupPacket(u8Buf);

    if (u8Buf[0] & 0x80)
    {

        switch (u8Buf[1])
        {
            case 0x01:
            {
                HID_CtrlSetupGetReport();
                break;
            }
            case 0x02:
            {
                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((1) << 4))) = (u8Buf[6]));

                USBD_PrepareCtrlIn(&g_u8Idle, u8Buf[6]);

                USBD_PrepareCtrlOut(0, 0);
                break;
            }
            case 0x03:
            {
                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((1) << 4))) = (u8Buf[6]));

                USBD_PrepareCtrlIn(&g_u8Protocol, u8Buf[6]);

                USBD_PrepareCtrlOut(0, 0);
                break;
            }
            default:
            {

                USBD_SetStall(0);
                USBD_SetStall(1);
                break;
            }
        }
    }
    else
    {

        switch (u8Buf[1])
        {
            case 0x09:
            {
                HID_CtrlSetupSetReport();
                break;
            }

            case 0x0A:
            {
                g_u8Idle = u8Buf[3];

                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((0) << 4))) |= (0x1ul << (7)));
                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((0) << 4))) = (0));
                break;
            }
            case 0x0B:
            {
                g_u8Protocol = u8Buf[2];

                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].CFG + (uint32_t)((0) << 4))) |= (0x1ul << (7)));
                (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((0) << 4))) = (0));
                break;
            }
            default:
            {


                USBD_SetStall(0);
                USBD_SetStall(1);
                break;
            }
        }
    }
}


void HID_SetInReport(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t *ptr;


    ptr = (uint8_t *)((((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL)+0x800ul) + ((uint32_t)*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].BUFSEG + (uint32_t)((2) << 4)))));
    USBD_MemCopy(ptr, pu8EpBuf, u32Size);
    (*((volatile uint32_t *) ((uint32_t)&((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->EP[0].MXPLD + (uint32_t)((2) << 4))) = (u32Size));
}

void HID_Get_General_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t u8Command;
    uint8_t ReplyBuf[16];
    uint32_t Checksum;
    uint8_t Area;
    uint8_t i;


    u8Command = pu8EpBuf[1];

    switch(u8Command)
    {
        case 0xA0:
        {

            ReplyBuf[0] = 0x01;

            ReplyBuf[1] = 0x5A;

            ReplyBuf[2] = 0x01;

            ReplyBuf[3] = 0x04;

            for(i = 4; i < 16; i++)
                ReplyBuf[i] = 0x00;


            HID_SetInReport(ReplyBuf, 16);

            break;
        }
        case 0xA1:
        {

            SYS_UnlockReg();
            FMC_Open();
            (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCTL |= (0x1UL << (3)));
            Checksum = FMC_Read(((0x00000000UL + (0x00080000UL * 2)) - (0x2000UL * 1)) + (-4));
            (((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCTL &= ~(0x1UL << (3)));
            FMC_Close();
            SYS_LockReg();


            ReplyBuf[0] = 0x01;

            ReplyBuf[1] = 0x5A;

            ReplyBuf[2] = (uint8_t)((Checksum >> 0) & 0xFF);

            ReplyBuf[3] = (uint8_t)((Checksum >> 8) & 0xFF);

            for(i = 4; i < 16; i++)
                ReplyBuf[i] = 0x00;


            HID_SetInReport(ReplyBuf, 16);

            break;
        }
        case 0xB0:
        {

            __NVIC_SetPriority(USBD_IRQn, 3);



            for(i = 0; i < 4; i++)
                while(LED_Mapping[i]->fPDMA_Done == 0);

            for(i = 0; i < 4; i++)
            {
                Clear_LED_Data(LED_Mapping[i]);
            }
            for(i = 0; i < 4; i++)
                while(!LED_Mapping[i]->fPDMA_Done);


            ssd1306_Fill(Black);
            ssd1306_SetCursor(2, START_POSITION_Y[1]);
            ssd1306_WriteString("Updating FW...", Font_7x10, White);
            ssd1306_UpdateScreen();


            __NVIC_SetPriority(USBD_IRQn, 2);
            ((USBD_T *) ((((uint32_t) 0x40000000UL) + 0x00040000UL) + 0x80000UL))->INTEN &= ~((0x1ul << (4)) | (0x1ul << (8)));


            SYS_UnlockReg();
            FMC_Open();
            ((FMC_T *) ((((uint32_t) 0x40000000UL) + 0x00000000UL) + 0x0C000UL))->ISPCTL |= (0x1UL << (1));
            ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ICPR[0] = 0xFFFFFFFF;

            FMC_SetVectorPageAddr(0x0F100000UL);
            SYS_ResetCPU();

            break;
        }
        case 0xC0:
        {

            for(i = 0; i < 4; i++)
            {

                LED_Mapping[i]->Main_Volume = pu8EpBuf[2];

                LED_Mapping[i]->Left_Volume = pu8EpBuf[3];

                LED_Mapping[i]->Right_Volume = pu8EpBuf[4];

                LED_Mapping[i]->Music_Action = pu8EpBuf[5];
            }

            break;
        }
    }
}

void HID_Get_LEDSetStrip_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t i;
    uint16_t Area;


    Area = (uint16_t)(pu8EpBuf[1] | (pu8EpBuf[2] << 8));


    for(i = 0; i < 4; i++)
    {
        if(Area & (1 << i))
        {

            LED_Mapping[i]->LEDNum = (uint16_t)(pu8EpBuf[3] | (pu8EpBuf[4] << 8));
            if(LED_Mapping[i]->LEDNum > LED_Number_Limit[i])
                LED_Mapping[i]->LEDNum = LED_Number_Limit[i];

            LED_Mapping[i]->LED_Type = pu8EpBuf[5];

            HAL_Change_LED_Type(LED_Mapping[i]);

            LED_Mapping[i]->Direction = pu8EpBuf[6];

            LED_Mapping[i]->AP_Sync = pu8EpBuf[7];
            if(LED_Mapping[i]->AP_Sync)
            {
                memset((void *)LED_Mapping[i]->LED_Data, 0x00, LED_Mapping[i]->Array_Size);
            }


            WriteSetting_Flag = 1;


            LED_Mapping[i]->TimeCounter = 0;
        }
    }
}

void HID_Set_LEDMode_CMD(uint8_t *pu8EpBuf, uint32_t u32Size)
{
    uint8_t i;
    uint16_t Area;


    Area = (uint16_t)(pu8EpBuf[1] | (pu8EpBuf[2] << 8));


    for(i = 0; i < 4; i++)
    {
        if(Area & (1 << i))
        {

            LED_Mapping[i]->LightingMode = pu8EpBuf[3];
            if(LED_Mapping[i]->LightingMode >= 11)
                LED_Mapping[i]->LightingMode = 0;
            LED_Mapping[i]->Mode_FUNC = (LED_FUNC)Mode_Function[LED_Mapping[i]->LightingMode];

            LED_Mapping[i]->Color_R = pu8EpBuf[4];
            LED_Mapping[i]->Color_G = pu8EpBuf[5];
            LED_Mapping[i]->Color_B = pu8EpBuf[6];

            LED_Mapping[i]->Brightness = pu8EpBuf[7];

            LED_Mapping[i]->Speed = pu8EpBuf[8];


            WriteSetting_Flag = 1;


            LED_Mapping[i]->TimeCounter = 0;

            LED_Mapping[i]->ColorIndex = eColorRed;
        }
    }
}

int Check_Repeat(uint16_t *src, uint8_t size)
{
    uint8_t i, j;

    for(i = 0; i < size-1; i++)
    {
        for(j = i+1; j < size; j++)
        {
            if(src[i] == src[j])
                return 1;
        }
    }

    return 0;
}
