/******************************************************************************
 * @file     device.h
 * @brief    device header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

/*!<Define LED Area */
#define TOTAL_LED_AREA      4
#define NUM_STRIP_LED_EVB   10
/* Strip A */
#define SEQUENCE_STRIP_A    1
#define NUM_LED_STRIP_A     NUM_STRIP_LED_EVB
/* Strip B */
#define SEQUENCE_STRIP_B    2
#define NUM_LED_STRIP_B     NUM_STRIP_LED_EVB
/* Strip C */
#define SEQUENCE_STRIP_C    3
#define NUM_LED_STRIP_C     NUM_STRIP_LED_EVB
/* Strip D */
#define SEQUENCE_STRIP_D    4
#define NUM_LED_STRIP_D     NUM_STRIP_LED_EVB

/*!<Define Dynamic Lighting Attributes */
/* Strip A */
#define WIDTH_MICROMETER_STRIP_A     137500
#define HEIGHT_MICROMETER_STRIP_A    63000
#define DEPTH_MICROMETER_STRIP_A     0
#define LAMPARRAYKIND_STRIP_A        LAMPARRAYKIND_SCENE
#define LAMPPURPOSE_STRIP_A          LAMPPURPOSE_ACCENT
#define POSITION_START_X_STRIP_A     101250
#define POSITION_OFFSET_X_STRIP_A    (-10000)
#define POSITION_START_Y_STRIP_A     8500
#define POSITION_OFFSET_Y_STRIP_A    0
#define POSITION_START_Z_STRIP_A     0
#define POSITION_OFFSET_Z_STRIP_A    0
/* Strip B */
#define WIDTH_MICROMETER_STRIP_B     137500
#define HEIGHT_MICROMETER_STRIP_B    63000
#define DEPTH_MICROMETER_STRIP_B     0
#define LAMPARRAYKIND_STRIP_B        LAMPARRAYKIND_SCENE
#define LAMPPURPOSE_STRIP_B          LAMPPURPOSE_ACCENT
#define POSITION_START_X_STRIP_B     101250
#define POSITION_OFFSET_X_STRIP_B    (-10000)
#define POSITION_START_Y_STRIP_B     20500
#define POSITION_OFFSET_Y_STRIP_B    0
#define POSITION_START_Z_STRIP_B     0
#define POSITION_OFFSET_Z_STRIP_B    0
/* Strip C */
#define WIDTH_MICROMETER_STRIP_C     137500
#define HEIGHT_MICROMETER_STRIP_C    63000
#define DEPTH_MICROMETER_STRIP_C     0
#define LAMPARRAYKIND_STRIP_C        LAMPARRAYKIND_SCENE
#define LAMPPURPOSE_STRIP_C          LAMPPURPOSE_ACCENT
#define POSITION_START_X_STRIP_C     101250
#define POSITION_OFFSET_X_STRIP_C    (-10000)
#define POSITION_START_Y_STRIP_C     32500
#define POSITION_OFFSET_Y_STRIP_C    0
#define POSITION_START_Z_STRIP_C     0
#define POSITION_OFFSET_Z_STRIP_C    0
/* Strip D */
#define WIDTH_MICROMETER_STRIP_D     137500
#define HEIGHT_MICROMETER_STRIP_D    63000
#define DEPTH_MICROMETER_STRIP_D     0
#define LAMPARRAYKIND_STRIP_D        LAMPARRAYKIND_SCENE
#define LAMPPURPOSE_STRIP_D          LAMPPURPOSE_ACCENT
#define POSITION_START_X_STRIP_D     101250
#define POSITION_OFFSET_X_STRIP_D    (-10000)
#define POSITION_START_Y_STRIP_D     44500
#define POSITION_OFFSET_Y_STRIP_D    0
#define POSITION_START_Z_STRIP_D     0
#define POSITION_OFFSET_Z_STRIP_D    0

/*!<Define FW version */
#define FW_VERSION_MAJOR      0x01
#define FW_VERSION_MINOR      0x04

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
