/******************************************************************************//**
 * @file     main.c
 * @version  V1.00
 * @brief
 *           Demonstrate how to control Gen1 ARGB LED lighting.
 *           And supports Microsoft Dynamic Lighting control.
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "device.h"
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "Platform_HDIV.h"
#include "Flash.h"
#include "LED_Control.h"
#include "Platform_usbd.h"
#include "hid_transfer.h"
#include "Button.h"
#include "OLED_Control.h"

/*--------------------------------------------------------------------------*/
void SYS_Init(void)
{
    /* Clear reset flag for safety */
    SYS->RSTSTS &= SYS->RSTSTS;

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Enable HIRC and LIRC clock (LIRC is used by the GPIO debounce for buttons) */
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk | CLK_PWRCTL_LIRCEN_Msk);

    /* Wait for HIRC and LIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk | CLK_STATUS_LIRCSTB_Msk);

    /* Set core clock to HCLK_CLK MHz */
    CLK_SetCoreClock(HCLK_CLK);

    /* Enable module clock */
    CLK_EnableModuleClock(PDMA0_MODULE);

    /* Enable GPIO port clocks (needed for button GPIO input/interrupt/debounce) */
    CLK_EnableModuleClock(GPA_MODULE);
    CLK_EnableModuleClock(GPB_MODULE);
    CLK_EnableModuleClock(GPC_MODULE);

    /* USB clock: select source/divider, enable PHY, then enable module clock (match M3351 ISP order) */
    CLK_SetModuleClock(USBD_MODULE, CLK_CLKSEL0_USBSEL_HIRC, CLK_CLKDIV0_USB(1));
    SYS->USBPHY = (SYS->USBPHY & ~SYS_USBPHY_USBROLE_Msk) | SYS_USBPHY_USBEN_Msk;
    CLK_EnableModuleClock(USBD_MODULE);

    /* Reset PDMA module */
    SYS_ResetModule(PDMA0_RST);

    /* Init HDIV (software divider on M3351) */
    HDIV_Init();

    /* Update the Variable SystemCoreClock */
    SystemCoreClockUpdate();

    /* Check setting storage (APROM last page) */
    FMC_Open();

    /* Write default setting if stored settings are not present/valid (signature mismatch) */
    if(FMC_Read(DATAFLASH_BASE_ADDR + 12) != SETTING_MAGIC)
    {
        WriteDefaultSetting();
    }
}

void SysTick_Initial(void)
{
    /* Set SysTick clock source to HCLK */
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk;

    /* Set load value to make SysTick period is 1 ms */
    SysTick->LOAD = HCLK_CLK / 1000;

    /* Clear SysTick counter */
    SysTick->VAL = 0;

    /* Enable SysTick interrupt */
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;

    /* Enable SysTick NVIC */
    NVIC_EnableIRQ(SysTick_IRQn);
    /* Change interrupt priority to normal */
    NVIC_SetPriority(SysTick_IRQn, INT_PRIORITY_NORMAL);
}

void SysTick_Handler(void)
{
   uint8_t i, j;

    /* Clear interrupt flag */
    SysTick->VAL = 0;

    /* Add LED mode counter */
    TimeCounterFrameUpdate++;
    for(i = 0; i < TOTAL_LED_AREA; i++)
        LED_Mapping[i]->TimeCounter++;

    /* Update LED frame data */
    if(TimeCounterFrameUpdate >= TIMER_FRAME_UPDATE)
    {
        LED_Frame_Update_flag = 1;
        TimeCounterFrameUpdate -= TIMER_FRAME_UPDATE;
    }

    /* Add OLED update counter */
    TimeCounterOLEDUpdate++;

    /* Update OLED panel data */
    if(TimeCounterOLEDUpdate >= TIMER_OLED_UPDATE)
    {
        OLED_Panel_Update_flag = 1;
        TimeCounterOLEDUpdate -= TIMER_OLED_UPDATE;
    }
}

uint32_t ProcessHardFault(uint32_t lr, uint32_t msp, uint32_t psp)
{
    /* It is casued by hardfault. Just process the hard fault */
    /* TODO: Implement your hardfault handle code here */

//    /* Erase current setting */
//    /* Unlock write-protected registers */
//    SYS_UnlockReg();
//    /* Enable FMC ISP function */
//    FMC_Open();
//    /* Erase Current Setting */
//    FMC_Erase(Addr_LEDSetting);
//    /* Chip reset */
//    SYS->IPRST0 |= SYS_IPRST0_CHIPRST_Msk;
//    /* Lock protected registers */
//    SYS_LockReg();
    while(1);

    return lr;
}

/*---------------------------------------------------------------------------------------------------------*/
/*  Main Function                                                                                          */
/*---------------------------------------------------------------------------------------------------------*/
int32_t main(void)
{
    uint32_t i;
    uint8_t target_port;

    /* Unlock write-protected registers */
    SYS_UnlockReg();

    /* Init system and multi-funcition I/O */
    SYS_Init();

    /* Open USB controller */
    USBD_Open(&gsInfo, HID_ClassRequest, NULL);
    /*Init Endpoint configuration for HID */
    HID_Init();
    /* Start USB device */
    USBD_Start();
    /* Enable USB device interrupt */
    NVIC_EnableIRQ(USBD_IRQn);
    /* Change interrupt priority to normal */
    NVIC_SetPriority(USBD_IRQn, INT_PRIORITY_NORMAL);

    /* Backup default trim */
    g_u32DefaultTrim = M32(TRIM_INIT);

    /* Read setting from Data Flash */
    ReadStoredSetting();

    /* Set Serial LED configuration */
    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        ARGB_Port_Initial(i);
        PDMA_Initial(i);
    }

    /* Clear Color Data */
    for(i = 0; i < TOTAL_LED_AREA; i++)
        Clear_LED_Data(LED_Mapping[i]);
    for(i = 0; i < TOTAL_LED_AREA; i++)
        while(!LED_Mapping[i]->fPDMA_Done);

    /* Initial SysTick, enable interrupt and 1000 interrupt tick per second to add counter */
    SysTick_Initial();

    /* Start SysTick */
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;

    /* Use SysTick counter as seed of random function */
    srand(SysTick->VAL);

    /* Init button setting */
    Button1_Initial();
    Button2_Initial();
    Button3_Initial();
    Button4_Initial();

    /* Init OLED control */
    OLED_Initial();
    OLED_Show_LightingMode();

    while (1)
    {
        /* Checking USB trim */
        USB_trim();

        /* Update LED Control */
        if(LED_Frame_Update_flag)
        {
            for(target_port = 0; target_port < TOTAL_LED_AREA; target_port++)
            {
                /* Check if data transmission is done */
                if(LED_Mapping[target_port]->fPDMA_Done == 1)
                {
                    /* Check Dynamic Lighting control */
                    if(LED_Mapping[target_port]->Autonomous_Flag == TRUE)
                    {
                        if(LED_Mapping[target_port]->AP_Sync == FALSE)
                        {
                            for(i = 0; i < LED_Mapping[target_port]->Array_Size; i++)
                            {
                                *(LED_Mapping[target_port]->LED_Data + i) = 0x0;
                            }

                            /* LED data */
                            LED_Mapping[target_port]->Mode_FUNC(LED_Mapping[target_port]);
                        }

                        /* Set Serial Data */
                        Set_LED_Data(LED_Mapping[target_port]);
                    }
                    else
                    {
                        /* Dynamic Lighting control */
                        if(LED_Mapping[target_port]->Dynamic_Update_Flag)
                        {
                            /* Mapping DynamicData to LED_Data */
                            for(i = 0; i < LED_Number_Limit[target_port]; i++)
                            {
                                Set_Array(LED_Mapping[target_port]->LED_Data + 3*i,
                                          1,
                                          LED_Mapping[target_port]->LED_Offset,
                                          (uint8_t *)(LED_Mapping[target_port]->DynamicData + i),
                                          LED_Mapping[target_port]->DynamicData[i].IntensityUpdate
                                         );
                            }

                            /* Set Serial Data */
                            Set_LED_Data(LED_Mapping[target_port]);
                        }
                    }
                }
            }

            /* Clear flag */
            LED_Frame_Update_flag = 0;
        }

        /* Check if get new LED setting */
        if(WriteSetting_Flag == 1)
        {
            /* Store Setting */
            WriteNewSetting();

            /* Clear flag */
            WriteSetting_Flag = 0;
        }

        /* Update OLED Panel */
        if(OLED_Panel_Update_flag)
        {
            /* Update OLED to show current lighting mode */
            OLED_Show_LightingMode();

            /* Clear flag */
            OLED_Panel_Update_flag = 0;
        }

#if (BUTTON1_EVENT_TYPE == BUTTON_TYPE_POLLING)
        /* Check Button1 */
        Button1_IRQCheck();
#endif

#if (BUTTON2_EVENT_TYPE == BUTTON_TYPE_POLLING)
        /* Check Button2 */
        Button2_IRQCheck();
#endif

#if (BUTTON3_EVENT_TYPE == BUTTON_TYPE_POLLING)
        /* Check Button3 */
        Button3_IRQCheck();
#endif

#if (BUTTON4_EVENT_TYPE == BUTTON_TYPE_POLLING)
        /* Check Button4 */
        Button4_IRQCheck();
#endif
    }
}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
