/******************************************************************************//**
 * @file     OLED_Control.c
 * @version  V1.00
 * @brief    OLED Control sample file
 *
 * @copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

 /*!<Includes */
#include <string.h>
#include "device.h"
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "LED_Control.h"
#include "OLED_Control.h"

uint32_t TimeCounterOLEDUpdate = 0;
uint8_t OLED_Panel_Update_flag = 0;

const uint8_t START_POSITION_Y[TOTAL_LED_AREA] = {START_POSITION_Y_A, START_POSITION_Y_B, START_POSITION_Y_C, START_POSITION_Y_D};

void OLED_Initial(void)
{
    /* Enable module clock */
    CLK_EnableModuleClock(I2C_MODULE);

    /* Set multi-function pins for I2C SDA and SCL */
    I2C_SDA_MFP = (I2C_SDA_MFP & ~I2C_SDA_MFP_MSK) | I2C_SDA_MFP_FUNC;
    I2C_SCL_MFP = (I2C_SCL_MFP & ~I2C_SCL_MFP_MSK) | I2C_SCL_MFP_FUNC;

    /* I2C pins enable schmitt trigger */
    I2C_SDA_PORT->SMTEN |= I2C_SDA_SMT_MSK;
    I2C_SCL_PORT->SMTEN |= I2C_SCL_SMT_MSK;

    /* Enable I2C */
    I2C_Open(I2C_PORT, I2C_BUS_FREQUENCY);

    /* Initial OLED driver */
    ssd1306_Init();
}

void OLED_Show_LightingMode(void)
{
    uint8_t i;
    char str_buffer[TOTAL_LED_AREA][MAX_CHAR_PER_LINE] = {{"A: "}, {"B: "}, {"C: "}, {"D: "}};

    ssd1306_Fill(Black);

    for(i = 0; i < TOTAL_LED_AREA; i++)
    {
        if(LED_Mapping[i]->Autonomous_Flag == FALSE)
        {
            strcat(str_buffer[i], "DynamicLighting");
        }
        else if(LED_Mapping[i]->AP_Sync == TRUE)
        {
            strcat(str_buffer[i], "AP Sync");
        }
        else
        {
            strcat(str_buffer[i],  Mode_String[LED_Mapping[i]->LightingMode]);
            if(LED_Mapping[i]->LightingMode == eMode_Music)
                strcat(str_buffer[i],  Music_String[LED_Mapping[i]->Music_Action - 1]);
        }
        ssd1306_SetCursor(START_POSITION_X, START_POSITION_Y[i]);
        ssd1306_WriteString(str_buffer[i], STRING_FONT, White);
    }

    ssd1306_UpdateScreen();
}

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
