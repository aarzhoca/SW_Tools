/******************************************************************************
 * @file     OLED_Control.h
 * @brief    OLED Control header file
 *
 * @note
 * Copyright (C) 2016 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __OLED_CONTROL_H
#define __OLED_CONTROL_H

#include <stdint.h>
#include "Platform_HAL.h"
#include "NuMicro.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "hal_tick_control.h"

/* OLED String Definition */
#define TIMER_OLED_UPDATE 100
extern uint32_t TimeCounterOLEDUpdate;
extern uint8_t OLED_Panel_Update_flag;
#define STRING_FONT          Font_7x10
#define STRING_FONT_X        7
#define STRING_FONT_Y        10
#define NUM_STRING           4
#define START_POSITION_X     2
#define MAX_CHAR_PER_LINE    ((SSD1306_WIDTH - START_POSITION_X)/STRING_FONT_X + 1)
#define START_POSITION_Y_GAP (SSD1306_HEIGHT - STRING_FONT_Y*NUM_STRING)/(NUM_STRING + 1)
#define START_POSITION_Y_A   (                  START_POSITION_Y_GAP  )
#define START_POSITION_Y_B   (STRING_FONT_Y   + START_POSITION_Y_GAP*2)
#define START_POSITION_Y_C   (STRING_FONT_Y*2 + START_POSITION_Y_GAP*3)
#define START_POSITION_Y_D   (STRING_FONT_Y*3 + START_POSITION_Y_GAP*4)

extern const uint8_t START_POSITION_Y[TOTAL_LED_AREA];

void OLED_Initial(void);
void OLED_Show_LightingMode(void);

#endif  /* __OLED_CONTROL_H */
