/***************************************************************************//**
 * @file     fmc_user.c
 * @version  V1.00
 * @brief    Simplified FMC driver source file
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2025 Nuvoton Technology Corp. All rights reserved.
 *****************************************************************************/

#include "fmc_user.h"

int FMC_Proc(uint32_t u32Cmd, uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t *pu32Data)
{
    uint32_t u32Addr, u32RegVal;
    uint32_t u32TimeOutCount;

    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr;)
    {
        FMC->ISPCMD  = u32Cmd;
        FMC->ISPADDR = u32Addr;

        if (u32Cmd == FMC_ISPCMD_PROGRAM)
        {
            FMC->ISPDAT = *pu32Data;
            pu32Data++;     /* Prevent Null pointer addition error in cppcheck */
        }
        else if (u32Cmd == FMC_ISPCMD_PROGRAM_64)
        {
            FMC->MPDAT0 = *pu32Data;
            pu32Data++;
            FMC->MPDAT1 = *pu32Data;
            pu32Data++;
        }

        FMC->ISPTRG = FMC_ISPTRG_ISPGO_Msk;
        __ISB();

        u32TimeOutCount = SystemCoreClock;

        /* Wait ISP cmd complete */
        while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk)
        {
            if (--u32TimeOutCount == 0) /* 1 second time-out */
                return -1;
        }

        u32RegVal = FMC->ISPCTL;

        if (u32RegVal & FMC_ISPCTL_ISPFF_Msk)
        {
            FMC->ISPCTL = u32RegVal;
            return -1;
        }

        if (u32Cmd == FMC_ISPCMD_READ)
        {
            *pu32Data = FMC->ISPDAT;
            pu32Data++;     /* Prevent NULL pointer addition error in cppcheck */
        }

        if (u32Cmd == FMC_ISPCMD_PAGE_ERASE)
        {
            u32Addr += FMC_FLASH_PAGE_SIZE;
        }
        else if (u32Cmd == FMC_ISPCMD_PROGRAM_64)
        {
            u32Addr += 8;
        }
        else
        {
            u32Addr += 4;
        }
    }

    return 0;
}

/**
 * @brief      Program 32-bit data into specified address of flash
 *
 * @param[in]  u32Addr  Flash address include APROM, LDROM, Data Flash, and CONFIG
 * @param[in]  u32Data  32-bit Data to program
 *
 * @details    To program word data into Flash include APROM, LDROM, Data Flash, and CONFIG.
 *             The corresponding functions in CONFIG are listed in FMC section of TRM.
 *
 * @note
 *             Please make sure that Register Write-Protection Function has been disabled
 *             before using this function. User can check the status of
 *             Register Write-Protection Function with SYS_IsRegLocked().
 */
int FMC_Write_User(uint32_t u32Addr, uint32_t u32Data)
{
    return FMC_Proc(FMC_ISPCMD_PROGRAM, u32Addr, u32Addr + 4, &u32Data);
}

/**
 * @brief       Read 32-bit Data from specified address of flash
 *
 * @param[in]   u32Addr  Flash address include APROM, LDROM, Data Flash, and CONFIG
 *
 * @return      The data of specified address
 *
 * @details     To read word data from Flash include APROM, LDROM, Data Flash, and CONFIG.
 *
 * @note
 *              Please make sure that Register Write-Protection Function has been disabled
 *              before using this function. User can check the status of
 *              Register Write-Protection Function with SYS_IsRegLocked().
 */
int FMC_Read_User(uint32_t u32Addr, uint32_t *pu32Data)
{
    return FMC_Proc(FMC_ISPCMD_READ, u32Addr, u32Addr + 4, pu32Data);
}

/**
 * @brief      Flash page erase
 *
 * @param[in]  u32Addr  Flash address including APROM, LDROM, Data Flash, and CONFIG
 *
 * @details    To do flash page erase. The target address could be APROM, LDROM, Data Flash, or CONFIG.
 *             The page size is FMC_FLASH_PAGE_SIZE.
 *
 * @note
 *             Please make sure that Register Write-Protection Function has been disabled
 *             before using this function. User can check the status of
 *             Register Write-Protection Function with SYS_IsRegLocked().
 */
int FMC_Erase_User(uint32_t u32PageAddr)
{
    return FMC_Proc(FMC_ISPCMD_PAGE_ERASE, u32PageAddr, u32PageAddr + 4, 0);
}

void ReadData(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t *pu32Data)    // Read data from flash
{
    FMC_Proc(FMC_ISPCMD_READ, u32StartAddr, u32EndAddr, pu32Data);
    return;
}

void WriteData(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t *pu32Data)  // Write data into flash
{
    FMC_Proc(FMC_ISPCMD_PROGRAM_64, u32StartAddr, u32EndAddr, pu32Data);
    return;
}


int EraseAP(uint32_t u32StartAddr, uint32_t u32EraseSize)
{
    uint32_t u32Addr, u32Cmd, u32Size;
    uint32_t u32TimeOutCount;

    u32Addr = u32StartAddr;

    while (u32EraseSize > 0)
    {
        u32Cmd  = FMC_ISPCMD_PAGE_ERASE;
        u32Size = FMC_FLASH_PAGE_SIZE;

        FMC->ISPCMD  = u32Cmd;
        FMC->ISPADDR = u32Addr;
        FMC->ISPTRG  = FMC_ISPTRG_ISPGO_Msk;
        __ISB();

        u32TimeOutCount = FMC_TIMEOUT_ERASE;

        /* Wait ISP cmd complete */
        while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk)   /* Wait for ISP command done. */
        {
            if (--u32TimeOutCount == 0)
                return -1;
        }

        if (FMC->ISPCTL & FMC_ISPCTL_ISPFF_Msk)
        {
            FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;
            return -1;
        }

        u32Addr += u32Size;
        u32EraseSize -= u32Size;
    }

    return 0;
}

void UpdateConfig(uint32_t *pu32Data, uint32_t *pu32Resp)
{
    uint32_t u32ConfigBytes = (ISP_CONFIG_CNT * 4);

    FMC_ENABLE_CFG_UPDATE();

    FMC_Proc(FMC_ISPCMD_CFG_ERASE, FMC_USER_CONFIG_0, (FMC_USER_CONFIG_0 + u32ConfigBytes), 0);
    FMC_Proc(FMC_ISPCMD_PROGRAM,   FMC_USER_CONFIG_0, (FMC_USER_CONFIG_0 + u32ConfigBytes), pu32Data);

    if (pu32Resp)
    {
        /* Read back to response */
        FMC_Proc(FMC_ISPCMD_READ, FMC_USER_CONFIG_0, (FMC_USER_CONFIG_0 + u32ConfigBytes), pu32Resp);
    }

    FMC_DISABLE_CFG_UPDATE();
}

/*** (C) COPYRIGHT 2025 Nuvoton Technology Corp. ***/
